create
    definer = part@`%` procedure WAITING_ACCOUNT_Flow() comment '待入帐(结算上个月流量卡)'
BEGIN
  DECLARE b_agent_no varchar(10);    -- 代理商编号
  DECLARE b_wait_account decimal(18, 2) DEFAULT '0'; -- 待入帐
  DECLARE b_code int(1); -- 工作状态
  DECLARE b_account_type int(1); -- 账户类型
  DECLARE b_yesterday_sum_money decimal(18, 2) DEFAULT '0'; -- 昨日代理的分润
  DECLARE t_error integer DEFAULT 0; -- 错误标识
  DECLARE stop_flag int DEFAULT 0;    -- 记录游标循环是否终止 


  DECLARE wa_procedures CURSOR FOR
  (SELECT
      agent_no,
      wait_account,
      aa.account_type
    FROM agent_account aa
    WHERE account_type = '8'
    AND `status` = '1');
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1; -- 异常标识
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET stop_flag = 1;
  START TRANSACTION;
    OPEN wa_procedures;
    REPEAT
      FETCH wa_procedures INTO b_agent_no, b_wait_account, b_account_type;
      IF stop_flag != 1 THEN

        SET b_yesterday_sum_money = (SELECT
            SUM(aad.amount)
          FROM agent_account_details aad
          WHERE aad.set_type = 0
          AND aad.details_status = '0'
          AND DATE_FORMAT(aad.set_date, '%Y-%m') = DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), '%Y-%m')
          AND aad.agent_no = b_agent_no
          AND aad.account_type = b_account_type);
        -- 代理账目明细总金额
        --         SET b_sum_money = (SELECT SUM(aad.amount) FROM agent_account_details aad WHERE 
        --         DATE_FORMAT(aad.set_date,'%Y-%m-%d') <= DATE_FORMAT( DATE_SUB(NOW(),INTERVAL 1 DAY) ,'%Y-%m-%d') and
        --         aad.details_status='0'AND aad.set_type = '0' AND aad.account_type=b_account_type AND aad.agent_no=b_agent_no); 
        --  校验，明细表中金额 = 待入帐金额
        -- IF b_sum_money = b_wait_account  THEN 
        --        IF b_sum_money is NOT NULL THEN 
        IF b_yesterday_sum_money IS NOT NULL THEN
          --  修改可用余额，最后修改时间，待入帐 = 0；
          UPDATE agent_account
          SET total_amt = total_amt + b_yesterday_sum_money,
              last_time = NOW(),
              wait_account = wait_account - b_yesterday_sum_money
          WHERE agent_no = b_agent_no
          AND account_type = b_account_type;
          -- 修改上个月流量卡交易
          UPDATE agent_account_details aad
          SET details_status = 1
          WHERE aad.set_type = 0
          AND aad.details_status = '0'
          AND DATE_FORMAT(aad.set_date, '%Y-%m') = DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), '%Y-%m')
          AND aad.agent_no = b_agent_no
          AND aad.account_type = b_account_type;
        END IF;
      END IF;

    --  END IF;
    UNTIL stop_flag = 1
    END REPEAT;
    CLOSE wa_procedures;
    IF t_error = 1 THEN
      ROLLBACK;
    ELSE
    COMMIT;
  END IF;

END;


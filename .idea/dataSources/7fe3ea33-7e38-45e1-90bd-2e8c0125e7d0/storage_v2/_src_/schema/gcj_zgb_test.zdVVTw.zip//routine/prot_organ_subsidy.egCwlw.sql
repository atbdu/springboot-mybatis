create
    definer = part@`%` procedure prot_organ_subsidy(IN agent_no1 varchar(30), IN organ_subsidy_policy int(5),
                                                    IN product varchar(30), IN trad_money1 varchar(20),
                                                    IN trad_serial_no1 varchar(30), OUT total_amount varchar(30))
BEGIN
  DECLARE t_error integer DEFAULT 0; -- 错误标识
  DECLARE reward_earnings varchar(18) DEFAULT 0; -- 奖励收益
  DECLARE policy_rate varchar(10); -- 奖励费率
  DECLARE is_min_agent_no int(5); -- 是否是最后一级代理
  DECLARE up_policy_rate varchar(10); -- 上级奖励费率
  DECLARE this_agent_no varchar(30); -- 当前代理 
  DECLARE up_agent_no varchar(30); -- 上级代理 
  DECLARE max_agent_no varchar(30); -- 最上级代理 
  DECLARE direct_money varchar(18) DEFAULT 0; -- 直营交易金额
  DECLARE front_end_display1 int(1); -- 当前代理享受政策
  DECLARE front_end_display2 int(1); -- 上级代理享受政策
  DECLARE count_num int(5); -- 是否重复插入
  DECLARE add_date1 varchar(15); -- 政策添加日期
  DECLARE add_time1 varchar(15); -- 政策添加时间
  DECLARE amend_num1 int(5); -- 是否是第一次修改   trad_serial_no2
  DECLARE agent_total_money varchar(18) DEFAULT 0; -- 当前代理交易金额
  DECLARE down_total_money varchar(18) DEFAULT 0; -- 下级代理交易总金额
  DECLARE trad_serial_no2 varchar(30) DEFAULT 0; -- 交易流水号
  DECLARE total_money varchar(18) DEFAULT 0; -- 首次奖励金额
  DECLARE is_this_month varchar(18) DEFAULT 0; -- 是否是当前月份
  DECLARE this_month varchar(18) DEFAULT 0; -- 当前月份
  DECLARE stop_flag int DEFAULT 0;

  DECLARE organ_subsidy CURSOR FOR
  (SELECT
      pdr.e_value,
      ap.add_date,
      ap.add_time,
      ap.amend_num,
      ap.front_end_display,
      pdr.object_no
    FROM agent_policy ap
      LEFT JOIN policy_detail_rim pdr
        ON pdr.policy_type_no = ap.policy_type_no
        AND ap.agent_no = pdr.object_no
    WHERE pdr.object_no IN (SELECT
        aa.agent_no
      FROM agent_agent aa
      WHERE aa.parent_no = agent_no1
      AND aa.agent_no != agent_no1
      --       WHERE aa.parent_no = agent_no1
      AND aa.is_direct = 1)
    AND pdr.policy_type_no = organ_subsidy_policy
    AND pdr.object_type = '1');

  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1; -- 异常标识
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET stop_flag = 1;
  START TRANSACTION;
    --     -- 上级费率和上级代理
    --     SELECT
    --       pdr.object_no,
    --       pdr.e_value,
    --       ap.front_end_display
    --     FROM agent_policy ap
    --       LEFT JOIN policy_detail_rim pdr
    --         ON pdr.policy_type_no = ap.policy_type_no
    --         AND ap.agent_no = pdr.object_no
    --     WHERE pdr.object_no IN (SELECT
    --         aa.parent_no
    --       FROM agent_agent aa
    --       WHERE aa.agent_no = agent_no1
    --       AND aa.is_direct = 1)
    --     AND pdr.policy_type_no = organ_subsidy_policy
    --     AND pdr.object_type = '1' INTO up_agent_no, up_policy_rate, front_end_display2;
    -- 是否最后一级代理   1 最后一级代理
    --     SET is_min_agent_no = (SELECT
    --         COUNT(*)
    --       FROM agent_agent aa
    --       WHERE aa.parent_no = agent_no1);

    SET total_amount = 0;
    SET max_agent_no = (SELECT
        aa.parent_no
      FROM agent_agent aa
      WHERE aa.agent_no = agent_no1 LIMIT 1);
    OPEN organ_subsidy;
    REPEAT
      FETCH organ_subsidy INTO policy_rate, add_date1, add_time1, amend_num1, front_end_display1, this_agent_no;
      IF stop_flag != 1 THEN
        IF policy_rate IS NULL THEN -- 政策类型中的值为空的话，改变错误标识状态
          SET policy_rate = 0;
          SET stop_flag = 1;
        END IF;

        SET trad_serial_no2 = CONCAT(DATE_FORMAT(CURDATE(), '%Y%m'), this_agent_no);
        SET agent_total_money = (SELECT
            SUM(ts.trad_money) AS total_money
          FROM trad_serial ts
          WHERE ts.trade_status = 1
          AND ts.trade_type IN ('0', '6', '9')
          AND DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), '%Y-%m') = DATE_FORMAT(ts.trad_date, '%Y-%m')
          AND ts.product_no = product
          AND ts.agent_no IN (SELECT
              aa.agent_no
            FROM agent_agent aa
            WHERE aa.parent_no = this_agent_no)
          AND ts.trade_type != 5);

        IF front_end_display1 = 0 THEN
          SET policy_rate = 0;
        END IF;
        --         IF front_end_display2 = 0 THEN
        --           SET up_policy_rate = 0;
        --         END IF;
        -- 不是首次奖励
        --         IF amend_num1 != 1 THEN
        -- 最后一级代理奖励
        --         IF is_min_agent_no = 1 THEN
        -- 防止重复插入
        SET count_num = (SELECT
            COUNT(*)
          FROM agent_account_details aad
          WHERE aad.serial_no = trad_serial_no2
          AND aad.agent_no = this_agent_no
          AND aad.product_no = product);
          -- 计算收益
        SET reward_earnings = policy_rate * agent_total_money / 10000;
        IF count_num = 0 THEN
          IF this_agent_no != agent_no1 THEN
            IF reward_earnings IS NULL
              AND reward_earnings < 0 THEN
              SET t_error = 1;
            END IF;
            IF reward_earnings > 0 THEN
              -- 插入金额
              UPDATE agent_account
              SET wait_account = wait_account + TRUNCATE(reward_earnings, 2)
              WHERE agent_no = this_agent_no
              AND account_type = '0';
              -- 插入记录
              INSERT INTO agent_account_details (serial_no, agent_no, amount, set_date, set_time, product_no, account_type, act_rim, source_flag, trade_money)
                VALUES (trad_serial_no2, this_agent_no, TRUNCATE(reward_earnings, 2), CURDATE(), CURTIME(), product, '0', '机构补贴', '3', trad_money1);
            END IF;
            
          END IF;
        END IF;
        IF reward_earnings IS NOT NULL THEN
              SET total_amount = total_amount + reward_earnings;
            END IF;
      -- 上级代理奖励
      --         IF agent_no1 != up_agent_no THEN
      --           SET reward_earnings = (up_policy_rate - policy_rate) * trad_money1 / 10000;
      --           IF reward_earnings IS NULL
      --             AND reward_earnings < 0 THEN
      --             SET t_error = 1;
      --           END IF;
      --           -- 插入金额
      --           IF reward_earnings > 0 THEN
      --             UPDATE agent_account
      --             SET wait_account = wait_account + TRUNCATE(reward_earnings, 2)
      --             WHERE agent_no = up_agent_no
      --             AND account_type = '0';
      --             -- 插入记录
      --             INSERT INTO agent_account_details (serial_no, agent_no, amount, set_date, set_time, product_no, account_type, act_rim, source_flag, trade_money)
      --               VALUES (trad_serial_no1, up_agent_no, TRUNCATE(reward_earnings, 2), CURDATE(), CURTIME(), product, '0', '机构补贴', '3', trad_money1);
      --           END IF;
      --           SET count_num = (SELECT
      --               COUNT(*)
      --             FROM agent_account_details aad
      --             WHERE aad.serial_no = trad_serial_no1
      --             AND aad.agent_no = agent_no1
      --             AND aad.product_no = product);
      --           IF agent_no1 = this_agent_no
      --             AND count_num = 0 THEN
      --             -- 直营交易金额
      --             SET direct_money = (SELECT
      --                 SUM(ts.trad_money)
      --               FROM trad_serial ts
      --               WHERE DATE_FORMAT(ts.trad_date, '%Y-%m') = DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), '%Y-%m')
      --               AND ts.agent_no = agent_no1
      --               AND ts.trade_type IN ('0', '6', '9')
      --               AND ts.product_no = product
      --               AND ts.trade_type != 5);
      --             SET reward_earnings = policy_rate * direct_money / 10000;
      --             IF reward_earnings IS NULL
      --               AND reward_earnings < 0 THEN
      --               SET t_error = 1;
      --             END IF;
      --             IF reward_earnings > 0 THEN
      --               -- 插入金额
      --               UPDATE agent_account
      --               SET wait_account = wait_account + TRUNCATE(reward_earnings, 2)
      --               WHERE agent_no = agent_no1
      --               AND account_type = '0';
      --               -- 插入记录
      --               INSERT INTO agent_account_details (serial_no, agent_no, amount, set_date, set_time, product_no, account_type, act_rim, source_flag, trade_money)
      --                 VALUES (trad_serial_no1, agent_no1, TRUNCATE(reward_earnings, 2), CURDATE(), CURTIME(), product, '0', '机构补贴', '3', trad_money1);
      --           END IF;
      -- 
      --           END IF;

      --         END IF;
      -- 最上级奖励
      --         IF max_agent_no = agent_no1 THEN
      --           -- 直营交易金额
      --           SET direct_money = (SELECT
      --               SUM(ts.trad_money)
      --             FROM trad_serial ts
      --             WHERE DATE_FORMAT(ts.trad_date, '%Y-%m') = DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), '%Y-%m')
      --             AND ts.agent_no = agent_no1
      --             AND ts.trade_type IN ('0', '6', '9')
      --             AND ts.product_no = product
      --             AND ts.trade_type != 5);
      --           SET reward_earnings = policy_rate * trad_money1 / 10000;
      --           IF reward_earnings IS NULL
      --             AND reward_earnings < 0 THEN
      --             SET t_error = 1;
      --           END IF;
      --           IF reward_earnings > 0 THEN
      --             -- 插入金额
      --             UPDATE agent_account
      --             SET wait_account = wait_account + TRUNCATE(reward_earnings, 2)
      --             WHERE agent_no = agent_no1
      --             AND account_type = '0';
      --             -- 插入记录
      --             INSERT INTO agent_account_details (serial_no, agent_no, amount, set_date, set_time, product_no, account_type, act_rim, source_flag, trade_money)
      --               VALUES (trad_serial_no1, agent_no1, TRUNCATE(reward_earnings, 2), CURDATE(), CURTIME(), product, '0', '机构补贴', '3', trad_money1);
      --           END IF;
      --           SET down_total_money = down_total_money + reward_earnings;
      --         END IF;
      --         END IF;
      -- 
      --         -- 首次奖励
      --         IF add_time1 IS NULL THEN
      --           SET add_time1 = '00:00:00';
      --         END IF;
      --         SET is_this_month = DATE_FORMAT(add_date1, '%Y-%m');
      --         SET this_month = DATE_FORMAT(CURDATE(), '%Y-%m'); -- CURDATE()
      --         -- 不计算本月享受政策的新代理
      --         IF amend_num1 = 1
      --           AND is_this_month != this_month THEN
      --           -- 享受政策起 按代理按产品按贷记卡的交易总额
      --           -- 享受补贴日-当月最后一天交易
      --           SET total_money = (SELECT
      --               SUM(trad_money) AS total_money
      --             FROM trad_serial
      --             WHERE trade_status = 1
      --             AND trade_type IN ('0', '6', '9')
      --             AND agent_no = agent_no1
      --             AND product_no = product
      --             AND CONCAT(trad_date, ' ', trad_time) BETWEEN CONCAT(add_date1, ' ', add_time1) AND CONCAT(LAST_DAY(add_date1), ' ', '23:59:59'));
      --           IF total_money IS NOT NULL THEN
      --             -- 最后一级代理奖励
      --             IF is_min_agent_no = 1 THEN
      --               SET reward_earnings = policy_rate * trad_money1 / 10000;
      --               IF reward_earnings IS NULL
      --                 AND reward_earnings < 0 THEN
      --                 SET t_error = 1;
      --               END IF;
      --               -- 插入金额
      --               UPDATE agent_account
      --               SET wait_account = wait_account + TRUNCATE(reward_earnings, 2)
      --               WHERE agent_no = agent_no1
      --               AND account_type = '0';
      --               -- 插入记录
      --               INSERT INTO agent_account_details (serial_no, agent_no, amount, set_date, set_time, product_no, account_type, act_rim, source_flag, trade_money)
      --                 VALUES (trad_serial_no1, agent_no1, TRUNCATE(reward_earnings, 2), CURDATE(), CURTIME(), product, '0', '机构补贴', '3', trad_money1);
      --             END IF;
      --             -- 上级代理奖励
      --             IF agent_no1 != up_agent_no THEN
      --               SET reward_earnings = (up_policy_rate - policy_rate) * trad_money1 / 10000;
      --               IF reward_earnings IS NULL
      --                 AND reward_earnings < 0 THEN
      --                 SET t_error = 1;
      --               END IF;
      --               -- 插入金额
      --               UPDATE agent_account
      --               SET wait_account = wait_account + TRUNCATE(reward_earnings, 2)
      --               WHERE agent_no = up_agent_no
      --               AND account_type = '0';
      --               -- 插入记录
      --               INSERT INTO agent_account_details (serial_no, agent_no, amount, set_date, set_time, product_no, account_type, act_rim, source_flag, trade_money)
      --                 VALUES (trad_serial_no1, up_agent_no, TRUNCATE(reward_earnings, 2), CURDATE(), CURTIME(), product, '0', '机构补贴', '3', trad_money1);
      --             END IF;
      --             UPDATE agent_policy ap
      --             SET ap.amend_num = ap.amend_num + 1
      --             WHERE ap.agent_no = agent_no1
      --             AND ap.policy_type_no = organ_subsidy_policy;
      --           END IF;
      --           IF total_money IS NULL
      --             AND amend_num1 = 1 THEN
      --             SET total_money = 0;
      -- --             INSERT INTO agent_account_details (serial_no, agent_no, amount, set_date, set_time, product_no, account_type, act_rim, source_flag, trade_money)
      -- --               VALUES (trad_serial_no1, agent_no1, TRUNCATE(reward_earnings, 2), CURDATE(), CURTIME(), product, '0', '机构补贴', '3', trad_money1);
      --             UPDATE agent_policy ap
      --             SET ap.amend_num = ap.amend_num + 1
      --             WHERE ap.agent_no = agent_no1
      --             AND ap.policy_type_no = organ_subsidy_policy;
      --           END IF;
      --         END IF;

      END IF;
    UNTIL stop_flag = 1
    END REPEAT;
    SELECT
      total_amount;
    CLOSE organ_subsidy;
    IF t_error = 1 THEN
      ROLLBACK;
    ELSE
    COMMIT;
  END IF;
END;


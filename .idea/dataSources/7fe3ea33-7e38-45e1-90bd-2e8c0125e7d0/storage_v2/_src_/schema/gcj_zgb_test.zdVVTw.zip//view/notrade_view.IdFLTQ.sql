create view notrade_view as
select `gcj_zgb_test`.`pay_company_product`.`product_no` AS `product_no`
from `gcj_zgb_test`.`pay_company_product`
where ((`gcj_zgb_test`.`pay_company_product`.`product_no` in
        ('P00000001', 'P00000002', 'P00000003', 'P00000013', 'P00000014', 'P00000018', 'P00000020')) and
       (not (`gcj_zgb_test`.`pay_company_product`.`product_no` in
             (select distinct `gcj_zgb_test`.`trad_serial`.`product_no`
              from `gcj_zgb_test`.`trad_serial`
              where ((`gcj_zgb_test`.`trad_serial`.`trade_status` = 1) and
                     (`gcj_zgb_test`.`trad_serial`.`trade_type` in ('0', '6', '9')) and
                     (date_format(('2021-07-15' - interval 1 month), '%Y-%m') =
                      date_format(`gcj_zgb_test`.`trad_serial`.`trad_date`, '%Y-%m')) and
                     (`gcj_zgb_test`.`trad_serial`.`agent_no` = 'A00000100'))))));

-- comment on column notrade_view.product_no not supported: 产品编号


create definer = part@`%` trigger policy_detail_no_insert_seq
    before insert
    on policy_detail
    for each row
BEGIN
  set new.policy_detail_no =( select concat('PD',LPAD((replace(IFNULL(max(policy_detail_no),0),'PD','')+1),4,0)) from policy_detail);
END;


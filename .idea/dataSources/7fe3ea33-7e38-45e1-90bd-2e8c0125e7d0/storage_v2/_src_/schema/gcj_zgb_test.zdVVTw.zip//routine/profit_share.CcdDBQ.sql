create
    definer = part@`%` procedure profit_share(IN trad_serial_no1 varchar(50), IN pay_name varchar(50),
                                              IN policytype int, IN policytype_device int, IN tx_money1 decimal(15, 2),
                                              IN deposit_amount1 decimal(15, 2), IN flow_card_amount1 decimal(15, 2))
    comment '交易分润'
lb:
BEGIN
  DECLARE t_error integer DEFAULT 0; -- 错误标识
  DECLARE trad_set_point decimal(6, 2); -- 交易流水上的结算点
  DECLARE product varchar(50); -- 产品编号
  DECLARE policy_rate decimal(6, 5); -- 代理政策费率
  DECLARE policy_name varchar(100); -- 交易费率
  DECLARE transcation_money decimal(18, 5); -- 交易金额
  DECLARE profit_money decimal(15, 5) DEFAULT 0.00; -- 收取金额
  DECLARE transcation_rate decimal(6, 5); -- 费率
  DECLARE device_rate1 decimal(6, 5); -- 终端费率
  DECLARE pay_type int; -- 支付方式
  DECLARE temp_rate decimal(6, 5); -- 中间变量
  DECLARE rate_l decimal(6, 5); -- 上级代理收取费率
  DECLARE bottom_profit decimal(18, 5) DEFAULT 0.00; -- 下级代理的费用
  DECLARE total_money decimal(18, 5); -- 总金额
  DECLARE device_policy varchar(255); -- 终端结算政策
  DECLARE trade_status1 int; -- 交易状态
  DECLARE device_no1 varchar(50); -- 终端编号
  DECLARE device_trade_rate decimal(6, 5); -- 终端费率
  DECLARE agent_no1 varchar(50); -- 代理商编号
  DECLARE last_agent_no varchar(50); -- 最后一级代理的编号
  DECLARE agent_level int; -- 代理商等级
  DECLARE stop_flag int DEFAULT 0; -- 游标停止的条件

  DECLARE custom_no1 varchar(50); -- 客户编号
  DECLARE chnnel_customer_no1 varchar(50); -- 商户通道编号
  DECLARE count_detail_flow int DEFAULT 0; -- 是否进行了流量卡分润
  DECLARE count_detail_deposit int DEFAULT 0;-- 是否押金分润
  DECLARE source_flag1 int; -- 数据来源标识
  -- 查询代理商编号和 政策，然后使用游标遍历
  DECLARE search_agents_policys_cursor CURSOR FOR
  (SELECT
      a.agent_no,
      pdr.e_name,
      pdr.e_value
    FROM policy_detail_rim pdr
      LEFT JOIN agent a
        ON pdr.object_no = a.agent_no
    WHERE pdr.policy_type_no = policytype
    AND pdr.e_name = pay_name
    AND pdr.object_no IN (SELECT
        parent_no
      FROM agent_agent
      WHERE agent_no = (SELECT
          agent_no
        FROM trad_serial
        WHERE trad_serial_no = trad_serial_no1))
    AND object_type = '1'
    ORDER BY a.agent_level DESC);
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1; -- 异常标识
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET stop_flag = 1;
  SELECT
    trad_money,
    trade_type,
    trade_status,
    device_no,
    set_point,
    product_no
  FROM trad_serial
  WHERE trad_serial_no = trad_serial_no1 INTO transcation_money, pay_type, trade_status1, device_no1, trad_set_point, product; -- 查询直属代理编号，交易金额，交易类型，结算状态,机具编号
  START TRANSACTION;
    -- 终端上结算费率
      SET device_trade_rate=(
      SELECT e_value
      FROM policy_detail_rim
      WHERE policy_type_no = policytype_device  -- 15表示终端政策类型编号
      AND object_no = device_no1
      AND object_type = '2' -- 2表示终端政策
      AND product_no = product
      AND e_name = pay_name);
      IF device_trade_rate IS NULL THEN
        LEAVE lb;
      END IF;
      IF device_trade_rate != trad_set_point THEN -- 终端费率不等于结算点的话
        UPDATE policy_detail_rim
        SET e_value = trad_set_point
        WHERE policy_type_no = policytype_device  -- 15表示终端政策类型编号
        AND object_no = device_no1
        AND object_type = '2' -- 2表示终端政策
        AND product_no = product
        AND e_name = pay_name;
      END IF;
    -- 查询机具编号，客户编号，商户通道编号
    SELECT
      device_no,
      customer_no,
      chnnel_customer_no,
      agent_no
    FROM trad_serial ts
    WHERE ts.trad_serial_no = trad_serial_no1 INTO device_no1, custom_no1, chnnel_customer_no1, agent_no1;

    SET device_rate1 = trad_set_point; -- 交易记录上的结算点
    SET transcation_money = transcation_money - deposit_amount1 - flow_card_amount1; -- 参与交易分润的金额=交易金额 - 押金 - 流量卡
    IF deposit_amount1 IS NOT NULL AND deposit_amount1 != '0' THEN
      SELECT COUNT(1) FROM agent_account_details aad WHERE aad.device_no=device_no1 AND aad.source_flag=10 INTO count_detail_deposit;
     IF product='P00000001'AND count_detail_deposit=0 THEN
      IF deposit_amount1=99 THEN
        CALL everyone_deposit_policy(device_no1,'7',product,deposit_amount1,pay_type);
      ELSEIF deposit_amount1=199 THEN
        CALL everyone_deposit_policy(device_no1,'8',product,deposit_amount1,pay_type);
      END IF;
     ELSEIF product='P00000002'AND count_detail_deposit=0 THEN
      IF deposit_amount1=299 THEN
        CALL everyone_deposit_policy(device_no1,'15',product,deposit_amount1,pay_type);
      ELSEIF deposit_amount1=399 THEN
        CALL everyone_deposit_policy(device_no1,'16',product,deposit_amount1,pay_type);
      END IF;
     END IF;
    END IF;
    -- 流量卡分润
    IF flow_card_amount1 != 0 THEN
      SELECT COUNT(1) FROM agent_account_details aad WHERE aad.device_no=device_no1 AND aad.source_flag=4 INTO count_detail_flow;
      IF product = 'P00000001'AND count_detail_flow=0 THEN -- 4
        CALL flow_card_profit(agent_no1, 4, device_no1, custom_no1, chnnel_customer_no1, 4, pay_type, product,flow_card_amount1);
      ELSEIF product = 'P00000002' AND count_detail_flow=0 THEN -- 12
        CALL flow_card_profit(agent_no1, 12, device_no1, custom_no1, chnnel_customer_no1, 4, pay_type, product,flow_card_amount1);
      END IF;
    END IF;

    SET profit_money = transcation_money * device_rate1 / 100; -- 直属代理能获取的金额
    OPEN search_agents_policys_cursor;
    REPEAT
      FETCH search_agents_policys_cursor INTO agent_no1, policy_name, policy_rate;
      IF policy_rate IS NULL THEN -- 政策类型中的值为空的话，改变错误标识状态
        SET t_error = 1;
      END IF;
      UPDATE policy_detail_rim SET e_value = tx_money1 WHERE e_name = 'tx_money'
      AND policy_type_no = policytype_device AND object_no = device_no1;
      IF stop_flag != 1 THEN
        -- 解析政策
        IF pay_type = 0
          OR pay_type = 4 THEN -- 刷卡
          -- IF policy_name = 'trad_rate'  THEN
          SET transcation_rate = policy_rate;
        -- END IF;
        ELSE
          -- IF policy_name='qr_code' THEN
          SET transcation_rate = policy_rate;
        -- END IF;
        END IF;
        -- 终端结算小于代理结算 
        IF device_rate1 < transcation_rate THEN
          INSERT INTO agent_account_details (serial_no, agent_no, amount, set_date, set_time, product_no, account_type, act_rim, device_no,
          customer_no, chnnel_customer_no, source_flag, trade_type, trade_money)
            VALUES (trad_serial_no1, agent_no1, 0, CURDATE(), CURTIME(), product, '0', '交易分润', device_no1, custom_no1, chnnel_customer_no1, 0, pay_type, transcation_money);
        END IF;
        -- 终端结算大于代理结算  正常运算
        IF device_rate1 >= transcation_rate THEN
          SET bottom_profit = (profit_money - transcation_money * transcation_rate / 100); -- 下级的金额 - 上级的金额
          -- 分润小于0时，当前代理结算为0
          IF bottom_profit < 0 THEN
            INSERT INTO agent_account_details (serial_no, agent_no, amount, set_date, set_time, product_no, account_type, act_rim, device_no,
            customer_no, chnnel_customer_no, source_flag, trade_type, trade_money)
              VALUES (trad_serial_no1, agent_no1, 0, CURDATE(), CURTIME(), product, '0', '交易分润', device_no1, custom_no1, chnnel_customer_no1, 0, pay_type, transcation_money);
          ELSE
            SET profit_money = transcation_money * transcation_rate / 100;
            IF profit_money IS NULL THEN -- 钱为空的话，也回滚
              SET t_error = 1;
            END IF;
            -- SET total_money = ((SELECT total_amt FROM agent_account WHERE agent_no = agent_no1 AND account_type = '0')+bottom_profit);
            UPDATE agent_account
            SET wait_account = wait_account + TRUNCATE(bottom_profit, 2)
            WHERE agent_no = agent_no1
            AND account_type = '0'; -- 插入金额

            INSERT INTO agent_account_details (serial_no, agent_no, amount, set_date, set_time, product_no, account_type, act_rim, device_no,
            customer_no, chnnel_customer_no, source_flag, trade_type, trade_money)
              VALUES (trad_serial_no1, agent_no1, TRUNCATE(bottom_profit, 2), CURDATE(), CURTIME(), product, '0', '交易分润', device_no1, custom_no1, chnnel_customer_no1, 0, pay_type, transcation_money);
          END IF;
        END IF;
      END IF;
    UNTIL stop_flag = 1
    END REPEAT;
    CLOSE search_agents_policys_cursor;

    UPDATE trad_serial SET trade_status = 1 WHERE trad_serial_no = trad_serial_no1; -- 改变交易的结算状态
    IF t_error = 1 THEN
      ROLLBACK;
    ELSE
    COMMIT;
  END IF;
END;


create definer = part@`%` trigger company_no_insert_seq
    before insert
    on pay_company
    for each row
BEGIN
  set new.company_no =( select concat('P',LPAD((replace(IFNULL(max(company_no),0),'P','')+1),2,0)) from pay_company);
END;


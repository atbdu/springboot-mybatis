create
    definer = part@`%` procedure demo1()
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('demo1', 'pay2_shuaxinguanjia', 7, 100636)/*[cr_debug.1]*/;
	DECLARE procduct_flag INT; -- 商品标志 3表示POS，4表示电签
	DECLARE product VARCHAR(50);
	DECLARE stopflg INT DEFAULT 0;
	DECLARE pay_name VARCHAR(50);
	DECLARE pay_type INT(10);
	DECLARE trad_serial_no1 VARCHAR(255); -- 流水编号
	DECLARE date_cursor CURSOR  FOR(
			SELECT trad_serial_no,trade_type,product_no FROM trad_serial WHERE  
	(product_no = 'P00000002' OR product_no = 'P00000001') AND company_no='P02' AND trade_status = 0  
	);
	DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('demo1_Handler', 'demo1', 'pay2_shuaxinguanjia', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('procduct_flag', procduct_flag, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('pay_type', pay_type, 'INT(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, 'VARCHAR(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(13, 13, 40, 54, cr_stack_depth)/*[cr_debug.2]*/;
set stopflg=1;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;   -- 当无记录时，标记游标终止
		CALL cr_debug.UPDATE_WATCH3('procduct_flag', procduct_flag, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('pay_type', pay_type, 'INT(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, 'VARCHAR(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(2, 2, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(14, 14, 2, 19, cr_stack_depth)/*[cr_debug.2]*/;
OPEN date_cursor; -- 打开游标
			CALL cr_debug.TRACE(15, 37, 3, 14, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT
				CALL cr_debug.TRACE(16, 16, 4, 60, cr_stack_depth)/*[cr_debug.2]*/;
FETCH date_cursor INTO trad_serial_no1,pay_type,product;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('pay_type', pay_type, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, '', cr_stack_depth)/*[cr_debug.1]*/;
				CALL cr_debug.TRACE(17, 35, 4, 11, cr_stack_depth)/*[cr_debug.2]*/;
IF(stopflg != 1) THEN	
						CALL cr_debug.TRACE(18, 22, 6, 13, cr_stack_depth)/*[cr_debug.2]*/;
IF pay_type = '0' OR pay_type='4' THEN 
							CALL cr_debug.TRACE(19, 19, 7, 34, cr_stack_depth)/*[cr_debug.2]*/;
SET pay_name = 'trad_rate';
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, '', cr_stack_depth)/*[cr_debug.1]*/;
						ELSE 
							CALL cr_debug.TRACE(21, 21, 7, 32, cr_stack_depth)/*[cr_debug.2]*/;
SET pay_name = 'qr_code';
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, '', cr_stack_depth)/*[cr_debug.1]*/;
						END IF;
						CALL cr_debug.TRACE(23, 27, 6, 13, cr_stack_depth)/*[cr_debug.2]*/;
IF product = 'P00000001' THEN -- 电签
							CALL cr_debug.TRACE(24, 24, 7, 31, cr_stack_depth)/*[cr_debug.2]*/;
SET procduct_flag = '4';
CALL cr_debug.UPDATE_WATCH3('procduct_flag', procduct_flag, '', cr_stack_depth)/*[cr_debug.1]*/;
							ELSEIF product = 'P00000002' THEN
							CALL cr_debug.TRACE(26, 26, 7, 31, cr_stack_depth)/*[cr_debug.2]*/;
SET procduct_flag = '3';
CALL cr_debug.UPDATE_WATCH3('procduct_flag', procduct_flag, '', cr_stack_depth)/*[cr_debug.1]*/;
						END IF;
            CALL cr_debug.TRACE(28, 32, 12, 13, cr_stack_depth)/*[cr_debug.2]*/;
IF product = 'P00000001' THEN -- 电签
							CALL cr_debug.TRACE(29, 29, 7, 31, cr_stack_depth)/*[cr_debug.2]*/;
SET procduct_flag = '6';
CALL cr_debug.UPDATE_WATCH3('procduct_flag', procduct_flag, '', cr_stack_depth)/*[cr_debug.1]*/;
							ELSEIF product = 'P00000002' THEN
							CALL cr_debug.TRACE(31, 31, 7, 31, cr_stack_depth)/*[cr_debug.2]*/;
SET procduct_flag = '5';
CALL cr_debug.UPDATE_WATCH3('procduct_flag', procduct_flag, '', cr_stack_depth)/*[cr_debug.1]*/;
						END IF;
						CALL cr_debug.TRACE(33, 33, 6, 64, cr_stack_depth)/*[cr_debug.2]*/;
CALL profit_share(trad_serial_no1,pay_name,procduct_flag);
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('procduct_flag', procduct_flag, '', cr_stack_depth)/*[cr_debug.1]*/; -- 调用结算分润存储过程
						--  UPDATE trad_serial SET trade_status = 1 WHERE trad_serial_no = trad_serial_no1; -- 改变交易的结算状态
				END IF;
			UNTIL stopflg =1
			END REPEAT;
		CALL cr_debug.TRACE(38, 38, 2, 20, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE date_cursor;	-- 关闭游标
CALL cr_debug.TRACE(39, 39, 0, 3, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


create
    definer = part@`%` procedure insert_agent_account()
BEGIN
	DECLARE stopflg INT DEFAULT 0;
	DECLARE agent_no1 VARCHAR(50);
	DECLARE date_cursor CURSOR  FOR( -- 终端激活
			SELECT agent_no FROM agent 
	);
	DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
		OPEN date_cursor; -- 打开游标
			REPEAT
				FETCH date_cursor INTO agent_no1;
				
				IF(stopflg != 1) THEN	
						INSERT INTO `agent_account` (`agent_no`, `freeze_amt`, `check_val`, `last_time`, `total_amt`, `account_type`, `wait_account`) 
					VALUES (agent_no1, '0.00', '0.00', '2021-06-07 22:35:59', '0.00', '8', '0.00');
				END IF;
			UNTIL stopflg =1
			END REPEAT;
		CLOSE date_cursor;	-- 关闭游标
END;


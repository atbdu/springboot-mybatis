create
    definer = part@`%` procedure profit_share_tx(IN trad_serial_no1 varchar(50), IN pay_name varchar(50),
                                                 IN policytype int, IN product varchar(50), IN tx_money1 decimal(15, 2),
                                                 IN agent_no1 varchar(50), IN device1 varchar(50),
                                                 IN customer_no1 varchar(50), IN chnnel_customer_no1 varchar(50),
                                                 IN pay_type int(2), IN deduct_single_fee1 decimal(5, 2),
                                                 IN trad_money1 decimal(18, 2))
BEGIN
	DECLARE t_error INTEGER DEFAULT 0; -- 错误标识
	DECLARE policy_rate DECIMAL(6,2); -- 代理提现手续费
	DECLARE policy_name VARCHAR(100); -- 交易费率
	DECLARE b_agent_no VARCHAR(30); -- 代理编号
	DECLARE profit_money DECIMAL(15,2) DEFAULT 0.00; -- 收取金额
  DECLARE this_tx_money decimal(15,2) DEFAULT 0.00; -- 最上级代理手续费
  DECLARE up_agent_tx_money decimal(15,2) DEFAULT 0.00; -- 上级代理手续费
  DECLARE min_agent_tx_money decimal(15,2) DEFAULT 0.00; -- 最上级代理手续费
	DECLARE set_tx_money DECIMAL(15,2) DEFAULT 0.00; -- 收取金额
  DECLARE max_agent_no varchar(30); -- 最上级代理
  DECLARE sum_total DECIMAL(6,2)DEFAULT 0.00; -- 代理提现手续费总和
  DECLARE one_flag INT DEFAULT 1; -- 一次标记
	DECLARE stop_flag INT DEFAULT 0; -- 游标停止的条件
	-- 查询代理商编号和 政策，然后使用游标遍历  自下而上
	DECLARE search_agents_policys_cursor CURSOR  FOR(
			select a.agent_no,pdr.e_name,pdr.e_value from policy_detail_rim pdr
	left join agent a on pdr.object_no=a.agent_no
	 where  pdr.policy_type_no=policytype AND pdr.e_name=pay_name and pdr.object_no IN (SELECT parent_no
                               FROM agent_agent
                               WHERE agent_no = agent_no1)
																AND object_type = '1' order by a.agent_level DESC
	);   
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1; -- 异常标识
	 DECLARE CONTINUE HANDLER FOR NOT FOUND set stop_flag=1;
   START TRANSACTION;

     SET this_tx_money = tx_money1;
   	OPEN search_agents_policys_cursor; 
			REPEAT
				FETCH search_agents_policys_cursor INTO b_agent_no,policy_name,policy_rate;
				IF policy_rate IS NULL THEN -- 政策类型中的值为空的话，改变错误标识状态
					SET t_error = 1;
				END IF;
       	IF stop_flag != 1 THEN
          -- 没有抵扣卷，进行分润
        IF tx_money1!=deduct_single_fee1 THEN 
        -- 计算分润
         SET profit_money = this_tx_money - policy_rate;
 
         -- 下级提现手续费费率=单笔提现手续费
        IF profit_money<=0 THEN
            set profit_money = 0;
            INSERT INTO agent_account_details(serial_no,agent_no,amount,set_date,set_time,product_no,account_type,act_rim,device_no,customer_no,chnnel_customer_no,trade_type,source_flag,trade_money)VALUES(
          			trad_serial_no1,b_agent_no,profit_money,CURDATE(),CURTIME(),product,'0','提现手续费分润',device1,customer_no1,chnnel_customer_no1,pay_type,'1',trad_money1);  
--                 set this_tx_money=tx_money1;
        ELSEIF profit_money>0 THEN 
          UPDATE agent_account SET wait_account = wait_account+profit_money WHERE agent_no = b_agent_no AND account_type = '0'; -- 插入金额
         	 INSERT INTO agent_account_details(serial_no,agent_no,amount,set_date,set_time,product_no,account_type,act_rim,device_no,customer_no,chnnel_customer_no,trade_type,source_flag,trade_money)VALUES(
          		trad_serial_no1,b_agent_no,profit_money,CURDATE(),CURTIME(),product,'0','提现手续费分润',device1,customer_no1,chnnel_customer_no1,pay_type,'1',trad_money1);

            set this_tx_money =policy_rate;
        END IF ;
        
        END IF ;
        IF tx_money1=deduct_single_fee1 THEN 
             INSERT INTO agent_account_details(serial_no,agent_no,amount,set_date,set_time,product_no,account_type,act_rim,device_no,customer_no,chnnel_customer_no,trade_type,source_flag,trade_money)VALUES(
            trad_serial_no1,b_agent_no,'0',CURDATE(),CURTIME(),product,'0','使用单笔手续费抵扣卷',device1,customer_no1,chnnel_customer_no1,pay_type,'1',trad_money1); 
        END IF ;
        END IF;
        	UNTIL stop_flag = 1
			END REPEAT;
			CLOSE search_agents_policys_cursor;
	  	IF t_error= 1 THEN
			ROLLBACK;
	  	ELSE
			COMMIT;
		END IF;
END;


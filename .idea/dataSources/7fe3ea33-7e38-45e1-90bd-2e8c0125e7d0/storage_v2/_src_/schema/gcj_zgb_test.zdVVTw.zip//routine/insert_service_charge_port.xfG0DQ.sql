create
    definer = part@`%` procedure insert_service_charge_port(IN agent_no1 varchar(50), IN agent_no_test varchar(50))
BEGIN
  DECLARE e_name1 varchar(255); -- '英文名'
  DECLARE policy_type_no1 varchar(255); -- 政策类型编号
  DECLARE policy_detail_no1 varchar(255); -- 政策明细编号
  DECLARE policy_type1 int(1); -- 政策类型大类
  DECLARE e_value1 varchar(255); -- 参数值
  DECLARE add_date1 varchar(255); -- 日期
  DECLARE add_time1 varchar(255); -- 时间
  DECLARE object_no1 varchar(255); -- 对象编号
  DECLARE object_type1 varchar(255); -- 对象类型
  DECLARE product_no1 varchar(255); -- 产品编号

  DECLARE trad_serial_no1 varchar(255); -- 交易流水
  DECLARE b_agent_no varchar(255); -- 代理编号
  DECLARE device_no1 varchar(255); -- 机具编号
  DECLARE customer_no1 varchar(255); -- 商户编号
  DECLARE trade_type1 varchar(255); -- 交易类型
  DECLARE chnnel_customer_no1 varchar(255); -- 通道商户编号
  DECLARE trad_money1 varchar(255);-- 交易金额
  DECLARE total_money1 varchar(18); -- 总金额
  DECLARE deposit_amount1 varchar(18); -- 押金金额
  DECLARE stop_flag int(1) DEFAULT 0;
  DECLARE insert_service_charge_port_cursor CURSOR FOR
  (SELECT
      pdr.e_name,
      pdr.policy_type_no,
      pdr.policy_detail_no,
      pdr.policy_type,
      pdr.e_value,
      pdr.add_date,
      pdr.add_time,
      pdr.object_no,
      pdr.object_type,
      pdr.product_no
    FROM policy_detail_rim
    pdr
      LEFT JOIN policy_detail pd
        ON pdr.policy_detail_no = pd.policy_detail_no
    WHERE pdr.object_no = agent_no_test
    AND pdr.object_type = 3
    AND CONCAT(pdr.policy_type_no, "_", e_name) NOT IN (SELECT
        CONCAT(pdr.policy_type_no, "_", e_name)
      FROM policy_detail_rim
      pdr
        LEFT JOIN policy_detail pd
          ON pdr.policy_type_no = pd.policy_type_no
      WHERE pdr.object_type = 1
      AND pdr.object_no = agent_no1)
      --  ap表中政策类型，
--  ap表中政策类型，
-- SELECT ap.agent_no,ap.policy_detail_no,ap.policy_type,ap.policy_type_no,
-- ap.add_date,ap.product_no,ap.front_end_display,ap.is_show_agent
-- FROM agent_policy ap WHERE ap.agent_no='A00000007'
-- AND ap.policy_type_no 
-- NOT IN ('119','120','121','122','123','124','125','126','127','128','129','130',
-- '131','132','133','134','135','136','137','138','139','140','141','142')
-- and CONCAT(ap.policy_detail_no,'_',ap.policy_type_no) NOT IN (
-- SELECT CONCAT(ap1.policy_detail_no,'_',ap1.policy_type_no) FROM agent_policy ap1 
-- WHERE ap1.agent_no ='A00000013'
-- AND ap1.policy_type_no 
-- NOT IN ('119','120','121','122','123','124','125','126','127','128','129','130',
-- '131','132','133','134','135','136','137','138','139','140','141','142')
-- );
      );

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET stop_flag = 1;

  OPEN insert_service_charge_port_cursor;
  REPEAT
    FETCH insert_service_charge_port_cursor INTO e_name1, policy_type_no1, policy_detail_no1, policy_type1, e_value1, add_date1, add_time1, object_no1, object_type1, product_no1;

    IF stop_flag != 1 THEN
      INSERT INTO policy_detail_rim (e_name, policy_type_no, policy_detail_no, policy_type, e_value, add_date, add_time, object_no, object_type, product_no)
        VALUES (e_name1, policy_type_no1, policy_detail_no1, policy_type1, e_value1, add_date1, add_time1, agent_no1, 1, product_no1);
    END IF;

  UNTIL stop_flag = 1
  END REPEAT;
  CLOSE insert_service_charge_port_cursor;
END;


create
    definer = part@`%` procedure PAY_TRADE_DATA_AGENT(IN b_trad_date varchar(10))
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('PAY_TRADE_DATA_AGENT', 'pay2_haike', 7, 100636)/*[cr_debug.1]*/;
-- 插入变量定义
DECLARE  b_agent_no varchar(10);    -- 代理商编号
DECLARE  b_trade_num int(11) DEFAULT 0; -- '交易笔数',
DECLARE  b_trade_money varchar(15) DEFAULT '0'; -- '总交易数'
DECLARE  b_all_device_num int(11) DEFAULT 0; -- 总机器数(已激活)
DECLARE  b_trade_device_num int(11) DEFAULT 0; -- '当日交易终端数'
DECLARE  b_new_device int(7) DEFAULT 0; -- '新增终端个数'
DECLARE  b_swipe_credit_amt varchar(15) DEFAULT '0'; -- '刷卡信用卡T1'
DECLARE  b_swipe_credit0_amt varchar(15) DEFAULT '0'; -- '信用卡刷卡D0'
DECLARE  b_alipay_amt varchar(15) DEFAULT '0'; -- '支付宝T1'
DECLARE  b_alipay0_amt varchar(15) DEFAULT '0'; -- '支付宝D0'
DECLARE  b_swipe_debit_amt varchar(15) DEFAULT '0'; -- '储蓄刷卡T1'
DECLARE  b_swipe_debit0_amt varchar(15) DEFAULT '0'; -- '储蓄卡D0'
DECLARE  b_wechat_amt varchar(15) DEFAULT '0'; -- '微信T1'
DECLARE  b_wechat0_amt varchar(15) DEFAULT '0'; -- '微信D0'
DECLARE  b_quickpass_amt varchar(15) DEFAULT '0'; -- '云闪付T1'
DECLARE  b_quickpass0_amt varchar(15) DEFAULT '0'; -- '云闪付D0'
  DECLARE  b_preferred_credit_pay varchar(15) DEFAULT '0'; -- '优选付贷记卡T1'
  DECLARE  b_preferred_credit0_pay varchar(15) DEFAULT '0'; -- '优选付贷记卡D0'
  DECLARE  b_preferred_deposit_pay varchar(15) DEFAULT '0'; -- '优选付借记卡T1'
  DECLARE  b_preferred_deposit0_pay varchar(15) DEFAULT '0'; -- '优选付借记卡D0'
-- 游标相关定义 
DECLARE stopflg int DEFAULT 0;    -- 记录游标循环是否终止 
-- 按代理，按天汇总交易，传入的trade_dates 为日期搜索条件
DECLARE grb_cursor CURSOR FOR (
SELECT SUM(ts.trad_money) AS  trad_money,agent_no,COUNT(*) AS trade_num,COUNT(DISTINCT(system_device_no)) AS trade_device_num, 
  SUM(CASE WHEN trade_type=0 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS swipe_credit_amt,
  SUM(CASE WHEN trade_type=0 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS swipe_credit0_amt,
  SUM(CASE WHEN trade_type=1 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS alipay_amt,
  SUM(CASE WHEN trade_type=1 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS alipay0_amt,
  SUM(CASE WHEN trade_type=2 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS wechat_amt,
  SUM(CASE WHEN trade_type=2 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS wechat0_amt,
  SUM(CASE WHEN trade_type=3 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS quickpass_amt,
  SUM(CASE WHEN trade_type=3 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS quickpass0_amt,
  SUM(CASE WHEN trade_type=4 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS swipe_debit_amt,
  SUM(CASE WHEN trade_type=4 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS swipe_debit0_amt,
   SUM(CASE WHEN trade_type=6 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS preferred_credit_pay,
   SUM(CASE WHEN trade_type=6 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS preferred_credit0_pay,
   SUM(CASE WHEN trade_type=10 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS preferred_deposit_pay,
   SUM(CASE WHEN trade_type=10 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS preferred_deposit0_pay
  from trad_serial ts WHERE trad_date=b_trad_date GROUP BY ts.agent_no
);                
DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('PAY_TRADE_DATA_AGENT_Handler', 'PAY_TRADE_DATA_AGENT', 'pay2_haike', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_agent_no', b_agent_no, 'varchar(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_num', b_trade_num, 'int(11)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_money', b_trade_money, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_all_device_num', b_all_device_num, 'int(11)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_device_num', b_trade_device_num, 'int(11)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_new_device', b_new_device, 'int(7)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_credit_amt', b_swipe_credit_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_credit0_amt', b_swipe_credit0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_alipay_amt', b_alipay_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_alipay0_amt', b_alipay0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_debit_amt', b_swipe_debit_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_debit0_amt', b_swipe_debit0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_wechat_amt', b_wechat_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_wechat0_amt', b_wechat0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_quickpass_amt', b_quickpass_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_quickpass0_amt', b_quickpass0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_preferred_credit_pay', b_preferred_credit_pay, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_preferred_credit0_pay', b_preferred_credit0_pay, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_preferred_deposit_pay', b_preferred_deposit_pay, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_preferred_deposit0_pay', b_preferred_deposit0_pay, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trad_date', b_trad_date, 'VARCHAR ( 10 )', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(45, 45, 39, 53, cr_stack_depth)/*[cr_debug.2]*/;
set stopflg=1;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;   -- 当无记录时，标记游标终止

CALL cr_debug.UPDATE_WATCH3('b_trad_date', b_trad_date, 'VARCHAR ( 10 )', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_agent_no', b_agent_no, 'varchar(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_num', b_trade_num, 'int(11)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_money', b_trade_money, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_all_device_num', b_all_device_num, 'int(11)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_device_num', b_trade_device_num, 'int(11)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_new_device', b_new_device, 'int(7)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_credit_amt', b_swipe_credit_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_credit0_amt', b_swipe_credit0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_alipay_amt', b_alipay_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_alipay0_amt', b_alipay0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_debit_amt', b_swipe_debit_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_debit0_amt', b_swipe_debit0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_wechat_amt', b_wechat_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_wechat0_amt', b_wechat0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_quickpass_amt', b_quickpass_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_quickpass0_amt', b_quickpass0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_preferred_credit_pay', b_preferred_credit_pay, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_preferred_credit0_pay', b_preferred_credit0_pay, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_preferred_deposit_pay', b_preferred_deposit_pay, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_preferred_deposit0_pay', b_preferred_deposit0_pay, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(2, 2, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(47, 47, 0, 16, cr_stack_depth)/*[cr_debug.2]*/;
OPEN grb_cursor;
  CALL cr_debug.TRACE(48, 105, 2, 13, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT 
    CALL cr_debug.TRACE(49, 49, 4, 341, cr_stack_depth)/*[cr_debug.2]*/;
FETCH grb_cursor INTO b_trade_money,b_agent_no,b_trade_num,b_trade_device_num,b_swipe_credit_amt,b_swipe_credit0_amt,b_alipay_amt,b_alipay0_amt,b_wechat_amt,b_wechat0_amt,b_quickpass_amt,b_quickpass0_amt,b_swipe_debit_amt,b_swipe_debit0_amt,b_preferred_credit_pay,b_preferred_credit0_pay,b_preferred_deposit_pay,b_preferred_deposit0_pay;
CALL cr_debug.UPDATE_WATCH3('b_trade_money', b_trade_money, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_agent_no', b_agent_no, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_num', b_trade_num, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_device_num', b_trade_device_num, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_credit_amt', b_swipe_credit_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_credit0_amt', b_swipe_credit0_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_alipay_amt', b_alipay_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_alipay0_amt', b_alipay0_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_wechat_amt', b_wechat_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_wechat0_amt', b_wechat0_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_quickpass_amt', b_quickpass_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_quickpass0_amt', b_quickpass0_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_debit_amt', b_swipe_debit_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_debit0_amt', b_swipe_debit0_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_preferred_credit_pay', b_preferred_credit_pay, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_preferred_credit0_pay', b_preferred_credit0_pay, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_preferred_deposit_pay', b_preferred_deposit_pay, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_preferred_deposit0_pay', b_preferred_deposit0_pay, '', cr_stack_depth)/*[cr_debug.1]*/;    --   游标变量按序填充
      CALL cr_debug.TRACE(50, 103, 6, 13, cr_stack_depth)/*[cr_debug.2]*/;
IF stopflg != 1 THEN      -- 如果游标没有结束
         CALL cr_debug.TRACE(51, 51, 9, 213, cr_stack_depth)/*[cr_debug.2]*/;
SELECT COUNT(*) AS all_device_num,SUM(CASE WHEN add_date=b_trad_date THEN 1 ELSE 0 END) AS new_device INTO b_all_device_num,b_new_device  FROM device WHERE agent_no=b_agent_no AND customer_no is NOT NULL;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_all_device_num', b_all_device_num, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_new_device', b_new_device, '', cr_stack_depth)/*[cr_debug.1]*/;
         CALL cr_debug.TRACE(52, 54, 9, 16, cr_stack_depth)/*[cr_debug.2]*/;
IF b_new_device IS NULL THEN
           CALL cr_debug.TRACE(53, 53, 11, 31, cr_stack_depth)/*[cr_debug.2]*/;
set b_new_device=0 ;
CALL cr_debug.UPDATE_WATCH3('b_new_device', b_new_device, '', cr_stack_depth)/*[cr_debug.1]*/; 
         END IF;
         CALL cr_debug.TRACE(55, 102, 9, 16, cr_stack_depth)/*[cr_debug.2]*/;
INSERT INTO trade_date_agent( 
              agent_no,
              trade_date,
              trade_num,
              trade_money,
              all_device_num,
              trade_device_num,
              new_device,
              swipe_credit_amt,
              swipe_credit0_amt,
              alipay_amt,
              alipay0_amt,
              swipe_debit_amt,
              swipe_debit0_amt,
              wechat_amt,
              wechat0_amt,
              quickpass_amt,
              quickpass0_amt,
              preferred_credit_pay,
              preferred_credit0_pay,
              preferred_deposit_pay,
              preferred_deposit0_pay,
              direct_customer
              )
              VALUES(
                b_agent_no,
                b_trad_date,
                b_trade_num,
                b_trade_money,
                b_all_device_num,
                b_trade_device_num,
                b_new_device,
                b_swipe_credit_amt,
                b_swipe_credit0_amt,
                b_alipay_amt,
                b_alipay0_amt,
                b_swipe_debit_amt,
                b_swipe_debit0_amt,
                b_wechat_amt,
                b_wechat0_amt,
                b_quickpass_amt,
                b_quickpass0_amt,
                b_preferred_credit_pay,
                b_preferred_credit0_pay,
                b_preferred_deposit_pay,
                b_preferred_deposit0_pay,
                1
              );
CALL cr_debug.UPDATE_SYSTEM_CALLS(102)/*[cr_debug.1]*/;
      END IF;
    UNTIL stopflg = 1
  END REPEAT;
  
CALL cr_debug.TRACE(107, 107, 0, 17, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE grb_cursor;
CALL cr_debug.TRACE(108, 108, 0, 7, cr_stack_depth)/*[cr_debug.2]*/;
COMMIT;
CALL cr_debug.TRACE(109, 109, 0, 3, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


create
    definer = part@`%` procedure tx_test() comment '交易分润，实时显示交易数据，提现手续费分润'
BEGIN
  DECLARE count_details int DEFAULT 0;-- 明细表中是否存在
	DECLARE policytype_device INT; -- 终端政策类型编号
	DECLARE procduct_flag INT; -- 商品标志 3表示POS，4表示电签
	DECLARE product VARCHAR(50);
	DECLARE stopflg INT DEFAULT 0;
	DECLARE pay_name VARCHAR(50);
	DECLARE pay_type int(10);
	DECLARE trade_status1 INT(10);
	DECLARE trad_serial_no1 VARCHAR(255); -- 流水编号
 	DECLARE agent_no1 varchar(50); 	
  DECLARE trad_money1 VARCHAR(50); -- organ_reward
  DECLARE organ_reward_policy VARCHAR(50);
  DECLARE tx_money1 decimal(15,2); -- 提现费
	DECLARE date_cursor CURSOR  FOR(
			SELECT trad_serial_no,trade_type,product_no,withdraw_fee,agent_no,trad_money FROM trad_serial WHERE  
	(product_no = 'P00000002' OR product_no = 'P00000001' 
	OR product_no='P00000003' OR product_no='P00000004'
	OR product_no='P00000005'OR product_no='P00000006'
	OR product_no='P00000007' OR product_no='P00000008'
	OR product_no='P00000009' OR product_no='P00000010'
	OR product_no='P00000011' OR product_no='P00000012'
  OR product_no='P00000013' OR product_no='P00000014'
) AND company_no='P02' 
	AND trade_status = 0 AND trade_type !=5
	);
	DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
		OPEN date_cursor; -- 打开游标
			REPEAT
				FETCH date_cursor INTO trad_serial_no1,pay_type,product,tx_money1,agent_no1,trad_money1;
				IF(stopflg != 1) THEN	
            SELECT COUNT(1) FROM agent_account_details aad WHERE aad.serial_no=trad_serial_no1 AND aad.act_rim='交易分润' INTO count_details;
						IF pay_type = '0' OR pay_type='4' OR pay_type='6' OR pay_type ='8' OR pay_type ='9' OR pay_type ='10' THEN 
							SET pay_name = 'trad_rate';
						ELSE 
							SET pay_name = 'qr_code';
						END IF; 
						IF product = 'P00000001' THEN -- 电签
							SET procduct_flag = '11';
							SET policytype_device = '14';
                   set organ_reward_policy ='120';
						ELSEIF product = 'P00000002' THEN
							SET policytype_device='7';
							SET procduct_flag = '4';
                   set organ_reward_policy ='119';
						ELSEIF product ='P00000003' THEN
							SET policytype_device='27';
							SET procduct_flag = '28';
                   set organ_reward_policy ='121';
						ELSEIF product ='P00000004' THEN
							SET policytype_device='34';
							SET procduct_flag = '32';
                   set organ_reward_policy ='122';
						ELSEIF product ='P00000005' THEN
							SET policytype_device='40';
							SET procduct_flag = '38';
                   set organ_reward_policy ='123';
						ELSEIF product ='P00000006' THEN
							SET policytype_device='53';
							SET procduct_flag = '54';
                   set organ_reward_policy ='124';
						ELSEIF product ='P00000007' THEN
							SET policytype_device='86';
							SET procduct_flag = '84';
                   set organ_reward_policy ='128';
						ELSEIF product ='P00000008' THEN
							SET policytype_device='92';
							SET procduct_flag = '90';
                   set organ_reward_policy ='129';
						ELSEIF product ='P00000009' THEN
							SET policytype_device='105';
							SET procduct_flag = '106';
                   set organ_reward_policy ='130';
						ELSEIF product ='P00000010' THEN
							SET policytype_device='60';
							SET procduct_flag = '58';
                   set organ_reward_policy ='125';
						ELSEIF product ='P00000011' THEN
							SET policytype_device='66';
							SET procduct_flag = '64';
                   set organ_reward_policy ='126';
						ELSEIF product ='P00000012' THEN
							SET policytype_device='79';
							SET procduct_flag = '80';
                   set organ_reward_policy ='127';
            ELSEIF product ='P00000013' THEN
							SET policytype_device='108';
							SET procduct_flag = '111';
            ELSEIF product ='P00000014' THEN
							SET policytype_device='113';
							SET procduct_flag = '118';
						END IF;
--             CALL Today_Sum_Moneyint(trad_serial_no1);  -- 实时交易数据存储过程
--             IF count_details = 0 THEN
-- 					    CALL profit_share(trad_serial_no1,pay_name,procduct_flag,policytype_device,tx_money1); -- 调用结算分润存储过程
--             END IF;
--           IF tx_money1!=0 THEN
--               SET pay_name = 'tx_money';
--               CALL profit_share_tx(trad_serial_no1,pay_name,procduct_flag,product,tx_money1,agent_no1);
--             END IF;
             IF pay_type='0' OR pay_type='6' OR pay_type='9' then
              CALL prot_organ_reward(trad_serial_no1,organ_reward_policy,product,trad_money1,agent_no1);
              END IF;
				END IF;
			UNTIL stopflg =1
			END REPEAT;
		CLOSE date_cursor;	-- 关闭游标
END;


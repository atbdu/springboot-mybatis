create
    definer = part@`%` procedure terminal_activaty_policy_30()
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('terminal_activaty_policy_30', 'pay2.0s', 7, 100636)/*[cr_debug.1]*/;
				DECLARE stopflg INT DEFAULT 0;
				DECLARE device_no1 VARCHAR(50);-- 终端编号
				DECLARE agent_no1  VARCHAR(50); -- 直属代理商编号
				DECLARE trad_money1 DECIMAL(18,2);
				DECLARE bind_time1 INT DEFAULT 0;
				DECLARE date_cursor CURSOR  FOR(
				SELECT device.agent_no,device.device_no,SUM(trad_money),DATEDIFF(CURDATE(),device.bind_time) AS bind_date
				FROM trad_serial LEFT JOIN device on device.device_no = trad_serial.device_no 
				GROUP BY device.device_no,device.reward_status HAVING device.device_no is not null AND device.reward_status = '0'  
				AND bind_date <=30 
		);
		DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('terminal_activaty_policy_30_Handler', 'terminal_activaty_policy_30', 'pay2.0s', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, 'DECIMAL(18,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('bind_time1', bind_time1, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(14, 14, 41, 55, cr_stack_depth)/*[cr_debug.2]*/;
set stopflg=1;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;   -- 当无记录时，标记游标终止
			CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, 'DECIMAL(18,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('bind_time1', bind_time1, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(2, 2, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(15, 15, 3, 20, cr_stack_depth)/*[cr_debug.2]*/;
OPEN date_cursor; -- 打开游标
				CALL cr_debug.TRACE(16, 25, 4, 15, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT
					CALL cr_debug.TRACE(17, 17, 5, 72, cr_stack_depth)/*[cr_debug.2]*/;
FETCH date_cursor INTO agent_no1,device_no1,trad_money1,bind_time1;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('bind_time1', bind_time1, '', cr_stack_depth)/*[cr_debug.1]*/;
					CALL cr_debug.TRACE(18, 23, 5, 12, cr_stack_depth)/*[cr_debug.2]*/;
IF(stopflg != 1) THEN	
							CALL cr_debug.TRACE(19, 22, 7, 14, cr_stack_depth)/*[cr_debug.2]*/;
IF bind_time1 <= 30 AND trad_money1 >=500 THEN -- 激活
									CALL cr_debug.TRACE(20, 20, 9, 55, cr_stack_depth)/*[cr_debug.2]*/;
CALL fetch_agent_profit(agent_no1,device_no1);
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/; -- 给每一级代理按政策奖励
									CALL cr_debug.TRACE(21, 21, 9, 73, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE device SET reward_status =1 WHERE device_no = device_no1;
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/; -- 改变机器的奖惩状态
							END IF;
					END IF;
				UNTIL stopflg =1
				END REPEAT;
			CALL cr_debug.TRACE(26, 26, 3, 21, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE date_cursor;	-- 关闭游标
		CALL cr_debug.TRACE(27, 27, 2, 5, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


create
    definer = part@`%` procedure fetch_trad_serial_deposit() comment '单独刷押金交易'
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('fetch_trad_serial_deposit', 'gcj_zgb_test', 7, 100636)/*[cr_debug.1]*/;
  DECLARE t_error integer DEFAULT 0;  -- 定义错误标识 
  DECLARE trad_serial_no1 varchar(50);
  DECLARE stopflg int DEFAULT 0;
  DECLARE agent_no1 varchar(50);
  DECLARE device_no1 varchar(50);
  DECLARE customer_no1 varchar(50);
  DECLARE chnnel_customer_no1 varchar(50);
  DECLARE product_no1 varchar(50);
  DECLARE trade_type1 varchar(50);
  DECLARE agent_now varchar(50);
  DECLARE source_flag1 int DEFAULT 10;
  DECLARE count_details int DEFAULT 0;
  DECLARE trad_money1 decimal(15, 2);
  DECLARE new_money1 decimal(15, 2); -- 生成返现的金额
  DECLARE trade_date1 varchar(50);
  DECLARE trade_time1 varchar(50);
  DECLARE success int;
  DECLARE date_cursor CURSOR FOR
  ( -- 终端激活SELECT * FROM agent_agent aa WHERE aa.agent_no='A00000038'
    SELECT
      trad_serial_no,
      agent_no,
      device_no,
      customer_no,
      chnnel_customer_no,
      product_no,
      trade_type,
      trad_money,
      trad_date,
      trad_time
    FROM trad_serial
    WHERE trade_status = 0
    AND trade_type = 5);
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('fetch_trad_serial_deposit_Handler', 'fetch_trad_serial_deposit', 'gcj_zgb_test', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, 'integer', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('customer_no1', customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_type1', trade_type1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_now', agent_now, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('source_flag1', source_flag1, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('new_money1', new_money1, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_date1', trade_date1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_time1', trade_time1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('success', success, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(37, 37, 44, 60, cr_stack_depth)/*[cr_debug.2]*/;
SET t_error = 1;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END; -- 发现sql异常设置为1
  DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('fetch_trad_serial_deposit_Handler', 'fetch_trad_serial_deposit', 'gcj_zgb_test', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, 'integer', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('customer_no1', customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_type1', trade_type1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_now', agent_now, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('source_flag1', source_flag1, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('new_money1', new_money1, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_date1', trade_date1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_time1', trade_time1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('success', success, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(38, 38, 41, 57, cr_stack_depth)/*[cr_debug.2]*/;
SET stopflg = 1;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;   -- 当无记录时，标记游标终止

  -- 事务开始
  CALL cr_debug.UPDATE_WATCH3('t_error', t_error, 'integer', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('customer_no1', customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_type1', trade_type1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_now', agent_now, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('source_flag1', source_flag1, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('new_money1', new_money1, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_date1', trade_date1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_time1', trade_time1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('success', success, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(3, 3, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(41, 41, 2, 20, cr_stack_depth)/*[cr_debug.2]*/;
START TRANSACTION;
    CALL cr_debug.TRACE(42, 42, 4, 21, cr_stack_depth)/*[cr_debug.2]*/;
OPEN date_cursor; -- 打开游标
    CALL cr_debug.TRACE(43, 74, 4, 15, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT
      CALL cr_debug.TRACE(44, 44, 6, 168, cr_stack_depth)/*[cr_debug.2]*/;
FETCH date_cursor INTO  trad_serial_no1,agent_now, device_no1, customer_no1, chnnel_customer_no1, product_no1, trade_type1, trad_money1, trade_date1, trade_time1;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('agent_now', agent_now, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('customer_no1', customer_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trade_type1', trade_type1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trade_date1', trade_date1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trade_time1', trade_time1, '', cr_stack_depth)/*[cr_debug.1]*/;

      CALL cr_debug.TRACE(46, 72, 6, 13, cr_stack_depth)/*[cr_debug.2]*/;
IF (stopflg != 1) THEN
        CALL cr_debug.TRACE(47, 51, 8, 58, cr_stack_depth)/*[cr_debug.2]*/;
SELECT
          COUNT(1)
        FROM agent_account_details
        WHERE device_no = device_no1
        AND source_flag = source_flag1 INTO count_details;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, '', cr_stack_depth)/*[cr_debug.1]*/;
        CALL cr_debug.TRACE(52, 67, 8, 15, cr_stack_depth)/*[cr_debug.2]*/;
IF count_details = 0 THEN
          CALL cr_debug.TRACE(53, 65, 10, 17, cr_stack_depth)/*[cr_debug.2]*/;
IF product_no1 = 'P00000001' THEN
            CALL cr_debug.TRACE(54, 58, 12, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF trad_money1 = 99 THEN
              CALL cr_debug.TRACE(55, 55, 14, 93, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_deposit_policy(device_no1,7,product_no1,trad_money1,trade_type1);
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trade_type1', trade_type1, '', cr_stack_depth)/*[cr_debug.1]*/;
            ELSEIF trad_money1=199 THEN
              CALL cr_debug.TRACE(57, 57, 14, 93, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_deposit_policy(device_no1,8,product_no1,trad_money1,trade_type1);
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trade_type1', trade_type1, '', cr_stack_depth)/*[cr_debug.1]*/;
            END IF;
          ELSEIF product_no1='P00000002' THEN 
            CALL cr_debug.TRACE(60, 64, 12, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF trad_money1 = 299 THEN
              CALL cr_debug.TRACE(61, 61, 14, 94, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_deposit_policy(device_no1,15,product_no1,trad_money1,trade_type1);
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trade_type1', trade_type1, '', cr_stack_depth)/*[cr_debug.1]*/;
            ELSEIF trad_money1=399 THEN
              CALL cr_debug.TRACE(63, 63, 14, 94, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_deposit_policy(device_no1,16,product_no1,trad_money1,trade_type1);
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trade_type1', trade_type1, '', cr_stack_depth)/*[cr_debug.1]*/;
            END IF;       
          END IF;

        END IF;
          CALL cr_debug.TRACE(68, 68, 10, 144, cr_stack_depth)/*[cr_debug.2]*/;
SELECT COUNT(1) FROM agent_account_details aad WHERE aad.device_no=device_no1 AND source_flag=source_flag1 LIMIT 1 INTO count_details;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, '', cr_stack_depth)/*[cr_debug.1]*/;
          CALL cr_debug.TRACE(69, 71, 10, 17, cr_stack_depth)/*[cr_debug.2]*/;
IF count_details = 1 THEN
            CALL cr_debug.TRACE(70, 70, 12, 96, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE trad_serial ts SET ts.trade_status=1 WHERE ts.trad_serial_no=trad_serial_no1;
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/;
          END IF;
      END IF;
    UNTIL stopflg = 1
    END REPEAT;
    CALL cr_debug.TRACE(75, 75, 4, 22, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE date_cursor;	-- 关闭游标
    -- 判断错误状态，决定是否回滚
    CALL cr_debug.TRACE(77, 81, 4, 9, cr_stack_depth)/*[cr_debug.2]*/;
IF t_error = 1 THEN
      CALL cr_debug.TRACE(78, 78, 6, 15, cr_stack_depth)/*[cr_debug.2]*/;
ROLLBACK;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, 'integer', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('customer_no1', customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trade_type1', trade_type1, 'varchar(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('agent_now', agent_now, 'varchar(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('source_flag1', source_flag1, 'int', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, 'int', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('new_money1', new_money1, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trade_date1', trade_date1, 'varchar(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trade_time1', trade_time1, 'varchar(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('success', success, 'int', cr_stack_depth)/*[cr_debug.1]*/;
    ELSE
    CALL cr_debug.TRACE(80, 80, 4, 11, cr_stack_depth)/*[cr_debug.2]*/;
COMMIT;
  END IF;
CALL cr_debug.TRACE(82, 82, 0, 3, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


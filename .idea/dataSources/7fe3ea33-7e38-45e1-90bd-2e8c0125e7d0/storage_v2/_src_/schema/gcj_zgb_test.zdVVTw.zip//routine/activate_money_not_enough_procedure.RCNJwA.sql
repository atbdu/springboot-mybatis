create
    definer = part@`%` procedure activate_money_not_enough_procedure(IN agent_no1 varchar(50), IN device_no1 varchar(50))
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('activate_money_not_enough_procedure', 'pay2.0s', 7, 100636)/*[cr_debug.1]*/;
	DECLARE total_money DECIMAL(18,2) DEFAULT 0;
	DECLARE activate_cash_punish DECIMAL(15,2) DEFAULT 0; -- 伪激活扣除金额
	DECLARE activate_jifen_punish DECIMAL(15,2) DEFAULT 0; -- 伪激活扣除积分
	CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('total_money', total_money, 'DECIMAL(18,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('activate_cash_punish', activate_cash_punish, 'DECIMAL(15,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('activate_jifen_punish', activate_jifen_punish, 'DECIMAL(15,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(2, 2, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(6, 7, 1, 135, cr_stack_depth)/*[cr_debug.2]*/;
SELECT pdr.e_value FROM device d LEFT JOIN policy_detail_rim pdr ON 
	d.policy_type_no=pdr.policy_type_no WHERE pdr.object_no=agent_no1 AND pdr.e_name = 'swip_card_punish_money' INTO activate_cash_punish;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('activate_cash_punish', activate_cash_punish, '', cr_stack_depth)/*[cr_debug.1]*/;
		
	CALL cr_debug.TRACE(9, 10, 1, 136, cr_stack_depth)/*[cr_debug.2]*/;
SELECT pdr.e_value FROM device d LEFT JOIN policy_detail_rim pdr ON 
	d.policy_type_no=pdr.policy_type_no WHERE pdr.object_no=agent_no1 AND pdr.e_name = 'swip_card_punish_jifen' INTO activate_jifen_punish;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('activate_jifen_punish', activate_jifen_punish, '', cr_stack_depth)/*[cr_debug.1]*/;


	CALL cr_debug.TRACE(13, 13, 1, 117, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE agent_account SET total_amt = total_amt+activate_cash_punish WHERE agent_no = agent_no1 AND account_type='1';
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/;
	CALL cr_debug.TRACE(14, 14, 1, 120, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE agent_account SET total_amt = total_amt + activate_jifen_punish WHERE agent_no = agent_no1 AND account_type='2';
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/;
	-- 伪激活扣除金额
	CALL cr_debug.TRACE(16, 18, 1, 128, cr_stack_depth)/*[cr_debug.2]*/;
INSERT INTO `agent_account_details` 
							(`serial_no`, `agent_no`, `amount`, `set_date`, `set_time`, `account_type`, `product_no`, `act_rim`) 
							VALUES (device_no1, agent_no1, activate_cash_punish, CURDATE(), CURTIME(), '1', 'P00000002', 'POS机入网90天刷卡交易不足10000扣除金额');
CALL cr_debug.UPDATE_SYSTEM_CALLS(102)/*[cr_debug.1]*/;
		-- 伪激活扣除积分
		CALL cr_debug.TRACE(20, 22, 2, 129, cr_stack_depth)/*[cr_debug.2]*/;
INSERT INTO `agent_account_details` 
							(`serial_no`, `agent_no`, `amount`, `set_date`, `set_time`, `account_type`, `product_no`, `act_rim`) 
							VALUES (device_no1, agent_no1, activate_jifen_punish, CURDATE(), CURTIME(), '2', 'P00000002', 'POS机入网90天刷卡交易不足10000扣除积分');
CALL cr_debug.UPDATE_SYSTEM_CALLS(102)/*[cr_debug.1]*/;
CALL cr_debug.TRACE(23, 23, 0, 3, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


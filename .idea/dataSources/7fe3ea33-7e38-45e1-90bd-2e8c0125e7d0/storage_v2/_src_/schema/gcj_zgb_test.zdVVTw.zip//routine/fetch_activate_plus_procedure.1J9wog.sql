create
    definer = part@`%` procedure fetch_activate_plus_procedure() comment 'PLUS激活达标三阶段奖励'
BEGIN
	DECLARE stopflg INT DEFAULT 0;
	DECLARE device_no1 VARCHAR(50);
	DECLARE product_no1 VARCHAR(50);
	DECLARE reward_status1 INT(2);
	DECLARE reward_type1 INT DEFAULT 1; -- 激活奖励
	DECLARE reward_type2 INT DEFAULT 2;-- 二月达标奖励
	DECLARE reward_type3 INT DEFAULT 3;-- 三月达标奖励
	DECLARE date_cursor CURSOR  FOR( -- 终端激活
			SELECT device_no,reward_status,product_no FROM device WHERE reward_status !=2 AND reward_status !=4  AND (product_no='P00000003' 
      OR product_no='P00000012' OR  product_no='P00000020' OR product_no='P00000021')
	);
	DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
		OPEN date_cursor; -- 打开游标
			REPEAT
				FETCH date_cursor INTO device_no1,reward_status1,product_no1;				
				IF(stopflg != 1) THEN	
						IF reward_status1=0 THEN
							CALL activate_plus_procedure(device_no1,product_no1);
						ELSEIF reward_status1=1 THEN
							CALL activate_plus_procedure(device_no1,product_no1);
						ELSEIF reward_status1=3 THEN
							CALL activate_plus_procedure(device_no1,product_no1);
						END IF;
				END IF;
			UNTIL stopflg =1
			END REPEAT;
		CLOSE date_cursor;	-- 关闭游标
END;


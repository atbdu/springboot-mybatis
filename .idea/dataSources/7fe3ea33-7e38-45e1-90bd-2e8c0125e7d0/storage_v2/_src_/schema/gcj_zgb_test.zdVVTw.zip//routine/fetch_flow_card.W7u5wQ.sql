create
    definer = part@`%` procedure fetch_flow_card() comment '流量费'
BEGIN
  DECLARE count_details int DEFAULT 0; -- 记录明细表中的机具对应数量
	DECLARE product_no1 VARCHAR(50);
	DECLARE agent_no1 VARCHAR(50);
	DECLARE stopflg INT DEFAULT 0;
	DECLARE policy_type INT; -- 政策类型编号
	DECLARE device_no1 varchar(50);
	DECLARE date_cursor CURSOR  FOR( -- 流量卡代理及政策
		SELECT d.agent_no,d.product_no,d.device_no FROM device d LEFT JOIN device_flow_card dc 
		ON d.device_no=dc.device_no WHERE d.bind_time is not null and (dc.flow_card_status=0 OR(dc.flow_card_status=1 
		AND (dc.flow_card_date IS NULL OR YEAR(dc.flow_card_date)!=YEAR(CURDATE()))))
	);
	DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
		OPEN date_cursor; -- 打开游标
			REPEAT
				FETCH date_cursor INTO agent_no1,product_no1,device_no1;
				
				IF(stopflg != 1) THEN	
						IF product_no1='P00000001' THEN 
								SET policy_type = '13';
						ELSEIF product_no1='P00000002' THEN 
								SET policy_type = '6';
            ELSEIF product_no1='P00000004' THEN 
								SET policy_type = '33';
            ELSEIF product_no1='P00000005' THEN 
								SET policy_type = '39';
            ELSEIF product_no1='P00000010' THEN 
								SET policy_type = '59';
            ELSEIF product_no1='P00000011' THEN 
								SET policy_type = '65';
            ELSEIF product_no1='P00000007' THEN 
								SET policy_type = '85';
            ELSEIF product_no1='P00000008' THEN 
								SET policy_type = '91';
            ELSEIF product_no1='P00000013' THEN 
								SET policy_type = '109';
            ELSEIF product_no1='P00000044' THEN 
								SET policy_type = '114';
						END IF;
            -- 查询是不是存在记录
            SELECT COUNT(1) FROM agent_account_details WHERE serial_no=device_no1 AND act_rim='流量卡分润' 
            AND year(set_date) = year(set_date) LIMIT 1 INTO  count_details;
						-- IF policy_type IS NOT NULL THEN 
             --  IF count_details = 0 THEN
              
							  -- CALL flow_card_profit(agent_no1,policy_type,device_no1);
              -- END IF;
						-- END IF;
				END IF;
			UNTIL stopflg =1
			END REPEAT;
		CLOSE date_cursor;	-- 关闭游标
	END;


create
    definer = part@`%` procedure Today_Sum_Moneyint(IN b_trad_serial_no varchar(50))
BEGIN
  DECLARE b_agent_no varchar(10);    -- 代理商编号
  DECLARE b_trade_num int(11) DEFAULT 0; -- '交易笔数',
  DECLARE b_trade_money varchar(15) DEFAULT '0'; -- '总交易数'
  DECLARE b_parent_no varchar(30);    -- 1级代理商编号
  DECLARE b_trad_date varchar(30);    -- 交易时间
  DECLARE b_all_device_num int(11) DEFAULT 0; -- 总机器数(已激活)
  DECLARE b_trade_device_num int(11) DEFAULT 0; -- '当日交易终端数'
  DECLARE b_new_device int(7) DEFAULT 0; -- '新增终端个数'
  DECLARE b_swipe_credit_amt varchar(15) DEFAULT '0'; -- '刷卡信用卡T1'
  DECLARE b_swipe_credit0_amt varchar(15) DEFAULT '0'; -- '信用卡刷卡D0'
  DECLARE b_alipay_amt varchar(15) DEFAULT '0'; -- '支付宝T1'
  DECLARE b_alipay0_amt varchar(15) DEFAULT '0'; -- '支付宝D0'
  DECLARE b_swipe_debit_amt varchar(15) DEFAULT '0'; -- '储蓄刷卡T1'
  DECLARE b_swipe_debit0_amt varchar(15) DEFAULT '0'; -- '储蓄卡D0'
  DECLARE b_wechat_amt varchar(15) DEFAULT '0'; -- '微信T1'
  DECLARE b_wechat0_amt varchar(15) DEFAULT '0'; -- '微信D0'
  DECLARE b_quickpass_amt varchar(15) DEFAULT '0'; -- '云闪付T1'
  DECLARE b_quickpass0_amt varchar(15) DEFAULT '0'; -- '云闪付D0'
  DECLARE  b_preferred_credit_pay varchar(15) DEFAULT '0'; -- '优选付贷记卡T1'
  DECLARE  b_preferred_credit0_pay varchar(15) DEFAULT '0'; -- '优选付贷记卡D0'
  DECLARE  b_preferred_deposit_pay varchar(15) DEFAULT '0'; -- '优选付借记卡T1'
  DECLARE  b_preferred_deposit0_pay varchar(15) DEFAULT '0'; -- '优选付借记卡D0'
  DECLARE b_company_no varchar(3) DEFAULT NULL; --  支付公司编号
  DECLARE b_product_no varchar(15) DEFAULT NULL; --  产品编号
  DECLARE this_agent_no varchar(30); --  当前直属代理
  DECLARE b_is_agent_no varchar(30); --  表中是否有当前代理    
  DECLARE b_is_direct_customer int(1); --  表中是否是直营 
   DECLARE b_ts_parent_no varchar(30); --  当前交易的代理上级 
  DECLARE b_ts_agent_no varchar(30); --  当前交易的代理     
  DECLARE b_is_trad_date varchar(30); --  是否有当前时间
    DECLARE b_is_product_no varchar(30); --  是否有当前产品                
  DECLARE stopflg int DEFAULT 0;    -- 记录游标循环是否终止 

  DECLARE grb_cursor CURSOR FOR
  (SELECT
      ts.trad_money,
      ts.agent_no,
      (SELECT
          parent_no
        FROM agent_agent
        WHERE agent_no = ts.agent_no LIMIT 1) AS parent_no,
        ts.trad_date,
      COUNT(*) AS trade_num,
      product_no,
      MAX(ts.company_no) AS company_no,
      COUNT(DISTINCT (system_device_no)) AS trade_device_num,
      (CASE WHEN trade_type = 0 AND
          is_timely = 0 THEN ts.trad_money ELSE 0 END) AS swipe_credit_amt,
      (CASE WHEN trade_type = 0 AND
          is_timely = 1 THEN ts.trad_money ELSE 0 END) AS swipe_credit0_amt,
      (CASE WHEN trade_type = 1 AND
          is_timely = 0 THEN ts.trad_money ELSE 0 END) AS alipay_amt,
      (CASE WHEN trade_type = 1 AND
          is_timely = 1 THEN ts.trad_money ELSE 0 END) AS alipay0_amt,
      (CASE WHEN trade_type = 2 AND
          is_timely = 0 THEN ts.trad_money ELSE 0 END) AS wechat_amt,
      (CASE WHEN trade_type = 2 AND
          is_timely = 1 THEN ts.trad_money ELSE 0 END) AS wechat0_amt,
      (CASE WHEN trade_type = 3 AND
          is_timely = 0 THEN ts.trad_money ELSE 0 END) AS quickpass_amt,
      (CASE WHEN trade_type = 3 AND
          is_timely = 1 THEN ts.trad_money ELSE 0 END) AS quickpass0_amt,
      (CASE WHEN trade_type = 4 AND
          is_timely = 0 THEN ts.trad_money ELSE 0 END) AS swipe_debit_amt,
      (CASE WHEN trade_type = 4 AND
          is_timely = 1 THEN ts.trad_money ELSE 0 END) AS swipe_debit0_amt,
  (CASE WHEN trade_type=6 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS preferred_credit_pay,
  (CASE WHEN trade_type=6 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS preferred_credit0_pay,
  (CASE WHEN trade_type=10 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS preferred_deposit_pay,
  (CASE WHEN trade_type=10 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS preferred_deposit0_pay
    FROM trad_serial ts
    WHERE trad_serial_no = b_trad_serial_no
    GROUP BY ts.agent_no,
             product_no);

  DECLARE grb_today_cursor CURSOR FOR
  (SELECT
      parent_no
    FROM agent_agent
    WHERE agent_no = b_agent_no
  --   AND agent_no != b_parent_no
   --  AND is_direct = 1
   );

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET stopflg = 1; -- 记录游标是否终止

  OPEN grb_cursor;
myloop1:
  LOOP
    FETCH grb_cursor INTO b_trade_money, b_agent_no, b_parent_no, b_trad_date,b_trade_num, b_product_no, b_company_no, b_trade_device_num, b_swipe_credit_amt, b_swipe_credit0_amt, b_alipay_amt, b_alipay0_amt, b_wechat_amt, b_wechat0_amt, b_quickpass_amt, b_quickpass0_amt, b_swipe_debit_amt, b_swipe_debit0_amt,b_preferred_credit_pay,b_preferred_credit0_pay,b_preferred_deposit_pay,b_preferred_deposit0_pay;    --   游标变量按序填充
    IF stopflg = 1 THEN -- 判断是否继续循环
      LEAVE myloop1; -- 结束循环
    END IF;

    OPEN grb_today_cursor;
  myloop2:
    LOOP
      FETCH grb_today_cursor INTO this_agent_no;
      IF stopflg = 1 THEN
        LEAVE myloop2;
      END IF;
      SELECT
        COUNT(*) AS all_device_num,
        SUM(CASE WHEN add_date = b_trad_date THEN 1 ELSE 0 END) AS new_device INTO b_all_device_num, b_new_device
      FROM device
      WHERE agent_no = this_agent_no
      AND company_no = b_company_no
      AND product_no = b_product_no
      AND customer_no IS NOT NULL;
      IF b_new_device IS NULL THEN
        SET b_new_device = 0;
      END IF;
    
       -- 当前这笔交易的代理上级编号
      set b_ts_parent_no = (SELECT aa.parent_no FROM trad_serial ts 
  LEFT JOIN agent_agent aa
  ON aa.agent_no = ts.agent_no
   WHERE trad_serial_no = b_trad_serial_no
    AND  is_direct = '1');
    -- 表中代理是否有当前时间 直营
    SET b_is_trad_date = (SELECT
          tdpa.trade_date
        FROM trade_date_pro_agent tdpa
        WHERE tdpa.trade_date = DATE_FORMAT(NOW(),'%Y-%m-%d') 
        AND tdpa.direct_customer = '1'
        AND tdpa.agent_no = this_agent_no LIMIT 1);
    --  当前这笔交易的代理
    SET b_ts_agent_no = (SELECT agent_no FROM trad_serial ts 
   WHERE trad_serial_no = b_trad_serial_no);
       -- 表中今天是否有当前代理
      SET b_is_agent_no = (SELECT
          tdpa.agent_no
        FROM trade_date_pro_agent tdpa
        WHERE tdpa.agent_no = this_agent_no 
        AND product_no = b_product_no
        AND tdpa.trade_date = DATE_FORMAT(NOW(),'%Y-%m-%d')
        LIMIT 1);
       
   
      IF    b_agent_no = this_agent_no -- (b_ts_parent_no=this_agent_no OR b_agent_no = this_agent_no OR b_parent_no = this_agent_no ) 
         AND b_is_trad_date IS NULL THEN     --  AND   b_is_agent_no IS NOT NULL
        INSERT INTO trade_date_pro_agent (company_no,
        product_no,
        agent_no,
        trade_date,
        trade_num,
        trade_money,
        all_device_num,
        trade_device_num,
        new_device,
        swipe_credit_amt,
        swipe_credit0_amt,
        alipay_amt,
        alipay0_amt,
        swipe_debit_amt,
        swipe_debit0_amt,
        wechat_amt,
        wechat0_amt,
        quickpass_amt,
        quickpass0_amt,
        preferred_credit_pay,
        preferred_credit0_pay,
        preferred_deposit_pay,
        preferred_deposit0_pay,
        direct_customer)
          VALUES (b_company_no, b_product_no, this_agent_no, NOW(), b_trade_num, b_trade_money, b_all_device_num, b_trade_device_num, b_new_device, b_swipe_credit_amt, b_swipe_credit0_amt, b_alipay_amt, b_alipay0_amt, b_swipe_debit_amt, b_swipe_debit0_amt, b_wechat_amt, b_wechat0_amt, b_quickpass_amt, b_quickpass0_amt,b_preferred_credit_pay,b_preferred_credit0_pay,b_preferred_deposit_pay,b_preferred_deposit0_pay,1);
       ELSE  
      -- (b_ts_parent_no=this_agent_no OR b_agent_no = this_agent_no  OR b_parent_no = this_agent_no) 
        IF b_trade_money IS NOT NULL  AND b_agent_no = this_agent_no THEN

          UPDATE trade_date_pro_agent
          SET trade_money = trade_money + b_trade_money,
          trade_num = trade_num +1,
          swipe_credit_amt=swipe_credit_amt+ b_swipe_credit_amt,
          swipe_credit0_amt=swipe_credit0_amt+b_swipe_credit0_amt,
          alipay_amt= alipay_amt+b_alipay_amt,
          alipay0_amt =alipay0_amt + b_alipay0_amt,
          swipe_debit_amt = swipe_debit_amt +  b_swipe_debit_amt,
          swipe_debit0_amt = swipe_debit0_amt+ b_swipe_debit0_amt,
          wechat_amt = wechat_amt + b_wechat_amt,
          wechat0_amt = wechat0_amt + b_wechat0_amt,
          quickpass_amt = quickpass_amt + b_quickpass_amt,
          quickpass0_amt = quickpass0_amt + b_quickpass0_amt,
          preferred_credit_pay = preferred_credit_pay + b_preferred_credit_pay,
          preferred_credit0_pay = preferred_credit0_pay +b_preferred_credit0_pay,
          preferred_deposit_pay = preferred_deposit_pay + b_preferred_deposit_pay,
          preferred_deposit0_pay = preferred_deposit0_pay + b_preferred_deposit0_pay,
          new_device = new_device,
          trade_device_num = b_trade_device_num
          WHERE agent_no = this_agent_no
          AND trade_date = DATE_FORMAT(NOW(),'%Y-%m-%d')
          AND product_no = b_product_no
          AND direct_customer = '1';

--       SELECT COUNT(DISTINCT(system_device_no)) AS trade_device_num INTO b_trade_device_num
--       from trad_serial ts WHERE trad_date=b_trad_date AND ts.agent_no = this_agent_no GROUP BY ts.agent_no,product_no;
--       IF b_trade_device_num IS NOT NULL THEN 
--          UPDATE trade_date_pro_agent
--           SET trade_device_num = b_trade_device_num
--           WHERE agent_no = this_agent_no
--           AND trade_date = DATE_FORMAT(NOW(),'%Y-%m-%d')
--           AND product_no = b_product_no
--           AND direct_customer = '1';
--         END IF ;

        END IF;
        END IF ;
     -- 是否直商
      SET b_is_direct_customer = (SELECT
          tdpa.direct_customer
        FROM trade_date_pro_agent tdpa
        WHERE tdpa.agent_no = this_agent_no AND 
        tdpa.trade_date = DATE_FORMAT(NOW(),'%Y-%m-%d') LIMIT 1);
  -- 表中代理是否有当前时间 机构
          SET b_is_trad_date = (SELECT
          tdpa.trade_date
        FROM trade_date_pro_agent tdpa
        WHERE tdpa.trade_date = DATE_FORMAT(NOW(),'%Y-%m-%d') 
        AND tdpa.direct_customer = '0'
        AND product_no = b_product_no
        AND tdpa.agent_no = this_agent_no LIMIT 1);
         -- 表中是否有当前产品
      SET b_is_product_no = (
      SELECT
          tdpa.product_no
        FROM trade_date_pro_agent tdpa
        WHERE tdpa.trade_date = DATE_FORMAT(NOW(),'%Y-%m-%d') 
        AND tdpa.direct_customer = '0'
        AND product_no = b_product_no
        AND tdpa.agent_no = this_agent_no LIMIT 1
      
      );
  
      IF( b_is_direct_customer IS NULL OR b_is_direct_customer = 1 OR  b_is_product_no IS NULL)
      AND    (b_ts_parent_no=this_agent_no OR b_agent_no = this_agent_no OR b_parent_no = this_agent_no ) 
      AND   b_is_trad_date IS  NULL  THEN
        INSERT INTO trade_date_pro_agent (       -- 插入数据
        product_no,
        company_no,
        agent_no,
        trade_date,
        trade_num,
        trade_money,
        all_device_num,
        trade_device_num,
        new_device,
        swipe_credit_amt,
        swipe_credit0_amt,
        alipay_amt,
        alipay0_amt,
        swipe_debit_amt,
        swipe_debit0_amt,
        wechat_amt,
        wechat0_amt,
        quickpass_amt,
        quickpass0_amt,
        preferred_credit_pay,
        preferred_credit0_pay,
        preferred_deposit_pay,
        preferred_deposit0_pay,
        direct_customer)
          VALUES (b_product_no, b_company_no, this_agent_no, NOW(), b_trade_num, b_trade_money, b_all_device_num, b_trade_device_num, b_new_device, b_swipe_credit_amt, b_swipe_credit0_amt, b_alipay_amt, b_alipay0_amt, b_swipe_debit_amt, b_swipe_debit0_amt, b_wechat_amt, b_wechat0_amt, b_quickpass_amt, b_quickpass0_amt,b_preferred_credit_pay,b_preferred_credit0_pay,b_preferred_deposit_pay,b_preferred_deposit0_pay,0);
      ELSEIF ( b_ts_parent_no=this_agent_no OR b_agent_no = this_agent_no  OR b_parent_no = this_agent_no ) 
      THEN 

        UPDATE trade_date_pro_agent
        SET trade_money = trade_money + b_trade_money,
          trade_num = trade_num +1,
         swipe_credit_amt=swipe_credit_amt+ b_swipe_credit_amt,
          swipe_credit0_amt=swipe_credit0_amt+b_swipe_credit0_amt,
          alipay_amt= alipay_amt+b_alipay_amt,
          alipay0_amt =alipay0_amt +b_alipay0_amt,
          swipe_debit_amt = swipe_debit_amt +b_swipe_debit_amt,
          swipe_debit0_amt = swipe_debit0_amt+ b_swipe_debit0_amt,
          wechat_amt = wechat_amt + b_wechat_amt,
          wechat0_amt = wechat0_amt+ b_wechat0_amt,
          quickpass_amt = quickpass_amt + b_quickpass_amt,
          quickpass0_amt = quickpass0_amt + b_quickpass0_amt,
          preferred_credit_pay = preferred_credit_pay + b_preferred_credit_pay,
          preferred_credit0_pay = preferred_credit0_pay +b_preferred_credit0_pay,
          preferred_deposit_pay = preferred_deposit_pay + b_preferred_deposit_pay,
          preferred_deposit0_pay = preferred_deposit0_pay + b_preferred_deposit0_pay,
          new_device = new_device,
          trade_device_num = b_trade_device_num
        WHERE agent_no = this_agent_no
        AND trade_date = DATE_FORMAT(NOW(),'%Y-%m-%d')
        AND product_no = b_product_no
        AND direct_customer ='0';

--       SELECT COUNT(DISTINCT(system_device_no)) AS trade_device_num INTO b_trade_device_num
--       from trad_serial ts WHERE trad_date=b_trad_date  AND ts.agent_no = this_agent_no GROUP BY ts.agent_no,product_no;
--       IF b_trade_device_num IS NOT NULL THEN 
--       UPDATE trade_date_pro_agent
--       SET trade_device_num = b_trade_device_num
--       WHERE agent_no = this_agent_no
--       AND trade_date = DATE_FORMAT(NOW(),'%Y-%m-%d')
--       AND product_no = b_product_no
--       AND direct_customer = '0';
--       END IF ;

      END IF;
    END LOOP myloop2;
    CLOSE grb_today_cursor;
    SET stopflg = 0;
    COMMIT;
  END LOOP myloop1;
  CLOSE grb_cursor;


END;


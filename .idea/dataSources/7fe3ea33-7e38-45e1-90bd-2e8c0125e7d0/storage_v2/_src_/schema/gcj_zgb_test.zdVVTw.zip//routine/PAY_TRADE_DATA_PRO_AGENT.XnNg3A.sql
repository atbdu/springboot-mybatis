create
    definer = part@`%` procedure PAY_TRADE_DATA_PRO_AGENT(IN b_trad_date varchar(10))
BEGIN
DECLARE  b_agent_no varchar(10);    -- 代理商编号
DECLARE  b_trade_num int(11) DEFAULT 0; -- '交易笔数',
DECLARE  b_trade_money varchar(15) DEFAULT '0'; -- '总交易数'
DECLARE  b_all_device_num int(11) DEFAULT 0; -- 总机器数(已激活)
DECLARE  b_trade_device_num int(11) DEFAULT 0; -- '当日交易终端数'
DECLARE  b_new_device int(7) DEFAULT 0; -- '新增终端个数'
DECLARE  b_swipe_credit_amt varchar(15) DEFAULT '0'; -- '刷卡信用卡T1'
DECLARE  b_swipe_credit0_amt varchar(15) DEFAULT '0'; -- '信用卡刷卡D0'
DECLARE  b_alipay_amt varchar(15) DEFAULT '0'; -- '支付宝T1'
DECLARE  b_alipay0_amt varchar(15) DEFAULT '0'; -- '支付宝D0'
DECLARE  b_swipe_debit_amt varchar(15) DEFAULT '0'; -- '储蓄刷卡T1'
DECLARE  b_swipe_debit0_amt varchar(15) DEFAULT '0'; -- '储蓄卡D0'
DECLARE  b_wechat_amt varchar(15) DEFAULT '0'; -- '微信T1'
DECLARE  b_wechat0_amt varchar(15) DEFAULT '0'; -- '微信D0'
DECLARE  b_quickpass_amt varchar(15) DEFAULT '0'; -- '云闪付T1'
DECLARE  b_quickpass0_amt varchar(15) DEFAULT '0'; -- '云闪付D0'
DECLARE  b_preferred_credit_pay varchar(15) DEFAULT '0'; -- '优选付贷记卡T1'
DECLARE  b_preferred_credit0_pay varchar(15) DEFAULT '0'; -- '优选付贷记卡D0'
DECLARE  b_preferred_deposit_pay varchar(15) DEFAULT '0'; -- '优选付借记卡T1'
DECLARE  b_preferred_deposit0_pay varchar(15) DEFAULT '0'; -- '优选付借记卡D0'
DECLARE  b_company_no varchar(3) DEFAULT NULL; --  支付公司编号
DECLARE  b_product_no varchar(15) DEFAULT NULL ; --  产品编号
DECLARE stopflg int DEFAULT 0;    -- 记录游标循环是否终止 
DECLARE grb_cursor CURSOR FOR (
SELECT SUM(ts.trad_money) AS  trad_money,agent_no,COUNT(*) AS trade_num,product_no,MAX(ts.company_no) AS company_no,COUNT(DISTINCT(system_device_no)) AS trade_device_num, 
  SUM(CASE WHEN trade_type=0 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS swipe_credit_amt,
  SUM(CASE WHEN trade_type=0 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS swipe_credit0_amt,
  SUM(CASE WHEN trade_type=1 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS alipay_amt,
  SUM(CASE WHEN trade_type=1 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS alipay0_amt,
  SUM(CASE WHEN trade_type=2 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS wechat_amt,
  SUM(CASE WHEN trade_type=2 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS wechat0_amt,
  SUM(CASE WHEN trade_type=3 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS quickpass_amt,
  SUM(CASE WHEN trade_type=3 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS quickpass0_amt,
  SUM(CASE WHEN trade_type=4 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS swipe_debit_amt,
  SUM(CASE WHEN trade_type=4 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS swipe_debit0_amt,
  SUM(CASE WHEN trade_type=6 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS preferred_credit_pay,
  SUM(CASE WHEN trade_type=6 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS preferred_credit0_pay,
  SUM(CASE WHEN trade_type=10 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS preferred_deposit_pay,
  SUM(CASE WHEN trade_type=10 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS preferred_deposit0_pay
  from trad_serial ts WHERE trad_date=b_trad_date GROUP BY ts.agent_no,product_no
);                
DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止

OPEN grb_cursor;
  REPEAT 
    FETCH grb_cursor INTO b_trade_money,b_agent_no,b_trade_num,b_product_no,b_company_no,b_trade_device_num,b_swipe_credit_amt,b_swipe_credit0_amt,b_alipay_amt,b_alipay0_amt,b_wechat_amt,b_wechat0_amt,b_quickpass_amt,b_quickpass0_amt,b_swipe_debit_amt,b_swipe_debit0_amt,b_preferred_credit_pay,b_preferred_credit0_pay,b_preferred_deposit_pay,b_preferred_deposit0_pay;    --   游标变量按序填充
      IF stopflg != 1 THEN      -- 如果游标没有结束
         SELECT COUNT(*) AS all_device_num,SUM(CASE WHEN add_date=b_trad_date THEN 1 ELSE 0 END) AS new_device INTO b_all_device_num,b_new_device  FROM device WHERE agent_no=b_agent_no AND company_no=b_company_no AND product_no=b_product_no AND customer_no is NOT NULL;
         IF b_new_device IS NULL THEN
           set b_new_device=0 ; 
         END IF;
         INSERT INTO trade_date_pro_agent(
              company_no,
              product_no, 
              agent_no,
              trade_date,
              trade_num,
              trade_money,
              all_device_num,
              trade_device_num,
              new_device,
              swipe_credit_amt,
              swipe_credit0_amt,
              alipay_amt,
              alipay0_amt,
              swipe_debit_amt,
              swipe_debit0_amt,
              wechat_amt,
              wechat0_amt,
              quickpass_amt,
              quickpass0_amt,
              preferred_credit_pay,
              preferred_credit0_pay,
              preferred_deposit_pay,
              preferred_deposit0_pay,
              direct_customer
              )
              VALUES(
                b_company_no,
                b_product_no, 
                b_agent_no,
                b_trad_date,
                b_trade_num,
                b_trade_money,
                b_all_device_num,
                b_trade_device_num,
                b_new_device,
                b_swipe_credit_amt,
                b_swipe_credit0_amt,
                b_alipay_amt,
                b_alipay0_amt,
                b_swipe_debit_amt,
                b_swipe_debit0_amt,
                b_wechat_amt,
                b_wechat0_amt,
                b_quickpass_amt,
                b_quickpass0_amt,
                b_preferred_credit_pay,
                b_preferred_credit0_pay,
                b_preferred_deposit_pay,
                b_preferred_deposit0_pay,
                1
              );
      END IF;
    UNTIL stopflg = 1
  END REPEAT;
CLOSE grb_cursor;
COMMIT;
END;


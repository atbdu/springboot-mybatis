create
    definer = part@`%` procedure everyone_activate300_producer(IN device_no1 varchar(50), IN agent_no1 varchar(50),
                                                               IN policytype varchar(50), IN pay_name varchar(50),
                                                               IN product_no1 varchar(50),
                                                               IN chnnel_customer_no1 varchar(50),
                                                               IN customer_no1 varchar(50), IN trade_date varchar(50),
                                                               IN trade_time varchar(50), OUT flg int)
    comment '0-300定制版激活分润'
BEGIN
	DECLARE t_error INTEGER DEFAULT 0; 
  DECLARE stopflg INT DEFAULT 0;
	DECLARE agent_now VARCHAR(50);
	DECLARE next_money DECIMAL(15,2) DEFAULT 0.00;
	DECLARE cash_reward1 DECIMAL(15,2);
  DECLARE count_detail int DEFAULT 0;
	DECLARE date_cursor CURSOR  FOR( 
			SELECT
      a.agent_no,
      pdr.e_value
    FROM policy_detail_rim pdr
      LEFT JOIN agent a
        ON pdr.object_no = a.agent_no
    WHERE pdr.policy_type_no = policytype
    AND pdr.e_name = pay_name
    AND pdr.object_no IN (SELECT
        parent_no
      FROM agent_agent
      WHERE agent_no = agent_no1)
    AND object_type = '1'
    ORDER BY a.agent_level DESC
	);
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1; -- 发现sql异常设置为1
	DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
  SELECT COUNT(1) FROM agent_account_details aad WHERE aad.device_no=device_no1 AND aad.source_flag=5 LIMIT 1 INTO count_detail;
		-- 事务开始
		START TRANSACTION;
			OPEN date_cursor; -- 打开游标
				REPEAT
					FETCH date_cursor INTO agent_now,cash_reward1;
					IF(stopflg != 1) THEN	
            
						IF cash_reward1 IS NOT NULL AND count_detail =0 THEN
								UPDATE agent_account SET wait_account = wait_account + cash_reward1-next_money
									WHERE agent_no = agent_now AND account_type = '1'; -- 服务费账户
									-- 添加记录
									INSERT INTO `agent_account_details` (`serial_no`, `agent_no`, `amount`, `set_date`, `set_time`, `account_type`, `product_no`, `act_rim`,
									device_no, customer_no, chnnel_customer_no, source_flag)
										VALUES (device_no1, agent_now, cash_reward1-next_money, trade_date, trade_time, '1', product_no1, '激活奖励', 
										device_no1, customer_no1, chnnel_customer_no1, 5);
								SET next_money = cash_reward1;
                UPDATE device d SET d.reward_status=1 WHERE d.device_no=device_no1;
						ELSE
							SET t_error=1;
						END IF;
					END IF;
				UNTIL stopflg =1
				END REPEAT;
			CLOSE date_cursor;	-- 关闭游标
		-- 判断错误状态，决定是否回滚
		 IF t_error = 1 THEN  
        SET flg = 0;  
				ROLLBACK;    
			ELSE 
        SET flg = 1;   
				COMMIT;    
			END IF;    
	END;


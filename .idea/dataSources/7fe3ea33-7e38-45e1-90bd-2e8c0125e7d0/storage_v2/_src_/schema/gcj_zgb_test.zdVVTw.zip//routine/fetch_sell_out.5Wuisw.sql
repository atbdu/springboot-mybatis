create
    definer = part@`%` procedure fetch_sell_out()
BEGIN
  DECLARE product varchar(50);
  DECLARE stop_flag int DEFAULT 0;
  DECLARE device_no1 varchar(50); -- 设备终端号
  DECLARE agent_no1 varchar(50); -- 终端直属代理
  DECLARE total_money decimal(18, 2); -- 每一个终端的贷记卡累计消费金额
  DECLARE add_date1 varchar(30); -- 机器入库时间
  DECLARE bind_time1 varchar(30); -- 商户入网时间
  DECLARE cash_pledge_status1 int(1); -- 添加时间
  DECLARE select_activite_cursor CURSOR FOR
  (
    -- 查询绑定日期小于30天，并且没有激活的终端，统计金额，同时完成奖励
    SELECT
      MAX(t1.agent_no) AS agent_no,
      t1.device_no,
      SUM(trad_money) AS total,
      MAX(t1.product_no) AS product_no,
      t1.add_date,
      t1.cash_pledge_status,
      t1.bind_time
    FROM device t1
      LEFT JOIN trad_serial t2
        ON t1.device_no = t2.device_no
    WHERE t1.reward_status = '0'
    AND trade_type = '0'
    AND t2.product_no = 'P00000003'
    GROUP BY t2.device_no);
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET stop_flag = 1;   -- 当无记录时，标记游标终止
  OPEN select_activite_cursor;
  REPEAT
    FETCH select_activite_cursor INTO agent_no1, device_no1, total_money, product, add_date1, cash_pledge_status1, bind_time1;
    IF stop_flag != 1 THEN
      IF total_money >= 500
        AND DATEDIFF(NOW(), DATE_ADD(add_date1, INTERVAL 0 MONTH)) <= 30
        AND cash_pledge_status1 = '0' THEN
        CALL PLUS_port_sell_out(device_no1, '15'); -- 计算29的分润
      ELSEIF total_money >= 5000
        AND DATEDIFF(NOW(), DATE_ADD(add_date1, INTERVAL 1 MONTH)) <= 30
        AND cash_pledge_status1 = '0' THEN
        CALL PLUS_port_sell_out(device_no1, '16'); -- 计算50的分润
      ELSEIF total_money >= 5000
        AND DATEDIFF(NOW(), DATE_ADD(add_date1, INTERVAL 2 MONTH)) <= 30
        AND cash_pledge_status1 = '0' THEN
        CALL PLUS_port_sell_out(device_no1, '17'); -- 计算50的分润
      ELSEIF total_money >= 500
        AND DATEDIFF(NOW(), DATE_ADD(bind_time1, INTERVAL 0 MONTH)) <= 30
        AND cash_pledge_status1 = '0' THEN
        CALL PLUS_port_sell_out(device_no1, '23'); -- 计算29的分润无押金
      ELSEIF total_money >= 5000
        AND DATEDIFF(NOW(), DATE_ADD(bind_time1, INTERVAL 1 MONTH)) <= 30
        AND cash_pledge_status1 = '0' THEN
        CALL PLUS_port_sell_out(device_no1, '24'); -- 计算50的分润无押金
      ELSEIF total_money >= 5000
        AND DATEDIFF(NOW(), DATE_ADD(bind_time1, INTERVAL 2 MONTH)) <= 30
        AND cash_pledge_status1 = '0' THEN
        CALL PLUS_port_sell_out(device_no1, '25'); -- 计算50的分润无押金
      ELSEIF total_money >= 500
        AND DATEDIFF(NOW(), DATE_ADD(bind_time1, INTERVAL 0 MONTH)) <= 30
        AND cash_pledge_status1 = '2' THEN
        CALL PLUS_port_sell_out(device_no1, '19'); -- 计算29的分润押金版
      ELSEIF total_money >= 5000
        AND DATEDIFF(NOW(), DATE_ADD(bind_time1, INTERVAL 1 MONTH)) <= 30
        AND cash_pledge_status1 = '2' THEN
        CALL PLUS_port_sell_out(device_no1, '20'); -- 计算50的分润押金版
      ELSEIF total_money >= 5000
        AND DATEDIFF(NOW(), DATE_ADD(bind_time1, INTERVAL 2 MONTH)) <= 30
        AND cash_pledge_status1 = '2' THEN
        CALL PLUS_port_sell_out(device_no1, '21'); -- 计算50的分润押金版
      END IF;
    END IF;
  UNTIL stop_flag = 1
  END REPEAT;
  CLOSE select_activite_cursor;
END;


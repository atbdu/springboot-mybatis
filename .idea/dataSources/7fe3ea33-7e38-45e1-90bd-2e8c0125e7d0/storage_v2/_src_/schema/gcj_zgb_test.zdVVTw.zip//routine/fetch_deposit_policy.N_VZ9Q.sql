create
    definer = part@`%` procedure fetch_deposit_policy()
BEGIN
	-- 押金 政策
  DECLARE count_details int DEFAULT 0; -- 明细表中是否存在记录
	DECLARE t_error INTEGER DEFAULT 0;    -- 错误标识
	DECLARE stopflg INT DEFAULT 0;
	DECLARE product_no1 VARCHAR(50);
	DECLARE trad_serial_no1 VARCHAR(50);
	DECLARE trad_money1 DECIMAL(15,2); -- 押金
	DECLARE agent_no1 VARCHAR(50); -- 代理商编号
	DECLARE top_agent_no VARCHAR(50); -- 顶级代理的编号
	DECLARE date_cursor CURSOR  FOR( 
			SELECT trad_serial_no,agent_no,trad_money,product_no FROM trad_serial WHERE trade_type='5' AND  trade_status='0' 
	);
	DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1; -- 遇见异常信息，改变错误标识
		START TRANSACTION; -- 事务开始
		OPEN date_cursor; -- 打开游标
			REPEAT
				FETCH date_cursor INTO trad_serial_no1,agent_no1,trad_money1,product_no1;
				IF(stopflg != 1) THEN	
          SELECT COUNT(1) FROM agent_account_details aad WHERE aad.serial_no=trad_serial_no1 AND aad.act_rim='终端代收服务费分润' LIMIT 1 INTO count_details;
						IF count_details=0 THEN
              SELECT a.agent_no FROM agent a
  						 WHERE a.agent_no IN
  						 (SELECT aa.parent_no FROM agent_agent aa WHERE aa.agent_no = agent_no1)
  						 ORDER BY a.agent_level LIMIT 1 INTO top_agent_no;
  
  						-- 插入押金记录，更新押金账户
  						IF trad_money1 IS NOT NULL  THEN
  							UPDATE agent_account SET wait_account = wait_account+trad_money1 WHERE agent_no=agent_no1 AND account_type='3'; -- 服务费账户
  								INSERT INTO `agent_account_details` 
  								(`serial_no`, `agent_no`, `amount`, `set_date`, `set_time`, `account_type`, `product_no` ,`act_rim`) 
  								VALUES (trad_serial_no1, agent_no1, trad_money1, CURDATE(), CURTIME(), '3',product_no1,'终端代收服务费分润');
  								UPDATE trad_serial SET trade_status='1' WHERE trad_serial_no=trad_serial_no1; -- 改变流水状态
  								UPDATE device SET cash_pledge_status = '2',cash_pledge=trad_money1 WHERE device_no=
  									(SELECT device_no FROM trad_serial WHERE trad_serial_no=trad_serial_no1);
  						  END IF;
            END IF;
				END IF;
			UNTIL stopflg =1
			END REPEAT;
		CLOSE date_cursor;	-- 关闭游标
		IF t_error=1 THEN
			ROLLBACK;
		ELSE
			COMMIT;
		END IF;
END;


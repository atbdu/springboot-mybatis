create
    definer = part@`%` procedure PLUS_port_sell_out(IN device_no1 varchar(50), IN policytype int)
BEGIN
  DECLARE product_no1 varchar(50); -- 产品编号
  DECLARE agent_level1 int; -- 代理级别
  DECLARE first_into int DEFAULT 1;
  DECLARE system_device_no1 varchar(50);
  DECLARE next_money decimal(15, 2) DEFAULT 0;
  DECLARE money decimal(15, 2);
  DECLARE level_agent_no varchar(50);
  DECLARE stopflg int DEFAULT 0;
  DECLARE first_agent_no varchar(50); -- 设备的直属代理
  DECLARE date_cursor CURSOR FOR
  ( -- 终端激活
    SELECT
      b.*,
      a.agent_level
    FROM (SELECT
        pdr.e_value,
        pdr.object_no,
        pdr.product_no
      FROM policy_detail_rim pdr
      WHERE policy_type_no = policytype
      AND object_type = '1'
      AND object_no IN (SELECT
          aa.parent_no
        FROM agent_agent aa
        WHERE aa.agent_no = (SELECT
            agent_no
          FROM device d
          WHERE d.device_no = device_no1))
      AND e_name = 'cash_reward') b
      INNER JOIN agent a
        ON a.agent_no = b.object_no
    ORDER BY a.agent_level DESC);
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET stopflg = 1;   -- 当无记录时，标记游标终止
  OPEN date_cursor; -- 打开游标
  REPEAT
    FETCH date_cursor INTO money, level_agent_no, product_no1, agent_level1;
    IF (stopflg != 1) THEN
      -- 更新总金额
      UPDATE agent_account
      SET total_amt = total_amt + money - next_money
      WHERE agent_no = level_agent_no
      AND account_type = '1';
      -- 添加记录
      INSERT INTO `agent_account_details` (`serial_no`, `agent_no`, `amount`, `set_date`, `set_time`, `account_type`, `product_no`, `act_rim`)
        VALUES (device_no1, level_agent_no, (money - next_money), CURDATE(), CURTIME(), '1', product_no1, '激活分润');
      -- 改变状态
      UPDATE device
      SET reward_status = 1,
          `status` = '2'
      WHERE device_no = device_no1;

      SET next_money = money;
    END IF;
  UNTIL stopflg = 1
  END REPEAT;
  CLOSE date_cursor;	-- 关闭游标
END;


create
    definer = part@`%` procedure activate_plus_procedure(IN device_no1 varchar(50), IN product_no1 varchar(50))
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('activate_plus_procedure', 'gcj_hk_test', 7, 100636)/*[cr_debug.1]*/;
  DECLARE total_yajin decimal(15, 2); -- 押金
  DECLARE cash_pledge1 decimal(15,2);
  DECLARE count_one int DEFAULT 0;
  DECLARE count_two int DEFAULT 0;
  DECLARE count_three int DEFAULT 0;
  DECLARE stopflg int DEFAULT 0;
  DECLARE agent_no1 varchar(50); -- 代理编号
  DECLARE reward_status1 int(2); -- 奖励状态
  DECLARE yiyue_money decimal(15, 2); -- 一月交易金额
  DECLARE eryue_money decimal(15, 2); -- 二月交易金额
  DECLARE sanyue_money decimal(15, 2); -- 三月交易金额
  DECLARE date_cursor CURSOR FOR
  ( -- 终端激活
    SELECT
      d.reward_status,d.cash_pledge,
      SUM(CASE WHEN ts.trad_date >= bind_time AND
          ts.trad_date <= DATE_ADD(d.bind_time, INTERVAL 1 MONTH) AND
          (trade_type = '0' OR
          trade_type = '6' OR
          trade_type = '9') THEN trad_money ELSE 0 END) AS yiyue,
      SUM(CASE WHEN ts.trad_date > DATE_ADD(d.bind_time, INTERVAL 1 MONTH) AND
          ts.trad_date <= DATE_ADD(d.bind_time, INTERVAL 2 MONTH) AND
          (trade_type = '0' OR
          trade_type = '6' OR
          trade_type = '9') THEN trad_money ELSE 0 END) AS eryue,
      SUM(CASE WHEN ts.trad_date > DATE_ADD(d.bind_time, INTERVAL 2 MONTH) AND
          ts.trad_date <= DATE_ADD(d.bind_time, INTERVAL 3 MONTH) AND
          (trade_type = '0' OR
          trade_type = '6' OR
          trade_type = '9') THEN trad_money ELSE 0 END) AS sanyue
    FROM trad_serial ts
      LEFT JOIN device d
        ON ts.device_no = d.device_no
    WHERE ts.device_no = device_no1);
  DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('activate_plus_procedure_Handler', 'activate_plus_procedure', 'gcj_hk_test', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('total_yajin', total_yajin, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('cash_pledge1', cash_pledge1, 'decimal(15,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_one', count_one, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_two', count_two, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_three', count_three, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('reward_status1', reward_status1, 'int(2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('yiyue_money', yiyue_money, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('eryue_money', eryue_money, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('sanyue_money', sanyue_money, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(37, 37, 41, 57, cr_stack_depth)/*[cr_debug.2]*/;
SET stopflg = 1;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;   -- 当无记录时，标记游标终止
  CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('total_yajin', total_yajin, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('cash_pledge1', cash_pledge1, 'decimal(15,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_one', count_one, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_two', count_two, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_three', count_three, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('reward_status1', reward_status1, 'int(2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('yiyue_money', yiyue_money, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('eryue_money', eryue_money, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('sanyue_money', sanyue_money, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(2, 2, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(38, 38, 2, 19, cr_stack_depth)/*[cr_debug.2]*/;
OPEN date_cursor; -- 打开游标
  CALL cr_debug.TRACE(39, 163, 2, 13, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT
    CALL cr_debug.TRACE(40, 40, 4, 95, cr_stack_depth)/*[cr_debug.2]*/;
FETCH date_cursor INTO reward_status1,cash_pledge1, yiyue_money, eryue_money, sanyue_money;
CALL cr_debug.UPDATE_WATCH3('reward_status1', reward_status1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('cash_pledge1', cash_pledge1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('yiyue_money', yiyue_money, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('eryue_money', eryue_money, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('sanyue_money', sanyue_money, '', cr_stack_depth)/*[cr_debug.1]*/;

    CALL cr_debug.TRACE(42, 161, 4, 11, cr_stack_depth)/*[cr_debug.2]*/;
IF (stopflg != 1) THEN
      -- 押金
      CALL cr_debug.TRACE(44, 50, 6, 44, cr_stack_depth)/*[cr_debug.2]*/;
SELECT
        SUM(ts.deposit_amount)
      FROM trad_serial ts
      WHERE device_no = device_no1
      AND (trade_type = '0'
      OR trade_type = '6'
      OR trade_type = '9') INTO total_yajin;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('total_yajin', total_yajin, '', cr_stack_depth)/*[cr_debug.1]*/;

      CALL cr_debug.TRACE(52, 56, 6, 43, cr_stack_depth)/*[cr_debug.2]*/;
SELECT
        COUNT(1)
      FROM agent_account_details aad
      WHERE aad.serial_no = device_no1
      AND aad.source_flag=5 INTO count_one;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('count_one', count_one, '', cr_stack_depth)/*[cr_debug.1]*/;
      CALL cr_debug.TRACE(57, 61, 6, 44, cr_stack_depth)/*[cr_debug.2]*/;
SELECT
        COUNT(1)
      FROM agent_account_details aad
      WHERE aad.serial_no = device_no1
      AND aad.source_flag=12 INTO count_two;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('count_two', count_two, '', cr_stack_depth)/*[cr_debug.1]*/;
      CALL cr_debug.TRACE(62, 66, 6, 46, cr_stack_depth)/*[cr_debug.2]*/;
SELECT
        COUNT(1)
      FROM agent_account_details aad
      WHERE aad.serial_no = device_no1
      AND aad.source_flag=13 INTO count_three;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('count_three', count_three, '', cr_stack_depth)/*[cr_debug.1]*/;
      CALL cr_debug.TRACE(67, 95, 6, 13, cr_stack_depth)/*[cr_debug.2]*/;
IF reward_status1 = 0 AND (yiyue_money - total_yajin) >= 500 THEN
        CALL cr_debug.TRACE(68, 94, 8, 15, cr_stack_depth)/*[cr_debug.2]*/;
IF count_one = 0 THEN
          CALL cr_debug.TRACE(69, 93, 10, 17, cr_stack_depth)/*[cr_debug.2]*/;
IF product_no1 = 'P00000003' THEN
            CALL cr_debug.TRACE(70, 74, 12, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF cash_pledge1 !=0 THEN
              CALL cr_debug.TRACE(71, 71, 14, 88, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '23', 'cash_reward_one');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            ELSE
            CALL cr_debug.TRACE(73, 73, 12, 86, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '19', 'cash_reward_one');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            END IF;
          ELSEIF product_no1 = 'P00000012' THEN
            CALL cr_debug.TRACE(76, 80, 12, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF cash_pledge1 !=0 THEN
              CALL cr_debug.TRACE(77, 77, 14, 88, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '75', 'cash_reward_one');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            ELSE
              CALL cr_debug.TRACE(79, 79, 14, 88, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '71', 'cash_reward_one');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            END IF;
          ELSEIF product_no1 = 'P00000020' THEN
            CALL cr_debug.TRACE(82, 86, 12, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF cash_pledge1 !=0 THEN
              CALL cr_debug.TRACE(83, 83, 14, 89, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '190', 'cash_reward_one');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            ELSE
              CALL cr_debug.TRACE(85, 85, 14, 89, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '188', 'cash_reward_one');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            END IF;
           ELSEIF product_no1 = 'P00000021' THEN
            CALL cr_debug.TRACE(88, 92, 12, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF cash_pledge1 !=0 THEN
              CALL cr_debug.TRACE(89, 89, 14, 89, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '198', 'cash_reward_one');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            ELSE
              CALL cr_debug.TRACE(91, 91, 14, 89, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '198', 'cash_reward_one');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            END IF;
          END IF;
        END IF;
      END IF;
      CALL cr_debug.TRACE(96, 127, 6, 13, cr_stack_depth)/*[cr_debug.2]*/;
IF reward_status1 = 1
        AND eryue_money >= 5000
        AND yiyue_money >= 500 THEN
        CALL cr_debug.TRACE(99, 126, 8, 15, cr_stack_depth)/*[cr_debug.2]*/;
IF count_two = 0 THEN
          CALL cr_debug.TRACE(100, 125, 10, 17, cr_stack_depth)/*[cr_debug.2]*/;
IF product_no1 = 'P00000003' THEN
            CALL cr_debug.TRACE(101, 105, 12, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF cash_pledge1 !=0 THEN
              CALL cr_debug.TRACE(102, 102, 14, 88, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '23', 'cash_reward_two');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            ELSE
              CALL cr_debug.TRACE(104, 104, 14, 88, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '19', 'cash_reward_two');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            END IF;
          ELSEIF product_no1 = 'P00000012' THEN
            CALL cr_debug.TRACE(107, 111, 12, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF cash_pledge1 !=0 THEN
              CALL cr_debug.TRACE(108, 108, 14, 88, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '75', 'cash_reward_two');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            ELSE
              CALL cr_debug.TRACE(110, 110, 14, 88, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '71', 'cash_reward_two');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            END IF;
          ELSEIF product_no1 = 'P00000020' THEN
            CALL cr_debug.TRACE(113, 117, 12, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF cash_pledge1 !=0 THEN
              CALL cr_debug.TRACE(114, 114, 14, 89, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '190', 'cash_reward_two');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            ELSE
              CALL cr_debug.TRACE(116, 116, 14, 89, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '188', 'cash_reward_two');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            END IF;
           ELSEIF product_no1 = 'P00000021' THEN
            CALL cr_debug.TRACE(119, 123, 12, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF cash_pledge1 !=0 THEN
              CALL cr_debug.TRACE(120, 120, 14, 89, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '198', 'cash_reward_two');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            ELSE
              CALL cr_debug.TRACE(122, 122, 14, 89, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '198', 'cash_reward_two');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            END IF;

          END IF;
        END IF;
      END IF;
      CALL cr_debug.TRACE(128, 160, 6, 13, cr_stack_depth)/*[cr_debug.2]*/;
IF reward_status1 = 3
        AND sanyue_money >= 5000
        AND eryue_money >= 5000
        AND yiyue_money >= 500 THEN
        CALL cr_debug.TRACE(132, 159, 8, 15, cr_stack_depth)/*[cr_debug.2]*/;
IF count_three = 0 THEN
          CALL cr_debug.TRACE(133, 158, 10, 17, cr_stack_depth)/*[cr_debug.2]*/;
IF product_no1 = 'P00000003' THEN
            CALL cr_debug.TRACE(134, 138, 12, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF cash_pledge1 !=0 THEN
              CALL cr_debug.TRACE(135, 135, 14, 90, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '23', 'cash_reward_three');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            ELSE
              CALL cr_debug.TRACE(137, 137, 14, 90, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '19', 'cash_reward_three');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            END IF;
          ELSEIF product_no1 = 'P00000012' THEN
            CALL cr_debug.TRACE(140, 144, 12, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF cash_pledge1 !=0 THEN
              CALL cr_debug.TRACE(141, 141, 14, 90, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '75', 'cash_reward_three');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            ELSE
              CALL cr_debug.TRACE(143, 143, 14, 90, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '71', 'cash_reward_three');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            END IF;
          ELSEIF product_no1 = 'P00000020' THEN
             CALL cr_debug.TRACE(146, 150, 13, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF cash_pledge1 !=0 THEN
              CALL cr_debug.TRACE(147, 147, 14, 91, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '190', 'cash_reward_three');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            ELSE
              CALL cr_debug.TRACE(149, 149, 14, 91, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '188', 'cash_reward_three');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            END IF;
          ELSEIF product_no1 = 'P00000021' THEN
             CALL cr_debug.TRACE(152, 156, 13, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF cash_pledge1 !=0 THEN
              CALL cr_debug.TRACE(153, 153, 14, 91, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '198', 'cash_reward_three');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            ELSE
              CALL cr_debug.TRACE(155, 155, 14, 91, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_plus_producer(device_no1, '198', 'cash_reward_three');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
            END IF;

          END IF;
        END IF;
      END IF;
    END IF;
  UNTIL stopflg = 1
  END REPEAT;
  CALL cr_debug.TRACE(164, 164, 2, 20, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE date_cursor;	-- 关闭游标
CALL cr_debug.TRACE(165, 165, 0, 3, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


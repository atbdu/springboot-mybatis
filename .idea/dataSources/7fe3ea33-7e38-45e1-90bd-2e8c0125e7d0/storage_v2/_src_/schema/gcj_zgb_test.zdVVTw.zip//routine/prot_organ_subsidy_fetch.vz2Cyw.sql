create
    definer = part@`%` procedure prot_organ_subsidy_fetch()
BEGIN
-- PROCEDURE pay2_haike.prot_organ_subsidy_fetch(IN this_date varchar(255) )
  DECLARE count_details int DEFAULT 0;-- 明细表中是否存在
  DECLARE product varchar(50); -- 产品编号
  DECLARE product_no1 varchar(50); -- 循环产品编号
  DECLARE agent_no1 varchar(50); 	-- 代理编号
  DECLARE agent_level1 varchar(50); 	-- 代理层级
  DECLARE parent_no1 varchar(50); 	-- 父级代理
  DECLARE is_min_agent_no varchar(50); 	-- 是否时最后一级代理
  DECLARE b_agent_no varchar(50) DEFAULT 0; 	-- 内循环的代理编号
  DECLARE trad_serial_no1 varchar(50); 	-- 交易流水号
  DECLARE trad_money1 varchar(50); -- 交易总额
  DECLARE organ_subsidy_policy varchar(50); -- 政策类型
  DECLARE policy_rate varchar(10); -- 奖励费率
  DECLARE this_agent_no varchar(30); -- 当前代理 
  DECLARE reward_earnings varchar(18) DEFAULT 0; -- 奖励收益
  DECLARE this_policy_rate varchar(10); -- 当前奖励费率
  DECLARE count_num int(5); -- 防止重复插入
  DECLARE front_end_display2 int(1); -- 当前代理享受政策
  DECLARE productss varchar(100); -- 代理有哪些产品
  DECLARE stopflg int DEFAULT 0; -- 初始化游标记录

  DECLARE date_cursor CURSOR FOR
  (SELECT
      aa.agent_no,
      aa.agent_level,
      ap.product_no
    FROM agent_agent aa
      LEFT JOIN agent_policy ap
        ON ap.agent_no = aa.agent_no
    WHERE ap.front_end_display = 1
    GROUP BY aa.agent_no,
             ap.product_no
    ORDER BY aa.agent_no DESC);

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET stopflg = 1;   -- 当无记录时，标记游标终止
  OPEN date_cursor; -- 打开游标
  REPEAT
    FETCH date_cursor INTO agent_no1, agent_level1, product_no1;
    IF (stopflg != 1) THEN
   SET @total_amount1 = 0;
    BEGIN
      DECLARE stopflg1 int DEFAULT 0; -- 内循环游标记录

      DECLARE notrade_cur CURSOR FOR
      (SELECT
          ts.product_no,
          SUM(ts.trad_money) AS total_money,
          ts.trad_serial_no
        FROM trad_serial ts
        WHERE ts.trade_status = 1
        AND ts.trade_type IN ('0', '6', '9')
        AND DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), '%Y-%m') = DATE_FORMAT(ts.trad_date, '%Y-%m')
        AND ts.agent_no IN (SELECT
            aa.agent_no
          FROM agent_agent aa
          WHERE aa.parent_no = agent_no1)
        AND ts.product_no = product_no1
        AND ts.trade_type != 5
        GROUP BY ts.product_no
      --       SELECt
      --           ts.product_no,
      --           SUM(ts.trad_money-ts.deposit_amount) AS total_money,
      --           ts.trad_serial_no
      --         FROM trad_serial ts
      --         WHERE ts.trade_status = 1
      --         AND ts.trade_type IN ('0', '6', '9')
      --         AND DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), '%Y-%m') = DATE_FORMAT(ts.trad_date, '%Y-%m')
      --         AND ts.agent_no IN (SELECT
      --             agent_no
      --           FROM agent_agent aa
      --           WHERE parent_no = agent_no1)
      --         AND ts.trade_type!=5
      --         GROUP BY ts.product_no
      );

      DECLARE CONTINUE HANDLER FOR NOT FOUND SET stopflg1 = 1;
     
      OPEN notrade_cur;
      REPEAT
        FETCH notrade_cur INTO product, trad_money1, trad_serial_no1;
        IF stopflg1 != 1 THEN

          IF product = 'P00000001' THEN -- 电签
            SET organ_subsidy_policy = '132';
          ELSEIF product = 'P00000002' THEN
            SET organ_subsidy_policy = '131';
          ELSEIF product = 'P00000003' THEN
            SET organ_subsidy_policy = '133';
          ELSEIF product = 'P00000004' THEN
            SET organ_subsidy_policy = '134';
          ELSEIF product = 'P00000005' THEN
            SET organ_subsidy_policy = '135';
          ELSEIF product = 'P00000006' THEN
            SET organ_subsidy_policy = '136';
          ELSEIF product = 'P00000007' THEN
            SET organ_subsidy_policy = '140';
          ELSEIF product = 'P00000008' THEN
            SET organ_subsidy_policy = '141';
          ELSEIF product = 'P00000009' THEN
            SET organ_subsidy_policy = '142';
          ELSEIF product = 'P00000010' THEN
            SET organ_subsidy_policy = '137';
          ELSEIF product = 'P00000011' THEN
            SET organ_subsidy_policy = '138';
          ELSEIF product = 'P00000012' THEN
            SET organ_subsidy_policy = '139';
          END IF;
          -- 流水号   时间+当前代理
          SET trad_serial_no1 = CONCAT(DATE_FORMAT(CURDATE(), '%Y%m'), agent_no1);

          -- 机构补贴
          CALL prot_organ_subsidy1(agent_no1, organ_subsidy_policy, product, trad_money1, trad_serial_no1, @total_amount1);
          SELECT
            @total_amount1;
          IF @total_amount1 >= 0 THEN
            SET count_num = (SELECT
                COUNT(*)
              FROM agent_account_details aad
              WHERE aad.serial_no = trad_serial_no1
              AND aad.agent_no = agent_no1
              AND aad.product_no = product);
            IF count_num = 0 THEN
              -- 上级费率和上级代理
              SELECT
                pdr.object_no,
                pdr.e_value
              FROM agent_policy ap
                LEFT JOIN policy_detail_rim pdr
                  ON pdr.policy_type_no = ap.policy_type_no
                  AND ap.agent_no = pdr.object_no
                  AND ap.product_no = pdr.product_no
              WHERE pdr.object_no = agent_no1
              AND ap.product_no = product
              AND pdr.policy_type_no = organ_subsidy_policy
              AND pdr.object_type = '1' INTO this_agent_no, this_policy_rate;
              -- 上级代理奖励

              SET reward_earnings = this_policy_rate * trad_money1 / 10000 - @total_amount1;
              -- 插入金额
              IF reward_earnings > 0 THEN
                UPDATE agent_account
                SET wait_account = wait_account + TRUNCATE(reward_earnings, 2)
                WHERE agent_no = agent_no1
                AND account_type = '0';
                -- 插入记录
                INSERT INTO agent_account_details (serial_no, agent_no, amount, set_date, set_time, product_no, account_type, act_rim, source_flag, trade_money)
                  VALUES (trad_serial_no1, agent_no1, TRUNCATE(reward_earnings, 2), CURDATE(), CURTIME(), product, '0', '机构补贴', '3', trad_money1);
              END IF;
            END IF;
          END IF;
        END IF;
      UNTIL stopflg1 = 1
      END REPEAT;
      CLOSE notrade_cur;	-- 关闭游标
    END;

    END IF;
  UNTIL stopflg = 1
  END REPEAT;
  CLOSE date_cursor;	-- 关闭游标
END;


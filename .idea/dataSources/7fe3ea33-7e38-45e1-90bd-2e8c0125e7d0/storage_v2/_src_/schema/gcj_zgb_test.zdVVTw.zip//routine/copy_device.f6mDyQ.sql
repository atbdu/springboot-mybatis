create
    definer = part@`%` procedure copy_device()
BEGIN
  DECLARE count_device int DEFAULT 0;
	DECLARE device_no1 VARCHAR(50);
	DECLARE stopflg INT DEFAULT 0;
	DECLARE date_cursor CURSOR  FOR( -- 终端激活
			SELECT device_no FROM device
	);
	DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
		OPEN date_cursor; -- 打开游标
			REPEAT
				FETCH date_cursor INTO device_no1;
				
				IF(stopflg != 1) THEN	
          SELECT COUNT(1) FROM device_flow_card dfc WHERE device_no=device_no1 INTO count_device;
          IF count_device=0 THEN
						insert INTO device_flow_card(device_no)VALUES(device_no1);
          END IF;
				END IF;
			UNTIL stopflg =1
			END REPEAT;
		CLOSE date_cursor;	-- 关闭游标
END;


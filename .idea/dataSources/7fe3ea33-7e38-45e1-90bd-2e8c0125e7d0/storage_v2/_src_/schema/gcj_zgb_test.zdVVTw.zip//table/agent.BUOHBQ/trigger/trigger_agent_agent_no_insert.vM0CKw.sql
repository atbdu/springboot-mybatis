create definer = part@`%` trigger trigger_agent_agent_no_insert
    before insert
    on agent
    for each row
begin
	set new.agent_no =ifnull(( select concat('A',LPAD((replace(max(agent_no),'A','')+1),8,0)) from agent),'A00000001');
end;


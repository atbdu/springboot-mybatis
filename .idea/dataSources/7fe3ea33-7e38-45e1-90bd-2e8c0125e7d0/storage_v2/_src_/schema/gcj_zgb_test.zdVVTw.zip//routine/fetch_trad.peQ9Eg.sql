create
    definer = part@`%` procedure fetch_trad() comment '掌柜宝交易分润'
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('fetch_trad', 'gcj_zgb_test', 7, 100636)/*[cr_debug.1]*/;
  DECLARE count_details int DEFAULT 0;-- 明细表中是否存在
  DECLARE policytype_device int; -- 终端政策类型编号
  DECLARE procduct_flag int; -- 商品标志 3表示POS，4表示电签
  DECLARE product varchar(50);
  DECLARE deposit_amount1 decimal(15, 2); -- 押金
  DECLARE stopflg int DEFAULT 0;
  DECLARE pay_name varchar(50);
  DECLARE pay_type int(10);
  DECLARE flow_card_amount1 decimal(15, 2); -- 流量卡费用
  DECLARE trade_status1 int(10);
  DECLARE trad_serial_no1 varchar(255); -- 流水编号
  DECLARE agent_no1 varchar(50);
  DECLARE trad_money1 varchar(50);
  DECLARE organ_reward_policy varchar(50); -- 机构奖励政策类型
  DECLARE tx_money1 decimal(15, 2); -- 提现费
  DECLARE deduct_single_fee1 decimal(5, 2); -- 提现费抵扣券
  DECLARE device1 varchar(50); -- 机具编号
  DECLARE customer_no1 varchar(255); -- 商户编号
  DECLARE chnnel_customer_no1 varchar(50); -- 通道商户编号
  DECLARE date_cursor CURSOR FOR
  (SELECT
      trad_serial_no,
      trade_type,
      product_no,
      withdraw_fee,
      agent_no,
      trad_money,
      deposit_amount,
      device_no,
      customer_no,
      chnnel_customer_no,
      deduct_single_fee,
      flow_card_amount
    FROM trad_serial
    WHERE (product_no = 'P00000002'
    OR product_no = 'P00000001'
    )
    AND company_no = 'P01'
    AND trade_status = 0
    AND trade_type != 5);
  DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('fetch_trad_Handler', 'fetch_trad', 'gcj_zgb_test', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policytype_device', policytype_device, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('procduct_flag', procduct_flag, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('deposit_amount1', deposit_amount1, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('pay_type', pay_type, 'int(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('flow_card_amount1', flow_card_amount1, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_status1', trade_status1, 'int(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('organ_reward_policy', organ_reward_policy, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('tx_money1', tx_money1, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('deduct_single_fee1', deduct_single_fee1, 'decimal(5, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device1', device1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('customer_no1', customer_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(44, 44, 41, 57, cr_stack_depth)/*[cr_debug.2]*/;
SET stopflg = 1;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;   -- 当无记录时，标记游标终止
  CALL cr_debug.UPDATE_WATCH3('count_details', count_details, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policytype_device', policytype_device, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('procduct_flag', procduct_flag, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('deposit_amount1', deposit_amount1, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('pay_type', pay_type, 'int(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('flow_card_amount1', flow_card_amount1, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_status1', trade_status1, 'int(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('organ_reward_policy', organ_reward_policy, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('tx_money1', tx_money1, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('deduct_single_fee1', deduct_single_fee1, 'decimal(5, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device1', device1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('customer_no1', customer_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(3, 3, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(45, 45, 2, 19, cr_stack_depth)/*[cr_debug.2]*/;
OPEN date_cursor; -- 打开游标
  CALL cr_debug.TRACE(46, 93, 2, 13, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT
    CALL cr_debug.TRACE(47, 47, 4, 197, cr_stack_depth)/*[cr_debug.2]*/;
FETCH date_cursor INTO trad_serial_no1, pay_type, product, tx_money1, agent_no1, trad_money1, deposit_amount1, device1, customer_no1, chnnel_customer_no1, deduct_single_fee1, flow_card_amount1;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('pay_type', pay_type, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('tx_money1', tx_money1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('deposit_amount1', deposit_amount1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('device1', device1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('customer_no1', customer_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('deduct_single_fee1', deduct_single_fee1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('flow_card_amount1', flow_card_amount1, '', cr_stack_depth)/*[cr_debug.1]*/;
    CALL cr_debug.TRACE(48, 91, 4, 11, cr_stack_depth)/*[cr_debug.2]*/;
IF (stopflg != 1) THEN
      CALL cr_debug.TRACE(49, 53, 6, 33, cr_stack_depth)/*[cr_debug.2]*/;
SELECT
        COUNT(1)
      FROM agent_account_details aad
      WHERE aad.serial_no= trad_serial_no1
      LIMIT 1 INTO count_details;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, '', cr_stack_depth)/*[cr_debug.1]*/;
      CALL cr_debug.TRACE(54, 64, 6, 13, cr_stack_depth)/*[cr_debug.2]*/;
IF pay_type = '0' THEN
        CALL cr_debug.TRACE(55, 55, 8, 41, cr_stack_depth)/*[cr_debug.2]*/;
SET pay_name = 'swiping_card_t0';
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, '', cr_stack_depth)/*[cr_debug.1]*/;
      ELSEIF pay_type='6' OR pay_type='9' THEN
        CALL cr_debug.TRACE(57, 57, 8, 48, cr_stack_depth)/*[cr_debug.2]*/;
SET pay_name = 'swiping_credit_card_t1';
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, '', cr_stack_depth)/*[cr_debug.1]*/;
      ELSEIF pay_type='4' OR pay_type='8' OR pay_type='7' THEN
         CALL cr_debug.TRACE(59, 59, 9, 50, cr_stack_depth)/*[cr_debug.2]*/;
SET pay_name = 'swiping_deposit_card_t1';
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, '', cr_stack_depth)/*[cr_debug.1]*/;
      ELSEIF pay_type='1' OR pay_type='2' THEN
         CALL cr_debug.TRACE(61, 61, 9, 44, cr_stack_depth)/*[cr_debug.2]*/;
SET pay_name = 'ewm_alipay_wechat';
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, '', cr_stack_depth)/*[cr_debug.1]*/;
      ELSEIF pay_type='3' THEN
         CALL cr_debug.TRACE(63, 63, 9, 39, cr_stack_depth)/*[cr_debug.2]*/;
SET pay_name = 'ewm_chinapay';
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, '', cr_stack_depth)/*[cr_debug.1]*/;
      END IF;
      CALL cr_debug.TRACE(65, 73, 6, 13, cr_stack_depth)/*[cr_debug.2]*/;
IF product = 'P00000001' THEN -- 电签
        CALL cr_debug.TRACE(66, 66, 8, 32, cr_stack_depth)/*[cr_debug.2]*/;
SET procduct_flag = '5';
CALL cr_debug.UPDATE_WATCH3('procduct_flag', procduct_flag, '', cr_stack_depth)/*[cr_debug.1]*/;
        CALL cr_debug.TRACE(67, 67, 8, 36, cr_stack_depth)/*[cr_debug.2]*/;
SET policytype_device = '6';
CALL cr_debug.UPDATE_WATCH3('policytype_device', policytype_device, '', cr_stack_depth)/*[cr_debug.1]*/;
        -- SET organ_reward_policy = '120';
      ELSEIF product = 'P00000002' THEN
        CALL cr_debug.TRACE(70, 70, 8, 37, cr_stack_depth)/*[cr_debug.2]*/;
SET policytype_device = '13';
CALL cr_debug.UPDATE_WATCH3('policytype_device', policytype_device, '', cr_stack_depth)/*[cr_debug.1]*/;
        CALL cr_debug.TRACE(71, 71, 8, 33, cr_stack_depth)/*[cr_debug.2]*/;
SET procduct_flag = '14';
CALL cr_debug.UPDATE_WATCH3('procduct_flag', procduct_flag, '', cr_stack_depth)/*[cr_debug.1]*/;
        -- SET organ_reward_policy = '119';
      END IF;

      CALL cr_debug.TRACE(75, 89, 6, 13, cr_stack_depth)/*[cr_debug.2]*/;
IF count_details = 0 THEN
        CALL cr_debug.TRACE(76, 76, 8, 49, cr_stack_depth)/*[cr_debug.2]*/;
CALL Today_Sum_Moneyint(trad_serial_no1);
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, '', cr_stack_depth)/*[cr_debug.1]*/;  -- 实时交易数据存储过程

        CALL cr_debug.TRACE(78, 78, 8, 134, cr_stack_depth)/*[cr_debug.2]*/;
CALL profit_share(trad_serial_no1, pay_name, procduct_flag, policytype_device, tx_money1, deposit_amount1, flow_card_amount1);
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('procduct_flag', procduct_flag, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('policytype_device', policytype_device, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('tx_money1', tx_money1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('deposit_amount1', deposit_amount1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('flow_card_amount1', flow_card_amount1, '', cr_stack_depth)/*[cr_debug.1]*/; -- 调用结算分润存储过程

        CALL cr_debug.TRACE(80, 83, 8, 15, cr_stack_depth)/*[cr_debug.2]*/;
IF tx_money1 != 0 THEN -- +3分润
          CALL cr_debug.TRACE(81, 81, 10, 36, cr_stack_depth)/*[cr_debug.2]*/;
SET pay_name = 'tx_money';
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, '', cr_stack_depth)/*[cr_debug.1]*/;
          CALL cr_debug.TRACE(82, 82, 10, 191, cr_stack_depth)/*[cr_debug.2]*/;
CALL profit_share_tx(trad_serial_no1, pay_name, procduct_flag, product, tx_money1, agent_no1, device1, customer_no1, chnnel_customer_no1, pay_type, deduct_single_fee1, trad_money1);
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('pay_name', pay_name, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('procduct_flag', procduct_flag, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('tx_money1', tx_money1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('device1', device1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('customer_no1', customer_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('pay_type', pay_type, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('deduct_single_fee1', deduct_single_fee1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, '', cr_stack_depth)/*[cr_debug.1]*/;
        END IF;

        -- IF pay_type = '0' OR pay_type = '6' OR pay_type = '9' THEN -- 机构奖励
          -- CALL prot_organ_reward(trad_serial_no1, organ_reward_policy, product, trad_money1, agent_no1, device1, customer_no1, chnnel_customer_no1, pay_type, trad_money1);
        -- END IF;
        -- 流量卡额外奖励
      END IF;

    END IF;
  UNTIL stopflg = 1
  END REPEAT;
  CALL cr_debug.TRACE(94, 94, 2, 20, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE date_cursor;	-- 关闭游标
CALL cr_debug.TRACE(95, 95, 0, 3, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


create
    definer = part@`%` procedure PAY_TRADE_DATA_PRO_AGENT_0(IN b_trad_date varchar(10))
BEGIN
DECLARE  b_agent_no varchar(10);    -- 代理商编号
DECLARE  b_trade_num int(11) DEFAULT NULL; -- '交易笔数',
DECLARE  b_trade_money varchar(15) DEFAULT '0'; -- '总交易数'
DECLARE  b_all_device_num varchar(15) DEFAULT '0'; -- 总机器数(已激活)
DECLARE  b_trade_device_num varchar(15) DEFAULT '0'; -- '当日交易终端数'
DECLARE  b_new_device int(7) DEFAULT 0; -- '新增终端个数'
DECLARE  b_swipe_credit_amt varchar(15) DEFAULT '0'; -- '刷卡信用卡T1'
DECLARE  b_swipe_credit0_amt varchar(15) DEFAULT '0'; -- '信用卡刷卡D0'
DECLARE  b_alipay_amt varchar(15) DEFAULT '0'; -- '支付宝T1'
DECLARE  b_alipay0_amt varchar(15) DEFAULT '0'; -- '支付宝D0'
DECLARE  b_swipe_debit_amt varchar(15) DEFAULT '0'; -- '储蓄刷卡T1'
DECLARE  b_swipe_debit0_amt varchar(15) DEFAULT '0'; -- '储蓄卡D0'
DECLARE  b_wechat_amt varchar(15) DEFAULT '0'; -- '微信T1'
DECLARE  b_wechat0_amt varchar(15) DEFAULT '0'; -- '微信D0'
DECLARE  b_quickpass_amt varchar(15) DEFAULT '0'; -- '云闪付T1'
DECLARE  b_quickpass0_amt varchar(15) DEFAULT '0'; -- '云闪付D0'
DECLARE  b_preferred_credit_pay varchar(15) DEFAULT '0'; -- '优选付贷记卡T1'
DECLARE  b_preferred_credit0_pay varchar(15) DEFAULT '0'; -- '优选付贷记卡D0'
DECLARE  b_preferred_deposit_pay varchar(15) DEFAULT '0'; -- '优选付借记卡T1'
DECLARE  b_preferred_deposit0_pay varchar(15) DEFAULT '0'; -- '优选付借记卡D0'
DECLARE  b_company_no varchar(3) DEFAULT NULL; --  支付公司编号
DECLARE  b_product_no varchar(15) DEFAULT NULL ; --  产品编号
DECLARE  stopflg int DEFAULT 0;    -- 记录游标循环是否终止 
DECLARE  agt_cursor CURSOR FOR(    -- 查出所有有交易的代理商父级并去重
   SELECT DISTINCT(parent_no) FROM agent_agent where agent_no IN(
      SELECT DISTINCT(agent_no) FROM trade_date_pro_agent WHERE trade_date=b_trad_date AND direct_customer=1
   )
);
DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
  OPEN agt_cursor;
    REPEAT 
      FETCH agt_cursor INTO b_agent_no;  -- 循环统计每个代理数据
      IF stopflg != 1 THEN
      BEGIN
         DECLARE  gby_stopflg int DEFAULT 0;
         DECLARE agt_gby_cusor CURSOR FOR(   -- 按产品号统计汇总记录
          SELECT SUM(trade_num) AS trade_num,SUM(trade_money)  AS trade_money,product_no,MAX(company_no) AS company_no,    -- 根据代理号统计其团队（包含在自己）交易数据
              SUM(trade_device_num) AS trade_device_num,
              SUM(new_device) AS new_device,
              SUM(swipe_credit_amt) AS swipe_credit_amt,
              SUM(swipe_credit0_amt) AS swipe_credit0_amt,
              SUM(alipay_amt) AS alipay_amt,
              SUM(alipay0_amt) AS alipay0_amt,
              SUM(swipe_debit_amt) AS swipe_debit_amt,
              SUM(swipe_debit0_amt) AS swipe_debit0_amt,
              SUM(wechat_amt) AS wechat_amt,
              SUM(wechat0_amt) AS wechat0_amt,
              SUM(quickpass_amt) AS quickpass_amt,
              SUM(quickpass0_amt) AS quickpass0_amt,
              SUM(preferred_credit_pay) AS preferred_credit_pay,
              SUM(preferred_credit0_pay) AS preferred_credit0_pay, 
              SUM(preferred_deposit_pay) AS preferred_deposit_pay, 
              SUM(preferred_deposit0_pay) AS preferred_deposit0_pay
              FROM trade_date_pro_agent  WHERE trade_date=b_trad_date AND direct_customer=1 and agent_no IN(SELECT agent_no FROM agent_agent WHERE parent_no=b_agent_no) GROUP BY product_no
         );
         DECLARE CONTINUE HANDLER FOR NOT FOUND set gby_stopflg=1;   -- 当无记录时，标记游标终止
         OPEN agt_gby_cusor;
         REPEAT 
              FETCH agt_gby_cusor INTO b_trade_num,b_trade_money,b_product_no,b_company_no,b_trade_device_num,b_new_device,b_swipe_credit_amt,b_swipe_credit0_amt,b_alipay_amt,b_alipay0_amt,b_wechat_amt,b_wechat0_amt,b_quickpass_amt,b_quickpass0_amt,b_swipe_debit_amt,b_swipe_debit0_amt,b_preferred_credit_pay,b_preferred_credit0_pay,b_preferred_deposit_pay,b_preferred_deposit0_pay; 
              IF gby_stopflg != 1 THEN
                  SELECT COUNT(*) as all_device_num INTO b_all_device_num FROM device WHERE agent_no IN(SELECT agent_no FROM agent_agent WHERE parent_no=b_agent_no) AND customer_no is NOT NULL AND product_no=b_product_no;
                  IF b_all_device_num=0 THEN
                    set b_all_device_num=0;
                  END IF;
                  INSERT INTO trade_date_pro_agent(       -- 插入数据
                       company_no,
              product_no, 
              agent_no,
              trade_date,
              trade_num,
              trade_money,
              all_device_num,
              trade_device_num,
              new_device,
              swipe_credit_amt,
              swipe_credit0_amt,
              alipay_amt,
              alipay0_amt,
              swipe_debit_amt,
              swipe_debit0_amt,
              wechat_amt,
              wechat0_amt,
              quickpass_amt,
              quickpass0_amt,
              preferred_credit_pay,
              preferred_credit0_pay,
              preferred_deposit_pay,
              preferred_deposit0_pay,
              direct_customer
              )
              VALUES(
                b_company_no,
                b_product_no, 
                b_agent_no,
                b_trad_date,
                b_trade_num,
                b_trade_money,
                b_all_device_num,
                b_trade_device_num,
                b_new_device,
                b_swipe_credit_amt,
                b_swipe_credit0_amt,
                b_alipay_amt,
                b_alipay0_amt,
                b_swipe_debit_amt,
                b_swipe_debit0_amt,
                b_wechat_amt,
                b_wechat0_amt,
                b_quickpass_amt,
                b_quickpass0_amt,
                b_preferred_credit_pay,
                b_preferred_credit0_pay,
                b_preferred_deposit_pay,
                b_preferred_deposit0_pay,
                        0
                      );
               END IF;    -- end if gby_stopflg!=1 
           UNTIL gby_stopflg = 1
           END REPEAT;    -- end  agt_gby_cusor 游标循环
           CLOSE agt_gby_cusor;
        END; 
      END IF;    -- END IF stopflg!=1
    UNTIL stopflg = 1
    END REPEAT;
    CLOSE agt_cursor;
    COMMIT;
END;


create
    definer = part@`%` procedure fetch_agent_profit(IN agent_no1 varchar(50), IN device_no1 varchar(50))
BEGIN
		DECLARE stopflg INT DEFAULT 0;
		DECLARE agent_temp VARCHAR(50);
		DECLARE date_cursor CURSOR  FOR(			
				SELECT parent_no  FROM agent_agent WHERE agent_no =agent_no1
		);
		DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
			OPEN date_cursor; -- 打开游标
				REPEAT
					FETCH date_cursor INTO agent_temp;
					IF(stopflg != 1) THEN	
							CALL activate_device_procedure(agent_temp,device_no1); -- 30天激活奖励
					END IF;	
				UNTIL stopflg =1
				END REPEAT;
			CLOSE date_cursor;	-- 关闭游标
END;


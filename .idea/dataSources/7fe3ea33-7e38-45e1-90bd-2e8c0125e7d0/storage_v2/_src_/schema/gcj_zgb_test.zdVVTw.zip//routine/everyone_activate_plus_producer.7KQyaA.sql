create
    definer = part@`%` procedure everyone_activate_plus_producer(IN device_no1 varchar(50), IN policytype int,
                                                                 IN reward_name varchar(50))
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('everyone_activate_plus_producer', 'test_hk123', 7, 100636)/*[cr_debug.1]*/;
	DECLARE t_error INTEGER DEFAULT 0;  -- 定义错误标识  
  DECLARE custom_no1 varchar(50); -- 客户编号
  DECLARE chnnel_customer_no1 varchar(50); -- 商户通道编号
	DECLARE product_no1 VARCHAR(50); -- 产品编号
	DECLARE agent_level1 INT; -- 代理级别
	DECLARE jifen INT DEFAULT 0; -- 奖励积分
	DECLARE first_into INT DEFAULT 1;
	DECLARE system_device_no1 VARCHAR(50);
	DECLARE next_money DECIMAL(15,2) DEFAULT 0;
	DECLARE money DECIMAL(15,2);
	DECLARE level_agent_no VARCHAR(50);
	DECLARE stopflg INT DEFAULT 0;
	DECLARE first_agent_no VARCHAR(50); -- 设备的直属代理
	DECLARE date_cursor CURSOR  FOR( -- 终端激活SELECT * FROM agent_agent aa WHERE aa.agent_no='A00000038'
			SELECT b.*,a.agent_level FROM
				(SELECT pdr.e_value,pdr.object_no FROM policy_detail_rim pdr WHERE policy_type_no = policytype AND object_type='1' AND object_no in (
				SELECT aa.parent_no FROM agent_agent aa WHERE aa.agent_no = (
				SELECT agent_no FROM device d WHERE d.device_no = device_no1
				)
				)	AND e_name =reward_name ) b
				INNER JOIN 
				 agent a ON a.agent_no = b.object_no ORDER BY a.agent_level DESC
	);
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('everyone_activate_plus_producer_Handler', 'everyone_activate_plus_producer', 'test_hk123', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, 'INTEGER', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('custom_no1', custom_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_level1', agent_level1, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('jifen', jifen, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('first_into', first_into, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('system_device_no1', system_device_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('next_money', next_money, 'DECIMAL(15,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('money', money, 'DECIMAL(15,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('level_agent_no', level_agent_no, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('first_agent_no', first_agent_no, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policytype', policytype, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('reward_name', reward_name, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(26, 26, 43, 57, cr_stack_depth)/*[cr_debug.2]*/;
SET t_error=1;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END; -- 发现sql异常设置为1
	DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('everyone_activate_plus_producer_Handler', 'everyone_activate_plus_producer', 'test_hk123', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, 'INTEGER', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('custom_no1', custom_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_level1', agent_level1, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('jifen', jifen, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('first_into', first_into, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('system_device_no1', system_device_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('next_money', next_money, 'DECIMAL(15,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('money', money, 'DECIMAL(15,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('level_agent_no', level_agent_no, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('first_agent_no', first_agent_no, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policytype', policytype, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('reward_name', reward_name, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(27, 27, 40, 54, cr_stack_depth)/*[cr_debug.2]*/;
set stopflg=1;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;   -- 当无记录时，标记游标终止
  CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policytype', policytype, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('reward_name', reward_name, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, 'INTEGER', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('custom_no1', custom_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_level1', agent_level1, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('jifen', jifen, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('first_into', first_into, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('system_device_no1', system_device_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('next_money', next_money, 'DECIMAL(15,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('money', money, 'DECIMAL(15,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('level_agent_no', level_agent_no, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('first_agent_no', first_agent_no, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(2, 2, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(28, 28, 2, 142, cr_stack_depth)/*[cr_debug.2]*/;
SELECT customer_no,chnnel_customer_no,product_no FROM device d WHERE d.device_no=device_no1 INTO custom_no1,chnnel_customer_no1,product_no1;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('custom_no1', custom_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
		-- 事务开始
		CALL cr_debug.TRACE(30, 30, 2, 20, cr_stack_depth)/*[cr_debug.2]*/;
START TRANSACTION;
			CALL cr_debug.TRACE(31, 31, 3, 20, cr_stack_depth)/*[cr_debug.2]*/;
OPEN date_cursor; -- 打开游标
				CALL cr_debug.TRACE(32, 80, 4, 15, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT
					CALL cr_debug.TRACE(33, 33, 5, 62, cr_stack_depth)/*[cr_debug.2]*/;
FETCH date_cursor INTO money,level_agent_no,agent_level1;
CALL cr_debug.UPDATE_WATCH3('money', money, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('level_agent_no', level_agent_no, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('agent_level1', agent_level1, '', cr_stack_depth)/*[cr_debug.1]*/;
					
					CALL cr_debug.TRACE(35, 78, 5, 12, cr_stack_depth)/*[cr_debug.2]*/;
IF(stopflg != 1) THEN	
							-- 判断政策金额是不是为空,改变事务状态
							 CALL cr_debug.TRACE(37, 39, 8, 15, cr_stack_depth)/*[cr_debug.2]*/;
IF money IS NULL THEN
									CALL cr_debug.TRACE(38, 38, 9, 25, cr_stack_depth)/*[cr_debug.2]*/;
SET t_error = 1;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, '', cr_stack_depth)/*[cr_debug.1]*/;
								END IF;

							-- 改变状态
								CALL cr_debug.TRACE(42, 76, 8, 15, cr_stack_depth)/*[cr_debug.2]*/;
IF reward_name='cash_reward_one' THEN
									-- 更新待入账账户金额
									CALL cr_debug.TRACE(44, 44, 9, 135, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE agent_account SET wait_account = wait_account + money - next_money WHERE agent_no =level_agent_no AND account_type='1';
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/;
									-- 添加记录
									CALL cr_debug.TRACE(46, 50, 9, 65, cr_stack_depth)/*[cr_debug.2]*/;
INSERT INTO `agent_account_details` 
										(`serial_no`, `agent_no`, `amount`, `set_date`, `set_time`, `account_type`, `product_no`,`act_rim`,
                    device_no,customer_no,chnnel_customer_no,source_flag) 
										VALUES (device_no1, level_agent_no, (money - next_money), CURDATE(), CURTIME(), '1',product_no1, '激活分润',
                    device_no1,custom_no1,chnnel_customer_no1,5);
CALL cr_debug.UPDATE_SYSTEM_CALLS(102)/*[cr_debug.1]*/;
									-- 改变机具状态和奖励状态
									CALL cr_debug.TRACE(52, 52, 9, 107, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE device SET reward_status = 1,`status`='2',active_date=CURDATE() WHERE device_no=device_no1;
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/;
								ELSEIF reward_name='cash_reward_two' THEN
									-- 更新待入账账户金额
									CALL cr_debug.TRACE(55, 55, 9, 135, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE agent_account SET wait_account = wait_account + money - next_money WHERE agent_no =level_agent_no AND account_type='1';
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/;
									-- 添加记录
									CALL cr_debug.TRACE(57, 61, 9, 66, cr_stack_depth)/*[cr_debug.2]*/;
INSERT INTO `agent_account_details` 
										(`serial_no`, `agent_no`, `amount`, `set_date`, `set_time`, `account_type`, `product_no`,`act_rim`,
                    device_no,customer_no,chnnel_customer_no,source_flag) 
										VALUES (device_no1, level_agent_no, (money - next_money), CURDATE(), CURTIME(), '1',product_no1, '第二月交易达标奖励分润',
                    device_no1,custom_no1,chnnel_customer_no1,12);
CALL cr_debug.UPDATE_SYSTEM_CALLS(102)/*[cr_debug.1]*/;
									-- 改变机具的奖励状态
									CALL cr_debug.TRACE(63, 63, 9, 72, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE device SET reward_status = 3 WHERE device_no=device_no1;
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/;
								ELSEIF reward_name='cash_reward_three' THEN
									-- 更新待入账账户金额
									CALL cr_debug.TRACE(66, 66, 9, 135, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE agent_account SET wait_account = wait_account + money - next_money WHERE agent_no =level_agent_no AND account_type='1';
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/;
									-- 添加记录
									CALL cr_debug.TRACE(68, 72, 9, 66, cr_stack_depth)/*[cr_debug.2]*/;
INSERT INTO `agent_account_details` 
										(`serial_no`, `agent_no`, `amount`, `set_date`, `set_time`, `account_type`, `product_no`,`act_rim`,
                    device_no,customer_no,chnnel_customer_no,source_flag) 
										VALUES (device_no1, level_agent_no, (money - next_money), CURDATE(), CURTIME(), '1',product_no1, '第三月交易达标奖励分润',
                    device_no1,custom_no1,chnnel_customer_no1,13);
CALL cr_debug.UPDATE_SYSTEM_CALLS(102)/*[cr_debug.1]*/;

									-- 改变机具的奖励状态
									CALL cr_debug.TRACE(75, 75, 9, 72, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE device SET reward_status = 4 WHERE device_no=device_no1;
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/;
								END IF;
							CALL cr_debug.TRACE(77, 77, 7, 30, cr_stack_depth)/*[cr_debug.2]*/;
SET next_money = money;
CALL cr_debug.UPDATE_WATCH3('next_money', next_money, '', cr_stack_depth)/*[cr_debug.1]*/;
					END IF;
				UNTIL stopflg =1
				END REPEAT;
			CALL cr_debug.TRACE(81, 81, 3, 21, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE date_cursor;	-- 关闭游标
		-- 判断错误状态，决定是否回滚
		 CALL cr_debug.TRACE(83, 87, 3, 10, cr_stack_depth)/*[cr_debug.2]*/;
IF t_error = 1 THEN    
					CALL cr_debug.TRACE(84, 84, 5, 14, cr_stack_depth)/*[cr_debug.2]*/;
ROLLBACK;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, 'INTEGER', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('custom_no1', custom_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('agent_level1', agent_level1, 'INT', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('jifen', jifen, 'INT', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('first_into', first_into, 'INT', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('system_device_no1', system_device_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('next_money', next_money, 'DECIMAL(15,2)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('money', money, 'DECIMAL(15,2)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('level_agent_no', level_agent_no, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'INT', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('first_agent_no', first_agent_no, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('policytype', policytype, 'INT', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('reward_name', reward_name, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.1]*/;    
			ELSE    
					CALL cr_debug.TRACE(86, 86, 5, 12, cr_stack_depth)/*[cr_debug.2]*/;
COMMIT;    
			END IF;    
	CALL cr_debug.TRACE(88, 88, 1, 4, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


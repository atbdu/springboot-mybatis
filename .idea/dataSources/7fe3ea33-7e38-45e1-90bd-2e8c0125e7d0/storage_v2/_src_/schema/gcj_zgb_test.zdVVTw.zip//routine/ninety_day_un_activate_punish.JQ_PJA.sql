create
    definer = part@`%` procedure ninety_day_un_activate_punish() comment '伪激活考核'
BEGIN
	DECLARE stopflg INT DEFAULT 0;
  DECLARE policy_type varchar(20);
	DECLARE agent_no1 VARCHAR(50); -- 代理商编号
	DECLARE device_no1 VARCHAR(50); -- 终端编号
	DECLARE product_no1 VARCHAR(50); -- 产品编号
	DECLARE trad_total_money DECIMAL(15,2);-- 交易总金额
	DECLARE punish_money1 DECIMAL(15,2); -- 处罚金额
	DECLARE punish_jifen1 INT; -- 扣除积分
	DECLARE date_cursor CURSOR  FOR( -- 终端激活
			SELECT t.agent_no,d.device_no,d.product_no,SUM(t.trad_money) AS total_money FROM device d LEFT JOIN trad_serial t
		ON d.device_no = t.device_no WHERE d.`status`=2 AND d.reward_status=1 AND t.trade_type IN (0,6,9)	
    GROUP BY d.device_no,d.bind_time HAVING total_money IS NOT NULL 
		AND total_money<10000 AND DATEDIFF(CURDATE(),d.bind_time) > 90
	);
	DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
		OPEN date_cursor; -- 打开游标
			REPEAT
				FETCH date_cursor INTO agent_no1,device_no1,product_no1,trad_total_money;
				IF(stopflg != 1) THEN	
						IF product_no1='P00000001' THEN 
              SET policy_type ='2';		
						ELSEIF product_no1 ='P00000002'	THEN -- 大POS
              SET policy_type ='10';                          
						END IF;
            -- 代理政策：扣款金额
						SELECT e_value FROM policy_detail_rim pdr WHERE pdr.policy_type_no=policy_type
						AND pdr.object_no = agent_no1 AND pdr.object_type='1' AND pdr.e_name='punish_money' INTO punish_money1;						
						-- 扣除代理的积分和金额
						IF  punish_money1 IS NOT NULL THEN
								-- 扣除金额
								UPDATE agent_account SET total_amt =total_amt - punish_money1 WHERE agent_no=agent_no1 AND account_type='1';
								INSERT INTO `agent_account_details` 
								(`serial_no`, `agent_no`, `amount`, `set_date`, `set_time`, `account_type`, `product_no` ,`act_rim`) 
								VALUES (device_no1, agent_no1, -punish_money1, CURDATE(), CURTIME(), '1',product_no1,'90天伪激活扣款');
								UPDATE device d SET d.reward_status=2 WHERE d.device_no=device_no1;
						END IF;           						 
				END IF;
			UNTIL stopflg =1
			END REPEAT;
		CLOSE date_cursor;	-- 关闭游标
END;


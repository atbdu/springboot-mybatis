create
    definer = part@`%` procedure INSERT_PAY_TRADE_DATA_PRO_AGENT()
BEGIN
DECLARE b_trad_date varchar(10);
DECLARE stopflg int DEFAULT 0;    -- 记录游标循环是否终止 
DECLARE date_cursor CURSOR  FOR(
  SELECT DISTINCT(trad_date) FROM trad_serial
); 
DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
   OPEN date_cursor;
    REPEAT 
      FETCH date_cursor INTO b_trad_date;
      IF(stopflg != 1) THEN
          CALL PAY_TRADE_DATA_PRO_AGENT(b_trad_date);
      END IF;
    UNTIL stopflg =1
    END REPEAT;
    CLOSE date_cursor;
END;


create
    definer = part@`%` procedure fetch_activate_procedureP18() comment '卡盟0反300定制版激活奖励'
BEGIN
	DECLARE count_detail INT DEFAULT 0;-- 是否存在记录
	DECLARE product_no1 VARCHAR(30); -- 产品编号
	DECLARE count_detail_yajin INT DEFAULT 0; -- 是否收取押金 0_未收取，1_已收取
	DECLARE cash_reward1 DECIMAL(15,2); -- 奖励金额
	DECLARE device_no1 VARCHAR(50); -- 机具编号
	DECLARE agent_no1 VARCHAR(50);
	DECLARE customer_no1 VARCHAR(50);
	DECLARE chnnel_customer_no1 VARCHAR(50);
	DECLARE source_flag INT DEFAULT 5; -- 激活奖励
	DECLARE stopflg INT DEFAULT 0;
	DECLARE date_cursor CURSOR  FOR( -- 终端激活
			SELECT device_no,agent_no,customer_no,chnnel_customer_no,product_no FROM device WHERE `status`=1 
			AND reward_status=0 AND cash_pledge_status=2 and product_no='P00000018'
	);
	DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
		OPEN date_cursor; -- 打开游标
			REPEAT
				FETCH date_cursor INTO device_no1,agent_no1,customer_no1,chnnel_customer_no1,product_no1;
				IF(stopflg != 1) THEN	
						-- 查询奖励的金额
						SELECT cash_reward FROM policy_detail_rim WHERE policy_type_no='171' AND object_no=agent_no1 AND object_type=1 INTO cash_reward1;
						
						SELECT COUNT(1) FROM agent_account_details WHERE source_flag=5 AND device_no=device_no1 INTO count_detail;
						IF count_detail=0 AND cash_reward1 IS NOT NULL THEN

								UPDATE agent_account SET wait_account=wait_account + cash_reward1,last_time=NOW() WHERE agent_no=agent_no1 AND account_type=1;
								INSERT INTO `agent_account_details` (`serial_no`, `agent_no`, `set_date`, `set_time`, `account_type`, 
								`product_no`, `act_rim`, `details_status`, `customer_no`, `chnnel_customer_no`, `device_no`, `source_flag`) 
								VALUES (device_no1, agent_no1, CURDATE(), CURTIME(), '1', product_no1, '激活奖励', '1', customer_no1, chnnel_customer_no1, device_no1, source_flag);
								-- 激活机器
								UPDATE device SET `status`=2 WHERE device_no=device_no1;
						END IF;
				END IF;
			UNTIL stopflg =1
			END REPEAT;
		CLOSE date_cursor;	-- 关闭游标
END;


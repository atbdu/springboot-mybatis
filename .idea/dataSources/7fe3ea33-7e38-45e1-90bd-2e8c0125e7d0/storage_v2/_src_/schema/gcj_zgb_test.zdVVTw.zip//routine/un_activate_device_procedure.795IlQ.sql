create
    definer = part@`%` procedure un_activate_device_procedure() comment '180天未激活'
BEGIN
  DECLARE count_detail int DEFAULT 0;
  DECLARE customer_no1 varchar(50);
  DECLARE chnnel_customer_no1 varchar(50);
	DECLARE device_no1 VARCHAR(50);
	DECLARE punish_money DECIMAL(15,2);
	DECLARE stopflg INT DEFAULT 0;
	DECLARE policy_type INT; -- 政策类型编号
	DECLARE product VARCHAR(50);
	DECLARE agent_no1 VARCHAR(50);
	DECLARE total_money DECIMAL(18,2) DEFAULT 0;
	DECLARE date_cursor CURSOR  FOR( -- 查询入库180天未激活的设备
			SELECT d.agent_no,d.product_no,d.device_no,d.customer_no,d.chnnel_customer_no FROM device d 
			WHERE d.reward_status = '0' AND  DATEDIFF(CURDATE(),d.add_date) >=180 AND d.status=1 
	);
	DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
		OPEN date_cursor; -- 打开游标
			REPEAT
				FETCH date_cursor INTO agent_no1,product,device_no1,customer_no1,chnnel_customer_no1;
				IF(stopflg != 1) THEN	
						IF product='P00000001' THEN -- 大POS
							SET policy_type = '3';
						ELSEIF product='P00000002' THEN -- 电签
							SET policy_type = '11';
            
						END IF;
						-- 查询代理绑定的政策中需要扣除的金额
						SELECT pdr.e_value FROM device d LEFT JOIN policy_detail_rim pdr ON 
					d.agent_no=pdr.object_no WHERE pdr.object_no=agent_no1 
					AND pdr.policy_type_no = policy_type AND device_no = device_no1
					INTO punish_money;
					
					IF punish_money IS NOT NULL THEN
						-- 扣款
						UPDATE agent_account SET total_amt = total_amt-punish_money WHERE agent_no = agent_no1 AND account_type='1';
						-- 记录
						INSERT INTO `agent_account_details` 
							(`serial_no`, `agent_no`, `amount`, `set_date`, `set_time`, `account_type`, `product_no`, `act_rim`,device_no,customer_no,chnnel_customer_no,source_flag) 
							VALUES (device_no1, agent_no1, punish_money, CURDATE(), CURTIME(), '1', product, '机具入库之日起180未激活扣款',
              device_no1,customer_no1,chnnel_customer_no1,8);
						 -- 改变状态
						UPDATE device SET reward_status = 5 WHERE device_no=device_no1;
					END IF ;
				END IF;
			UNTIL stopflg =1
			END REPEAT;
		CLOSE date_cursor;	-- 关闭游标
	
END;


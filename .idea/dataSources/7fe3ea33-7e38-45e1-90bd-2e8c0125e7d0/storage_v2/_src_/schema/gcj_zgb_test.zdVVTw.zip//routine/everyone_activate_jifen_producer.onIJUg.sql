create
    definer = part@`%` procedure everyone_activate_jifen_producer(IN device_no1 varchar(50), IN policytype varchar(50))
BEGIN
	DECLARE t_error INTEGER DEFAULT 0;  -- 定义错误标识  
  DECLARE stopflg INT DEFAULT 0;
	DECLARE jifen INT; -- 积分
	DECLARE next_jifen INT DEFAULT 0; -- 积分零时变量
	DECLARE agent_no1 VARCHAR(50);-- 代理编号
	DECLARE level1 INT; -- 代理级别
	DECLARE customer_no1 VARCHAR(50); -- 客户编号
	DECLARE chnnel_customer_no1 VARCHAR(50); -- 商户通道编号
	DECLARE product_no1 VARCHAR(50); -- 产品编号

	DECLARE date_cursor CURSOR  FOR( 
				SELECT b.*,a.agent_level FROM
				(SELECT pdr.e_value,pdr.object_no FROM policy_detail_rim pdr WHERE policy_type_no = policytype AND object_type='1' AND object_no in (
				SELECT aa.parent_no FROM agent_agent aa WHERE aa.agent_no = (
				SELECT agent_no FROM device d WHERE d.device_no = device_no1
				)
				)	AND e_name ='jifen_reward' ) b
				INNER JOIN 
				 agent a ON a.agent_no = b.object_no ORDER BY a.agent_level DESC
	);
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1; -- 发现sql异常设置为1
	DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止

	SELECT agent_no,product_no,customer_no,chnnel_customer_no FROM device WHERE device_no=device_no1 
	INTO agent_no1,product_no1,customer_no1,chnnel_customer_no1;
		-- 事务开始
		START TRANSACTION;
			OPEN date_cursor; -- 打开游标
				REPEAT
					FETCH date_cursor INTO jifen,agent_no1,level1;					
					IF(stopflg != 1) THEN	
						IF jifen IS NOT NULL THEN
						 INSERT INTO `agent_account_details` (`serial_no`, `agent_no`, `amount`, `set_date`, `set_time`, `account_type`, `product_no`, `act_rim`, `customer_no`, `chnnel_customer_no`, `device_no`, `source_flag`,`details_status`)
							VALUES (device_no1, agent_no1, jifen-next_jifen, CURDATE(), CURTIME(), '2', product_no1, '激活积分分润', customer_no1, chnnel_customer_no1, device_no1, '6','1');
							UPDATE agent_account SET total_amt=total_amt + jifen - next_jifen WHERE agent_no = agent_no1 AND account_type=2;
							SET next_jifen = jifen;
						
						END IF;
					END IF;
				UNTIL stopflg =1
				END REPEAT;
			CLOSE date_cursor;	-- 关闭游标
		-- 判断错误状态，决定是否回滚
		 IF t_error = 1 THEN    
					ROLLBACK;    
			ELSE    
					COMMIT;    
			END IF;    
	END;


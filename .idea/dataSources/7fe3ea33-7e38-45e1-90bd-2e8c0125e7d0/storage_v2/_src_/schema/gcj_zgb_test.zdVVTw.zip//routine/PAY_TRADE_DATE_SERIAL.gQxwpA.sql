create
    definer = part@`%` procedure PAY_TRADE_DATE_SERIAL(IN b_trad_date varchar(10))
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('PAY_TRADE_DATE_SERIAL', 'pay2_haike', 7, 100636)/*[cr_debug.1]*/;
-- 插入变量定义
DECLARE  b_trade_num int(11) DEFAULT 0; -- '交易笔数',
DECLARE  b_trade_money decimal(18,2) DEFAULT '0'; -- '总交易数'
DECLARE  b_trade_poundage decimal(8,2) DEFAULT '0'; -- '手续费'
DECLARE  b_swipe_credit_amt varchar(15) DEFAULT '0'; -- '刷卡信用卡T1'
DECLARE  b_swipe_credit0_amt varchar(15) DEFAULT '0'; -- '信用卡刷卡D0'
DECLARE  b_alipay_amt varchar(15) DEFAULT '0'; -- '支付宝T1'
DECLARE  b_alipay0_amt varchar(15) DEFAULT '0'; -- '支付宝D0'
DECLARE  b_swipe_debit_amt varchar(15) DEFAULT '0'; -- '储蓄刷卡T1'
DECLARE  b_swipe_debit0_amt varchar(15) DEFAULT '0'; -- '储蓄卡D0'
DECLARE  b_wechat_amt varchar(15) DEFAULT '0'; -- '微信T1'
DECLARE  b_wechat0_amt varchar(15) DEFAULT '0'; -- '微信D0'
DECLARE  b_quickpass_amt varchar(15) DEFAULT '0'; -- '云闪付T1'
DECLARE  b_quickpass0_amt varchar(15) DEFAULT '0'; -- '云闪付D0'
-- 游标相关定义 
DECLARE stopflg int DEFAULT 0;    -- 记录游标循环是否终止  CAST(ts.trad_poundage as DECIMAL(15,2))
-- 交易按天汇总，传入的trade_dates 为日期搜索条件
DECLARE grb_pro_cursor CURSOR FOR (
SELECT SUM(ts.trad_money) AS  trad_money,COUNT(*) AS trade_num,SUM(CAST(ts.trad_poundage as DECIMAL(15,2))) AS trade_poundage,
  SUM(CASE WHEN trade_type=0 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS swipe_credit_amt,
  SUM(CASE WHEN trade_type=0 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS swipe_credit0_amt,
  SUM(CASE WHEN trade_type=1 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS alipay_amt,
  SUM(CASE WHEN trade_type=1 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS alipay0_amt,
  SUM(CASE WHEN trade_type=2 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS wechat_amt,
  SUM(CASE WHEN trade_type=2 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS wechat0_amt,
  SUM(CASE WHEN trade_type=3 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS quickpass_amt,
  SUM(CASE WHEN trade_type=3 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS quickpass0_amt,
  SUM(CASE WHEN trade_type=4 AND is_timely=0 THEN ts.trad_money ELSE 0 END) AS swipe_debit_amt,
  SUM(CASE WHEN trade_type=4 AND is_timely=1 THEN ts.trad_money ELSE 0 END) AS swipe_debit0_amt
  from trad_serial ts WHERE trad_date=b_trad_date GROUP BY ts.trad_date
);                
DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('PAY_TRADE_DATE_SERIAL_Handler', 'PAY_TRADE_DATE_SERIAL', 'pay2_haike', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_num', b_trade_num, 'int(11)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_money', b_trade_money, 'decimal(18,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_poundage', b_trade_poundage, 'decimal(8,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_credit_amt', b_swipe_credit_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_credit0_amt', b_swipe_credit0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_alipay_amt', b_alipay_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_alipay0_amt', b_alipay0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_debit_amt', b_swipe_debit_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_debit0_amt', b_swipe_debit0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_wechat_amt', b_wechat_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_wechat0_amt', b_wechat0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_quickpass_amt', b_quickpass_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_quickpass0_amt', b_quickpass0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trad_date', b_trad_date, 'VARCHAR ( 10 )', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(34, 34, 39, 53, cr_stack_depth)/*[cr_debug.2]*/;
set stopflg=1;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;   -- 当无记录时，标记游标终止

CALL cr_debug.UPDATE_WATCH3('b_trad_date', b_trad_date, 'VARCHAR ( 10 )', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_num', b_trade_num, 'int(11)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_money', b_trade_money, 'decimal(18,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_poundage', b_trade_poundage, 'decimal(8,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_credit_amt', b_swipe_credit_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_credit0_amt', b_swipe_credit0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_alipay_amt', b_alipay_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_alipay0_amt', b_alipay0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_debit_amt', b_swipe_debit_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_debit0_amt', b_swipe_debit0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_wechat_amt', b_wechat_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_wechat0_amt', b_wechat0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_quickpass_amt', b_quickpass_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_quickpass0_amt', b_quickpass0_amt, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(2, 2, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(36, 36, 0, 20, cr_stack_depth)/*[cr_debug.2]*/;
OPEN grb_pro_cursor;
  CALL cr_debug.TRACE(37, 74, 2, 13, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT 
    CALL cr_debug.TRACE(38, 38, 4, 236, cr_stack_depth)/*[cr_debug.2]*/;
FETCH grb_pro_cursor INTO b_trade_money,b_trade_num,b_trade_poundage,b_swipe_credit_amt,b_swipe_credit0_amt,b_alipay_amt,b_alipay0_amt,b_wechat_amt,b_wechat0_amt,b_quickpass_amt,b_quickpass0_amt,b_swipe_debit_amt,b_swipe_debit0_amt;
CALL cr_debug.UPDATE_WATCH3('b_trade_money', b_trade_money, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_num', b_trade_num, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_poundage', b_trade_poundage, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_credit_amt', b_swipe_credit_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_credit0_amt', b_swipe_credit0_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_alipay_amt', b_alipay_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_alipay0_amt', b_alipay0_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_wechat_amt', b_wechat_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_wechat0_amt', b_wechat0_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_quickpass_amt', b_quickpass_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_quickpass0_amt', b_quickpass0_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_debit_amt', b_swipe_debit_amt, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_swipe_debit0_amt', b_swipe_debit0_amt, '', cr_stack_depth)/*[cr_debug.1]*/;    --   游标变量按序填充
		CALL cr_debug.TRACE(39, 72, 2, 10, cr_stack_depth)/*[cr_debug.2]*/;
IF stopflg != 1 THEN
				 CALL cr_debug.TRACE(40, 71, 5, 9, cr_stack_depth)/*[cr_debug.2]*/;
INSERT INTO trade_date_serial( 
							trade_date,
							trade_num,
							trade_money,
							trade_poundage,
							swipe_credit_amt,
							swipe_credit0_amt,
							alipay_amt,
							alipay0_amt,
							swipe_debit_amt,
							swipe_debit0_amt,
							wechat_amt,
							wechat0_amt,
							quickpass_amt,
							quickpass0_amt
							)
							VALUES(
								b_trad_date,
								b_trade_num,
								b_trade_money,
								b_trade_poundage,
								b_swipe_credit_amt,
								b_swipe_credit0_amt,
								b_alipay_amt,
								b_alipay0_amt,
								b_swipe_debit_amt,
								b_swipe_debit0_amt,
								b_wechat_amt,
								b_wechat0_amt,
								b_quickpass_amt,
								b_quickpass0_amt
							);
CALL cr_debug.UPDATE_SYSTEM_CALLS(102)/*[cr_debug.1]*/;
			END IF;
    UNTIL stopflg = 1
  END REPEAT;
CALL cr_debug.TRACE(75, 75, 0, 21, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE grb_pro_cursor;
CALL cr_debug.TRACE(76, 76, 0, 7, cr_stack_depth)/*[cr_debug.2]*/;
COMMIT;
CALL cr_debug.TRACE(77, 77, 0, 3, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


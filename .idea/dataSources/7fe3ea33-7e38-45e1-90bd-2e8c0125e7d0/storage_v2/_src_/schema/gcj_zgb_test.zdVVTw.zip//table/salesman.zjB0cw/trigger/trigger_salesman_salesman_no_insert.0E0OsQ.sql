create definer = part@`%` trigger trigger_salesman_salesman_no_insert
    before insert
    on salesman
    for each row
begin
	set new.salesman_no =ifnull(( select concat('B',LPAD((replace(max(salesman_no),'B','')+1),8,0)) from salesman),'B00000001');
end;


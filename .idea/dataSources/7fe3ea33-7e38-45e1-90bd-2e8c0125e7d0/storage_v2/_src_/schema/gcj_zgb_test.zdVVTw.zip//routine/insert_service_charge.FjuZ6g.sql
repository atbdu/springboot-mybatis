create
    definer = part@`%` procedure insert_service_charge(IN agent_no_test varchar(50))
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('insert_service_charge', 'pay2_haike', 7, 100636)/*[cr_debug.1]*/;
  DECLARE e_name1 varchar(255); -- '英文名'
  DECLARE policy_type_no1 varchar(255); -- 政策类型编号
  DECLARE policy_detail_no1 varchar(255); -- 政策明细编号
  DECLARE policy_type1 int(1); -- 政策类型大类
  DECLARE e_value1 varchar(255); -- 参数值
  DECLARE add_date1 varchar(255); -- 日期
  DECLARE add_time1 varchar(255); -- 时间
  DECLARE object_no1 varchar(255); -- 对象编号
  DECLARE object_type1 varchar(255); -- 对象类型
  DECLARE product_no1 varchar(255); -- 产品编号

  DECLARE trad_serial_no1 varchar(255); -- 交易流水
  DECLARE agent_no1 varchar(255); -- 代理上编号
  DECLARE device_no1 varchar(255); -- 机具编号
  DECLARE customer_no1 varchar(255); -- 商户编号
  DECLARE trade_type1 varchar(255); -- 交易类型
  DECLARE chnnel_customer_no1 varchar(255); -- 通道商户编号
  DECLARE trad_money1 varchar(255);-- 交易金额
  DECLARE total_money1 varchar(18); -- 总金额
  DECLARE deposit_amount1 varchar(18); -- 押金金额
  DECLARE stop_flag int(1) DEFAULT 0;

  DECLARE service_charge CURSOR FOR
  (
    -- 机具批量插入
    --    SELECT e_name,policy_type_no,policy_detail_no,policy_type,e_value,add_date,add_time,object_no,object_type,product_no FROM policy_detail_rim pdr
    --    WHERE pdr.object_type= '2' 
    --         GROUP BY  pdr.object_no 
    -- 代理批量插入
    --    SELECT e_name,policy_type_no,policy_detail_no,policy_type,e_value,add_date,add_time,object_no,object_type,product_no FROM policy_detail_rim pdr 
    --     WHERE (pdr.policy_type_no = '4' 
    --     OR pdr.policy_type_no = '11' 
    --     OR pdr.policy_type_no = '28' 
    --     OR pdr.policy_type_no = '32'
    --     OR pdr.policy_type_no = '38'
    --     OR pdr.policy_type_no = '54'
    --     OR pdr.policy_type_no = '58' 
    --     OR pdr.policy_type_no = '64' 
    --     OR pdr.policy_type_no = '80'
    --     OR pdr.policy_type_no = '84'
    --     OR pdr.policy_type_no = '90'
    --     OR pdr.policy_type_no = '106'
    --     ) 
    --     GROUP BY pdr.object_no,pdr.object_type,pdr.policy_type_no
    -- 按产品按代理按天汇总
    --     SELECT trad_date FROM trad_serial ts GROUP BY ts.trad_date
    -- 批量插入 分润0  机具编号，商户编号，交易类型，通道商户编号 交易金额
--     SELECT
--       ts.trad_serial_no,
--       ts.device_no,
--       ts.customer_no,
--       ts.trade_type,
--       ts.chnnel_customer_no,
--       ts.trad_money
--     FROM trad_serial ts
--     WHERE ts.trad_serial_no IN (SELECT
--         aad.serial_no
--       FROM agent_account_details aad
--       WHERE aad.account_type != 1
--       AND aad.act_rim NOT IN ('冻结抵扣', '提现', '货款抵扣')
--       GROUP BY aad.serial_no)
  -- 批量修改 激活1，2  机具编号，商户编号，通道商户编号
  -- SELECT d.device_no,d.customer_no,d.chnnel_customer_no FROM device d WHERE d.device_no IN(
  -- SELECT aad.serial_no FROM agent_account_details aad WHERE 
  -- aad.account_type IN (1,2) 
  -- AND aad.act_rim NOT IN ('冻结抵扣','提现','货款抵扣','提现到总账户')
  -- GROUP BY aad.serial_no)
  -- 批量修改机具状态 奖励状态
  -- SELECT ts.device_no,SUM(ts.trad_money) AS total_money,ts.deposit_amount FROM trad_serial ts 
  -- WHERE ts.trade_type IN('0','6')
  -- GROUP BY ts.device_no
  -- HAVING total_money BETWEEN 500 AND 799 AND ts.deposit_amount>0
 -- 批量插入政策
 SELECT agent_no from agent_agent WHERE parent_no=agent_no_test AND is_direct='1'
  );

  DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('insert_service_charge_Handler', 'insert_service_charge', 'pay2_haike', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('e_name1', e_name1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policy_type_no1', policy_type_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policy_detail_no1', policy_detail_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policy_type1', policy_type1, 'int(1)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('e_value1', e_value1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('add_date1', add_date1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('add_time1', add_time1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('object_no1', object_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('object_type1', object_type1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('customer_no1', customer_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_type1', trade_type1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('total_money1', total_money1, 'varchar(18)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('deposit_amount1', deposit_amount1, 'varchar(18)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stop_flag', stop_flag, 'int(1)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no_test', agent_no_test, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(79, 79, 41, 59, cr_stack_depth)/*[cr_debug.2]*/;
SET stop_flag = 1;
CALL cr_debug.UPDATE_WATCH3('stop_flag', stop_flag, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;

  CALL cr_debug.UPDATE_WATCH3('agent_no_test', agent_no_test, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('e_name1', e_name1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policy_type_no1', policy_type_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policy_detail_no1', policy_detail_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policy_type1', policy_type1, 'int(1)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('e_value1', e_value1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('add_date1', add_date1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('add_time1', add_time1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('object_no1', object_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('object_type1', object_type1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('customer_no1', customer_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_type1', trade_type1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, 'varchar(255)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('total_money1', total_money1, 'varchar(18)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('deposit_amount1', deposit_amount1, 'varchar(18)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stop_flag', stop_flag, 'int(1)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(2, 2, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(81, 81, 2, 22, cr_stack_depth)/*[cr_debug.2]*/;
OPEN service_charge;
  CALL cr_debug.TRACE(82, 120, 2, 13, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT
    -- 批量插入代理、机具
    --    FETCH service_charge INTO e_name1,policy_type_no1,policy_detail_no1,policy_type1,e_value1,add_date1,add_time1,object_no1,object_type1,product_no1;
    -- 按产品按代理按天汇总
    -- FETCH service_charge INTO add_date1;
    -- 批量修改 分润0  机具编号，商户编号，交易类型，通道商户编号 交易金额
--     FETCH service_charge INTO trad_serial_no1, device_no1, customer_no1, trade_type1, chnnel_customer_no1, trad_money1;
    -- 批量修改 激活1，2 机具编号，商户编号，通道商户编号
    --   FETCH service_charge INTO device_no1,customer_no1,chnnel_customer_no1;
    -- 批量修改激活激活状态，奖励状态
    --     FETCH service_charge INTO device_no1 ,total_money1,deposit_amount1;
-- 批量插入政策
   CALL cr_debug.TRACE(94, 94, 3, 39, cr_stack_depth)/*[cr_debug.2]*/;
FETCH service_charge INTO agent_no1;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
    CALL cr_debug.TRACE(95, 118, 4, 11, cr_stack_depth)/*[cr_debug.2]*/;
IF stop_flag != 1 THEN
      --  批量插入代理、机具
      --       INSERT INTO policy_detail_rim (e_name,policy_type_no,policy_detail_no,policy_type,e_value,add_date,add_time,object_no,object_type,product_no)
      --       VALUES('tx_money',policy_type_no1,policy_detail_no1,policy_type1,'0',add_date1,add_time1,object_no1,object_type1,product_no1);
      -- 按产品按代理按天汇总
      --   CALL PAY_TRADE_DATA_PRO_AGENT(add_date1);
      --   CALL PAY_TRADE_DATA_PRO_AGENT_0(add_date1);
      --  批量修改 分润0  机具编号，商户编号，交易类型，通道商户编号 交易金额
--       UPDATE agent_account_details aad
--       SET aad.customer_no = customer_no1,
--           aad.chnnel_customer_no = chnnel_customer_no1,
--           aad.device_no = device_no1,
--           aad.trade_type = trade_type1,
--           aad.trade_money = trad_money1
--       WHERE aad.serial_no = trad_serial_no1;
    -- 批量修改 激活1，2  机具编号，商户编号，交易类型，通道商户编号 
    --     UPDATE agent_account_details aad SET aad.customer_no=customer_no1,aad.chnnel_customer_no=chnnel_customer_no1,aad.device_no=device_no1
    --     WHERE aad.serial_no=device_no1;
    -- 批量修改激活激活状态，奖励状态
    --       UPDATE device d SET d.status='1',d.reward_status='0',d.active_date=NULL
    --       WHERE d.device_no=device_no1;
-- 批量插入政策
    CALL cr_debug.TRACE(117, 117, 4, 61, cr_stack_depth)/*[cr_debug.2]*/;
CALL insert_service_charge_port(agent_no1,agent_no_test);
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no_test', agent_no_test, '', cr_stack_depth)/*[cr_debug.1]*/;
    END IF;
  UNTIL stop_flag = 1
  END REPEAT;
  CALL cr_debug.TRACE(121, 121, 2, 23, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE service_charge;
  CALL cr_debug.TRACE(122, 122, 2, 9, cr_stack_depth)/*[cr_debug.2]*/;
COMMIT;
CALL cr_debug.TRACE(123, 123, 0, 3, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


create
    definer = part@`%` procedure flow_card_profit(IN agent_no1 varchar(50), IN policytype int,
                                                  IN device_no1 varchar(50), IN customer_no1 varchar(50),
                                                  IN chnnel_customer_no1 varchar(50), IN source_flag1 int,
                                                  IN trade_type1 int, IN product_no1 varchar(50),
                                                  IN trade_money1 decimal(10, 2)) comment '流量卡分润'
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('flow_card_profit', 'gcj_zgb_test', 7, 100636)/*[cr_debug.1]*/;
	DECLARE paren_agent VARCHAR(50);	
	DECLARE flow_money DECIMAL(6,2);
	DECLARE level_agent varchar(50);
  DECLARE is_satisfy_extra_flow int DEFAULT 0;-- 是否满足流量卡额外奖励0，不满足，1，满足
  DECLARE next_extra decimal(6,2) DEFAULT 0.00;
  DECLARE extra_flow_money decimal(6,2);-- 下级代理政策中的奖励金额
  DECLARE extra_flow_policy varchar(50); -- 流量卡额外奖励政策
	DECLARE stopflg INT DEFAULT 0;
	DECLARE policy_type INT; -- 政策类型编号
	DECLARE next_money DECIMAL(6,2) DEFAULT 0;
	DECLARE date_cursor CURSOR  FOR( -- 流量卡代理及政策
				select a.agent_no,pdr.e_value from policy_detail_rim pdr
	left join agent a on pdr.object_no=a.agent_no
	 where  pdr.policy_type_no=policytype  and pdr.object_no IN (SELECT parent_no
                               FROM agent_agent
                               WHERE agent_no = agent_no1)
																AND object_type = '1' order by a.agent_level desc);
	DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('flow_card_profit_Handler', 'flow_card_profit', 'gcj_zgb_test', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('paren_agent', paren_agent, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('flow_money', flow_money, 'DECIMAL(6,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('level_agent', level_agent, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('is_satisfy_extra_flow', is_satisfy_extra_flow, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('next_extra', next_extra, 'decimal(6,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('extra_flow_money', extra_flow_money, 'decimal(6,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('extra_flow_policy', extra_flow_policy, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policy_type', policy_type, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('next_money', next_money, 'DECIMAL(6,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policytype', policytype, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('customer_no1', customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('source_flag1', source_flag1, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_type1', trade_type1, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_money1', trade_money1, 'decimal(10,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(22, 22, 40, 54, cr_stack_depth)/*[cr_debug.2]*/;
set stopflg=1;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;   -- 当无记录时，标记游标终止
		CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policytype', policytype, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('customer_no1', customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('source_flag1', source_flag1, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_type1', trade_type1, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trade_money1', trade_money1, 'decimal(10,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('paren_agent', paren_agent, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('flow_money', flow_money, 'DECIMAL(6,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('level_agent', level_agent, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('is_satisfy_extra_flow', is_satisfy_extra_flow, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('next_extra', next_extra, 'decimal(6,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('extra_flow_money', extra_flow_money, 'decimal(6,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('extra_flow_policy', extra_flow_policy, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policy_type', policy_type, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('next_money', next_money, 'DECIMAL(6,2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(4, 4, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(23, 23, 2, 19, cr_stack_depth)/*[cr_debug.2]*/;
OPEN date_cursor; -- 打开游标
    CALL cr_debug.TRACE(24, 28, 4, 11, cr_stack_depth)/*[cr_debug.2]*/;
IF product_no1='P00000001' THEN
      CALL cr_debug.TRACE(25, 25, 6, 35, cr_stack_depth)/*[cr_debug.2]*/;
SET extra_flow_policy = '17';
CALL cr_debug.UPDATE_WATCH3('extra_flow_policy', extra_flow_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
    ELSEIF product_no1='P00000002' THEN
    CALL cr_debug.TRACE(27, 27, 4, 31, cr_stack_depth)/*[cr_debug.2]*/;
set extra_flow_policy='19';
CALL cr_debug.UPDATE_WATCH3('extra_flow_policy', extra_flow_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
    END IF;
			CALL cr_debug.TRACE(29, 66, 3, 14, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT
				CALL cr_debug.TRACE(30, 30, 4, 50, cr_stack_depth)/*[cr_debug.2]*/;
FETCH date_cursor INTO level_agent,flow_money;
CALL cr_debug.UPDATE_WATCH3('level_agent', level_agent, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('flow_money', flow_money, '', cr_stack_depth)/*[cr_debug.1]*/;
				
				CALL cr_debug.TRACE(32, 63, 4, 11, cr_stack_depth)/*[cr_debug.2]*/;
IF(stopflg != 1) THEN	
						
								CALL cr_debug.TRACE(34, 34, 8, 138, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE agent_account SET wait_account = wait_account + flow_money -next_money WHERE agent_no = level_agent AND account_type = '8';
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/;
								CALL cr_debug.TRACE(35, 39, 8, 53, cr_stack_depth)/*[cr_debug.2]*/;
INSERT INTO `agent_account_details` 
							(`serial_no`, `agent_no`, `amount`, `set_date`, `set_time`, `account_type`,`product_no`,  `act_rim`,device_no,customer_no,chnnel_customer_no,
              source_flag,trade_type,trade_money) 
							VALUES (device_no1, level_agent, (flow_money-next_money), CURDATE(), CURTIME(), '8',product_no1, '流量卡分润',device_no1,customer_no1,chnnel_customer_no1,
              source_flag1,trade_type1,trade_money1);
CALL cr_debug.UPDATE_SYSTEM_CALLS(102)/*[cr_debug.1]*/;
							CALL cr_debug.TRACE(40, 40, 7, 35, cr_stack_depth)/*[cr_debug.2]*/;
SET next_money = flow_money;
CALL cr_debug.UPDATE_WATCH3('next_money', next_money, '', cr_stack_depth)/*[cr_debug.1]*/;
              -- 流量卡额外奖励 
              CALL cr_debug.TRACE(42, 62, 14, 21, cr_stack_depth)/*[cr_debug.2]*/;
IF extra_flow_policy IS NOT NULL THEN -- 流量卡额外奖励政策不为空
                -- 流量卡额外奖励是否配置
                CALL cr_debug.TRACE(44, 44, 16, 163, cr_stack_depth)/*[cr_debug.2]*/;
SET is_satisfy_extra_flow=(SELECT ap.front_end_display FROM agent_policy ap WHERE ap.agent_no=level_agent AND ap.policy_type_no=extra_flow_policy);
CALL cr_debug.UPDATE_WATCH3('is_satisfy_extra_flow', is_satisfy_extra_flow, '', cr_stack_depth)/*[cr_debug.1]*/;
                CALL cr_debug.TRACE(45, 61, 16, 23, cr_stack_depth)/*[cr_debug.2]*/;
IF is_satisfy_extra_flow =1 THEN -- 配置了流量卡额外奖励
                  CALL cr_debug.TRACE(46, 47, 18, 71, cr_stack_depth)/*[cr_debug.2]*/;
SET extra_flow_money=(SELECT pdr.e_value FROM policy_detail_rim pdr WHERE pdr.object_no=level_agent AND pdr.policy_type_no=extra_flow_policy AND
                  pdr.e_name='flow_cash_reward' AND pdr.object_type=1);
CALL cr_debug.UPDATE_WATCH3('extra_flow_money', extra_flow_money, '', cr_stack_depth)/*[cr_debug.1]*/;

                  CALL cr_debug.TRACE(49, 60, 18, 25, cr_stack_depth)/*[cr_debug.2]*/;
IF (extra_flow_money IS NOT NULL AND extra_flow_money !=0) THEN 
              
                    CALL cr_debug.TRACE(51, 52, 20, 49, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE agent_account aa SET aa.wait_account=aa.wait_account +extra_flow_money-next_extra WHERE aa.account_type=8 
                    AND aa.agent_no =level_agent;
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/;
                    -- 添加记录
                      CALL cr_debug.TRACE(54, 58, 22, 26, cr_stack_depth)/*[cr_debug.2]*/;
INSERT INTO `agent_account_details` 
      							(`serial_no`, `agent_no`, `amount`, `set_date`, `set_time`, `account_type`,`product_no`,  `act_rim`,device_no,customer_no,chnnel_customer_no,
                    source_flag) 
      							VALUES (device_no1, level_agent, (extra_flow_money-next_extra), CURDATE(), CURTIME(), '8',product_no1, '流量卡额外分润',device_no1,customer_no1,chnnel_customer_no1,
                    '15');
CALL cr_debug.UPDATE_SYSTEM_CALLS(102)/*[cr_debug.1]*/;
      						  CALL cr_debug.TRACE(59, 59, 14, 48, cr_stack_depth)/*[cr_debug.2]*/;
SET next_extra = extra_flow_money;
CALL cr_debug.UPDATE_WATCH3('next_extra', next_extra, '', cr_stack_depth)/*[cr_debug.1]*/;
                  END IF;
                END IF;
              END IF;
				END IF;
				CALL cr_debug.TRACE(64, 64, 4, 107, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE device_flow_card SET flow_card_status='1',flow_card_date = CURDATE() where device_no=device_no1;
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/;
			UNTIL stopflg =1
			END REPEAT;
		CALL cr_debug.TRACE(67, 67, 2, 20, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE date_cursor;	-- 关闭游标
	CALL cr_debug.TRACE(68, 68, 1, 4, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


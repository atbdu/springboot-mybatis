create
    definer = part@`%` procedure PAY_TRADE_DATA_MONTH_AGENT_0(IN b_trade_date varchar(10)) comment '代理按月结算'
BEGIN
  -- 插入变量定义
  DECLARE b_agent_no varchar(10);    -- 代理商编号
  DECLARE b_trade_num int(11) DEFAULT 0; -- '交易笔数',
  DECLARE b_trade_money varchar(15) DEFAULT '0'; -- '总交易数'
 --  DECLARE b_all_device_num int(11) DEFAULT 0; -- 总机器数(已激活)
 --  DECLARE b_trade_device_num int(11) DEFAULT 0; -- '当日交易终端数'
 --  DECLARE b_new_device int(7) DEFAULT 0; -- '新增终端个数'
 
  -- 游标相关定义 
  DECLARE stopflg int DEFAULT 0;    -- 记录游标循环是否终止 
  -- 按代理，按月汇总交易，传入的trade_dates 为日期搜索条件
  DECLARE grb_cursor CURSOR FOR
  (SELECT
      SUM(tda.trade_money) AS trade_money, -- '总交易数'
      tda.agent_no AS agent_no, -- 代理商编号
      COUNT(*) AS trade_num  -- '交易笔数',
     --  COUNT(DISTINCT (system_device_no)) AS trade_device_num  -- 总机器数(已激活)
    FROM trade_date_agent tda 
    -- 截取年月日期 
    WHERE CONCAT((SELECT
        DATE_FORMAT(DATE_SUB(tda.trade_date, INTERVAL 0 MONTH), '%m')), (SELECT
        DATE_FORMAT(DATE_SUB(tda.trade_date, INTERVAL 0 year), '%Y')))
         =
         CONCAT((SELECT
        DATE_FORMAT(DATE_SUB(b_trade_date, INTERVAL 0 MONTH), '%m')), (SELECT
        DATE_FORMAT(DATE_SUB(b_trade_date, INTERVAL 0 year), '%Y')))
       GROUP BY tda.agent_no
        );
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET stopflg = 1;   -- 当无记录时，标记游标终止

  OPEN grb_cursor;
  REPEAT
    FETCH grb_cursor INTO b_trade_money,b_agent_no, b_trade_num ;-- , b_trade_device_num, b_swipe_credit_amt, b_swipe_credit0_amt, b_alipay_amt, b_alipay0_amt, b_wechat_amt, b_wechat0_amt, b_quickpass_amt, b_quickpass0_amt, b_swipe_debit_amt, b_swipe_debit0_amt;    --   游标变量按序填充
    IF stopflg != 1 THEN      -- 如果游标没有结束
--       SELECT
--         COUNT(*) AS all_device_num, -- 总机器数
--         SUM(CASE WHEN CONCAT((SELECT
--         DATE_FORMAT(DATE_SUB(add_date, INTERVAL 0 MONTH), '%m')), (SELECT
--         DATE_FORMAT(DATE_SUB(add_date, INTERVAL 0 year), '%Y')))
--          =
--          CONCAT((SELECT
--         DATE_FORMAT(DATE_SUB(b_trade_date, INTERVAL 0 MONTH), '%m')), (SELECT
--         DATE_FORMAT(DATE_SUB(b_trade_date, INTERVAL 0 year), '%Y')))
--         THEN 1 ELSE 0 END) AS new_device INTO b_all_device_num, b_new_device  -- 总机器数  ； 新增机器数
--       FROM device
--       WHERE agent_no = b_agent_no
--       AND customer_no IS NOT NULL;
--       IF b_new_device IS NULL THEN
--         SET b_new_device = 0;
--       END IF;
      
      INSERT INTO trade_date_month_agent (agent_no,
      trade_month,
      trade_num,
      trade_money,
--       all_device_num,
--       trade_device_num,
--       new_device,
--       swipe_credit_amt,
--       swipe_credit0_amt,
--       alipay_amt,
--       alipay0_amt,
--       swipe_debit_amt,
--       swipe_debit0_amt,
--       wechat_amt,
--       wechat0_amt,
--       quickpass_amt,
--       quickpass0_amt,
      direct_customer)
        VALUES (b_agent_no,
     LEFT(b_trade_date,7), -- 月份
      b_trade_num,
      b_trade_money,
--       b_all_device_num,
--       b_trade_device_num,
--       b_new_device,
--       b_swipe_credit_amt,
--       b_swipe_credit0_amt,
--       b_alipay_amt,
--       b_alipay0_amt,
--       b_swipe_debit_amt,
--       b_swipe_debit0_amt,
--       b_wechat_amt,
--       b_wechat0_amt,
--       b_quickpass_amt,
--       b_quickpass0_amt,
      0);
    END IF;
  UNTIL stopflg = 1
  END REPEAT;

  CLOSE grb_cursor;
  COMMIT;
END;


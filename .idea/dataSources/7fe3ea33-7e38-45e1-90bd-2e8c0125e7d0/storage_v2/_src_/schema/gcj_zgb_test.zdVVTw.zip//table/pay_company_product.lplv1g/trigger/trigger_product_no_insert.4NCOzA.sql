create definer = part@`%` trigger trigger_product_no_insert
    before insert
    on pay_company_product
    for each row
begin
	set new.product_no =ifnull(( select concat('P',LPAD((replace(max(product_no),'P','')+1),8,0)) from pay_company_product),'P00000001');
end;


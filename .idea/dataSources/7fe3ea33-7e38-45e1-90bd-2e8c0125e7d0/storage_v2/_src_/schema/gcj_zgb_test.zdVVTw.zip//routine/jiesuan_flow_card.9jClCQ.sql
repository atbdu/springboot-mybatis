create
    definer = part@`%` procedure jiesuan_flow_card()
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('jiesuan_flow_card', 'pay2_haike', 7, 100636)/*[cr_debug.1]*/;
	DECLARE product VARCHAR(50);
	DECLARE custom_no1 VARCHAR(50);
	DECLARE chnnel_customer_no1 VARCHAR(50);
	DECLARE count_details int DEFAULT 0;
	DECLARE device_no1 VARCHAR(50);
	DECLARE stopflg INT DEFAULT 0;
	DECLARE pay_type INT;
	DECLARE agent_no1 VARCHAR(50);
	DECLARE date_cursor CURSOR  FOR( -- 终端激活
			SELECT device_no,agent_no,trade_type,customer_no,chnnel_customer_no,product_no
			from trad_serial where (product_no='P00000003' OR product_no='P00000006' OR product_no='P00000012') 
			AND flow_card_amount!=0
	);
	DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('jiesuan_flow_card_Handler', 'jiesuan_flow_card', 'pay2_haike', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('custom_no1', custom_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('pay_type', pay_type, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(16, 16, 40, 54, cr_stack_depth)/*[cr_debug.2]*/;
set stopflg=1;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;   -- 当无记录时，标记游标终止
		CALL cr_debug.UPDATE_WATCH3('product', product, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('custom_no1', custom_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('pay_type', pay_type, 'INT', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'VARCHAR(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(2, 2, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(17, 17, 2, 19, cr_stack_depth)/*[cr_debug.2]*/;
OPEN date_cursor; -- 打开游标
			CALL cr_debug.TRACE(18, 35, 3, 14, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT
				CALL cr_debug.TRACE(19, 19, 4, 96, cr_stack_depth)/*[cr_debug.2]*/;
FETCH date_cursor INTO device_no1,agent_no1,pay_type,custom_no1,chnnel_customer_no1,product;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('pay_type', pay_type, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('custom_no1', custom_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, '', cr_stack_depth)/*[cr_debug.1]*/;
				CALL cr_debug.TRACE(20, 33, 4, 11, cr_stack_depth)/*[cr_debug.2]*/;
IF(stopflg != 1) THEN	
						CALL cr_debug.TRACE(21, 21, 6, 121, cr_stack_depth)/*[cr_debug.2]*/;
SELECT COUNT(1) FROM agent_account_details WHERE device_no=device_no1 AND source_flag=4 LIMIT 1 INTO count_details;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, '', cr_stack_depth)/*[cr_debug.1]*/;
						CALL cr_debug.TRACE(22, 32, 6, 13, cr_stack_depth)/*[cr_debug.2]*/;
IF count_details =0 THEN
							CALL cr_debug.TRACE(23, 31, 7, 14, cr_stack_depth)/*[cr_debug.2]*/;
IF product = 'P00000003' THEN -- 6
								CALL cr_debug.TRACE(24, 24, 8, 113, cr_stack_depth)/*[cr_debug.2]*/;
CALL flow_card_profit(agent_no1, 195, device_no1, custom_no1, chnnel_customer_no1, 4, pay_type, product);
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('custom_no1', custom_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('pay_type', pay_type, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, '', cr_stack_depth)/*[cr_debug.1]*/;
							ELSEIF product = 'P00000006' THEN -- 6
								CALL cr_debug.TRACE(26, 26, 8, 113, cr_stack_depth)/*[cr_debug.2]*/;
CALL flow_card_profit(agent_no1, 196, device_no1, custom_no1, chnnel_customer_no1, 4, pay_type, product);
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('custom_no1', custom_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('pay_type', pay_type, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, '', cr_stack_depth)/*[cr_debug.1]*/;
							-- ELSEIF product = 'P00000009' THEN -- 6
								-- CALL flow_card_profit(agent_no1, 195, device_no1, custom_no1, chnnel_customer_no1, 4, pay_type, product);
							ELSEIF product = 'P00000012' THEN -- 6
								CALL cr_debug.TRACE(30, 30, 8, 113, cr_stack_depth)/*[cr_debug.2]*/;
CALL flow_card_profit(agent_no1, 197, device_no1, custom_no1, chnnel_customer_no1, 4, pay_type, product);
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('custom_no1', custom_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('chnnel_customer_no1', chnnel_customer_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('pay_type', pay_type, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, '', cr_stack_depth)/*[cr_debug.1]*/;
							END IF;
						END IF;
				END IF;
			UNTIL stopflg =1
			END REPEAT;
		CALL cr_debug.TRACE(36, 36, 2, 20, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE date_cursor;	-- 关闭游标
CALL cr_debug.TRACE(37, 37, 0, 3, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


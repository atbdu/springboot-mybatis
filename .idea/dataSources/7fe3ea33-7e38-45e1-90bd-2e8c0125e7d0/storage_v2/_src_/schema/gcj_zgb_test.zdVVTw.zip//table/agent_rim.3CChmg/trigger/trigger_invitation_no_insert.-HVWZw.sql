create definer = part@`%` trigger trigger_invitation_no_insert
    before insert
    on agent_rim
    for each row
begin
	set new.invitation_no =( select ifnull(max(invitation_no)+1,'15987651') from agent_rim);
end;


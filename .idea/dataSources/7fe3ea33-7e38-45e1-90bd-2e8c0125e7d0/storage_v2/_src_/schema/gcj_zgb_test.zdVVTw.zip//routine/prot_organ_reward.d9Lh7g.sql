create
    definer = part@`%` procedure prot_organ_reward(IN trad_serial_no1 varchar(50), IN organ_reward_policy int(5),
                                                   IN product varchar(50), IN trad_money1 varchar(15),
                                                   IN agent_no1 varchar(50), IN device1 varchar(50),
                                                   IN customer_no1 varchar(50), IN chnnel_customer_no1 varchar(50),
                                                   IN pay_type int(2), IN trad_money2 varchar(15)) comment '机构奖励'
BEGIN
  DECLARE t_error INTEGER DEFAULT 0; -- 错误标识
  DECLARE reward_earnings varchar(18) DEFAULT 0 ; -- 奖励收益
  DECLARE policy_rate varchar(10); -- 奖励费率
	DECLARE stop_flag INT DEFAULT 0;
	
  DECLARE organ_reward CURSOR FOR (

 select pdr.e_value FROM agent_policy ap 
 LEFT JOIN policy_detail_rim pdr  ON pdr.policy_type_no=ap.policy_type_no 
 AND ap.agent_no=pdr.object_no
 AND ap.front_end_display='1'
 WHERE 
    pdr.object_no=agent_no1
    AND pdr.policy_type_no = organ_reward_policy
    AND pdr.object_type='1' 
  );
  
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1; -- 异常标识
	 DECLARE CONTINUE HANDLER FOR NOT FOUND set stop_flag=1;
   START TRANSACTION;

   	OPEN organ_reward; 
			REPEAT
				FETCH organ_reward INTO policy_rate;
				IF policy_rate IS NULL THEN -- 政策类型中的值为空的话，改变错误标识状态
					SET t_error = 1;
				END IF;
   	IF stop_flag != 1 THEN
      SET reward_earnings = policy_rate*trad_money1/10000;
      IF reward_earnings IS NULL THEN 
       SET t_error=1;
       END IF;

       UPDATE agent_account SET wait_account = wait_account+TRUNCATE(reward_earnings,2) 
       WHERE agent_no = agent_no1 AND account_type = '0'; -- 插入金额

       INSERT INTO agent_account_details(serial_no,agent_no,amount,set_date,set_time,product_no,account_type,act_rim,device_no,customer_no,chnnel_customer_no,trade_type,srouce_flag,trade_money)
       VALUES(trad_serial_no1,agent_no1,TRUNCATE(reward_earnings,2),CURDATE(),CURTIME(),product,'0','机构奖励',device1,customer_no1,chnnel_customer_no1,pay_type,'2',trad_money2);   
    END IF ;
        	UNTIL stop_flag = 1
			END REPEAT;
			CLOSE organ_reward;
	  	IF t_error= 1 THEN
			ROLLBACK;
	  	ELSE
			COMMIT;
		END IF;
END;


create
    definer = part@`%` procedure activate_device_procedure() comment '激活奖励'
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('activate_device_procedure', 'gcj_zgb_test', 7, 100636)/*[cr_debug.1]*/;
  DECLARE count_details int DEFAULT 0; -- 明细表中的记录数
  DECLARE total_yajin decimal(15, 2); -- 机具总押金
  DECLARE total_flow_card decimal(15, 2); -- 流量卡总金额
  DECLARE product varchar(50);
  DECLARE stop_flag int DEFAULT 0;
  DECLARE device_no1 varchar(50); -- 设备终端号
  DECLARE agent_no1 varchar(50); -- 终端直属代理
  DECLARE total_money decimal(18, 2); -- 每一个终端的贷记卡累计消费金额
  DECLARE select_activite_cursor CURSOR FOR
  (
    -- 查询绑定日期小于30天，并且没有激活的终端，统计金额，同时完成奖励
    SELECT
      MAX(t1.agent_no) AS agent_no,
      t1.device_no,
      SUM(trad_money) AS total,
      MAX(t1.product_no) AS product_no
    FROM device t1
      LEFT JOIN trad_serial t2
        ON t1.device_no = t2.device_no
    WHERE DATEDIFF(NOW(), t1.bind_time) <= 30
    AND t1.reward_status = '0'
    AND (trade_type = '0'
    OR trade_type = '6'
    OR trade_type = '9')
    GROUP BY t2.device_no);
  DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('activate_device_procedure_Handler', 'activate_device_procedure', 'gcj_zgb_test', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('total_yajin', total_yajin, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('total_flow_card', total_flow_card, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stop_flag', stop_flag, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('total_money', total_money, 'decimal(18, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(29, 29, 41, 59, cr_stack_depth)/*[cr_debug.2]*/;
SET stop_flag = 1;
CALL cr_debug.UPDATE_WATCH3('stop_flag', stop_flag, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;   -- 当无记录时，标记游标终止
  CALL cr_debug.UPDATE_WATCH3('count_details', count_details, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('total_yajin', total_yajin, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('total_flow_card', total_flow_card, 'decimal(15, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stop_flag', stop_flag, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('total_money', total_money, 'decimal(18, 2)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(3, 3, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(30, 30, 2, 30, cr_stack_depth)/*[cr_debug.2]*/;
OPEN select_activite_cursor;
  CALL cr_debug.TRACE(31, 67, 2, 13, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT
    CALL cr_debug.TRACE(32, 32, 4, 82, cr_stack_depth)/*[cr_debug.2]*/;
FETCH select_activite_cursor INTO agent_no1, device_no1, total_money, product;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('total_money', total_money, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, '', cr_stack_depth)/*[cr_debug.1]*/;
    -- 贷记卡交易总押金
    CALL cr_debug.TRACE(34, 40, 4, 45, cr_stack_depth)/*[cr_debug.2]*/;
SELECT
      SUM(ts.deposit_amount)
    FROM trad_serial ts
    WHERE device_no = device_no1
    AND (ts.trade_type = '0'
    OR ts.trade_type = '6'
    OR ts.trade_type = '9') INTO total_yajin;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('total_yajin', total_yajin, '', cr_stack_depth)/*[cr_debug.1]*/;
    -- 贷记卡交易总流量费
    CALL cr_debug.TRACE(42, 48, 4, 49, cr_stack_depth)/*[cr_debug.2]*/;
SELECT
      SUM(ts.flow_card_amount)
    FROM trad_serial ts
    WHERE device_no = device_no1
    AND (ts.trade_type = '0'
    OR ts.trade_type = '6'
    OR ts.trade_type = '9') INTO total_flow_card;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('total_flow_card', total_flow_card, '', cr_stack_depth)/*[cr_debug.1]*/;

    CALL cr_debug.TRACE(50, 54, 4, 47, cr_stack_depth)/*[cr_debug.2]*/;
SELECT
      COUNT(1)
    FROM agent_account_details aad
    WHERE aad.serial_no = device_no1
    AND aad.source_flag = 5 INTO count_details;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, '', cr_stack_depth)/*[cr_debug.1]*/;

    CALL cr_debug.TRACE(56, 65, 4, 11, cr_stack_depth)/*[cr_debug.2]*/;
IF stop_flag != 1 THEN
      CALL cr_debug.TRACE(57, 64, 6, 13, cr_stack_depth)/*[cr_debug.2]*/;
IF (total_money - total_yajin - total_flow_card) >= 2000
        AND count_details = 0 THEN -- 机器激活
        CALL cr_debug.TRACE(59, 63, 8, 15, cr_stack_depth)/*[cr_debug.2]*/;
IF product = 'P00000001' THEN -- 电签
          CALL cr_debug.TRACE(60, 60, 10, 66, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_profit_producer(device_no1, '1');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
        ELSEIF product = 'P00000002' THEN
          CALL cr_debug.TRACE(62, 62, 10, 66, cr_stack_depth)/*[cr_debug.2]*/;
CALL everyone_activate_profit_producer(device_no1, '9');
CALL cr_debug.UPDATE_WATCH3('device_no1', device_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
        END IF;
      END IF;
    END IF;
  UNTIL stop_flag = 1
  END REPEAT;
  CALL cr_debug.TRACE(68, 68, 2, 31, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE select_activite_cursor;
CALL cr_debug.TRACE(69, 69, 0, 3, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


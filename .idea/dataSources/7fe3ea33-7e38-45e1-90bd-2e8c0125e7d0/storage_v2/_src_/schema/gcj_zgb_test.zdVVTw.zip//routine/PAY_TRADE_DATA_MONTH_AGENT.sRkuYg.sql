create
    definer = part@`%` procedure PAY_TRADE_DATA_MONTH_AGENT(IN b_trade_date varchar(10)) comment '代理按月结算'
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('PAY_TRADE_DATA_MONTH_AGENT', 'pay2.0', 7, 100636)/*[cr_debug.1]*/;
  -- 插入变量定义
  DECLARE b_agent_no varchar(10);    -- 代理商编号
  DECLARE b_trade_num int(11) DEFAULT 0; -- '交易笔数',
  DECLARE b_trade_money varchar(15) DEFAULT '0'; -- '总交易数'
 --  DECLARE b_all_device_num int(11) DEFAULT 0; -- 总机器数(已激活)
 --  DECLARE b_trade_device_num int(11) DEFAULT 0; -- '当日交易终端数'
 --  DECLARE b_new_device int(7) DEFAULT 0; -- '新增终端个数'
 
  -- 游标相关定义 
  DECLARE stopflg int DEFAULT 0;    -- 记录游标循环是否终止 
  -- 按代理，按月汇总交易，传入的trade_dates 为日期搜索条件
  DECLARE grb_cursor CURSOR FOR
  (SELECT
      SUM(tda.trade_money) AS trade_money, -- '总交易数'
      tda.agent_no AS agent_no, -- 代理商编号
      COUNT(*) AS trade_num  -- '交易笔数',
     --  COUNT(DISTINCT (system_device_no)) AS trade_device_num  -- 总机器数(已激活)
    FROM trade_date_agent tda 
    -- 截取年月日期 
    WHERE CONCAT((SELECT
        DATE_FORMAT(DATE_SUB(tda.trade_date, INTERVAL 0 MONTH), '%m')), (SELECT
        DATE_FORMAT(DATE_SUB(tda.trade_date, INTERVAL 0 year), '%Y')))
         =
         CONCAT((SELECT
        DATE_FORMAT(DATE_SUB(b_trade_date, INTERVAL 0 MONTH), '%m')), (SELECT
        DATE_FORMAT(DATE_SUB(b_trade_date, INTERVAL 0 year), '%Y')))
       GROUP BY tda.agent_no
        );
  DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('PAY_TRADE_DATA_MONTH_AGENT_Handler', 'PAY_TRADE_DATA_MONTH_AGENT', 'pay2.0', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_agent_no', b_agent_no, 'varchar(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_num', b_trade_num, 'int(11)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_money', b_trade_money, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_date', b_trade_date, 'varchar(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(32, 32, 41, 57, cr_stack_depth)/*[cr_debug.2]*/;
SET stopflg = 1;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;   -- 当无记录时，标记游标终止

  CALL cr_debug.UPDATE_WATCH3('b_trade_date', b_trade_date, 'varchar(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_agent_no', b_agent_no, 'varchar(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_num', b_trade_num, 'int(11)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_money', b_trade_money, 'varchar(15)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(3, 3, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(34, 34, 2, 18, cr_stack_depth)/*[cr_debug.2]*/;
OPEN grb_cursor;
  CALL cr_debug.TRACE(35, 93, 2, 13, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT
    CALL cr_debug.TRACE(36, 36, 4, 65, cr_stack_depth)/*[cr_debug.2]*/;
FETCH grb_cursor INTO b_trade_money,b_agent_no, b_trade_num ;
CALL cr_debug.UPDATE_WATCH3('b_trade_money', b_trade_money, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_agent_no', b_agent_no, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('b_trade_num', b_trade_num, '', cr_stack_depth)/*[cr_debug.1]*/;-- , b_trade_device_num, b_swipe_credit_amt, b_swipe_credit0_amt, b_alipay_amt, b_alipay0_amt, b_wechat_amt, b_wechat0_amt, b_quickpass_amt, b_quickpass0_amt, b_swipe_debit_amt, b_swipe_debit0_amt;    --   游标变量按序填充
    CALL cr_debug.TRACE(37, 91, 4, 11, cr_stack_depth)/*[cr_debug.2]*/;
IF stopflg != 1 THEN      -- 如果游标没有结束
--       SELECT
--         COUNT(*) AS all_device_num, -- 总机器数
--         SUM(CASE WHEN CONCAT((SELECT
--         DATE_FORMAT(DATE_SUB(add_date, INTERVAL 0 MONTH), '%m')), (SELECT
--         DATE_FORMAT(DATE_SUB(add_date, INTERVAL 0 year), '%Y')))
--          =
--          CONCAT((SELECT
--         DATE_FORMAT(DATE_SUB(b_trade_date, INTERVAL 0 MONTH), '%m')), (SELECT
--         DATE_FORMAT(DATE_SUB(b_trade_date, INTERVAL 0 year), '%Y')))
--         THEN 1 ELSE 0 END) AS new_device INTO b_all_device_num, b_new_device  -- 总机器数  ； 新增机器数
--       FROM device
--       WHERE agent_no = b_agent_no
--       AND customer_no IS NOT NULL;
--       IF b_new_device IS NULL THEN
--         SET b_new_device = 0;
--       END IF;
      
      CALL cr_debug.TRACE(55, 90, 6, 9, cr_stack_depth)/*[cr_debug.2]*/;
INSERT INTO trade_date_month_agent (agent_no,
      trade_month,
      trade_num,
      trade_money,
--       all_device_num,
--       trade_device_num,
--       new_device,
--       swipe_credit_amt,
--       swipe_credit0_amt,
--       alipay_amt,
--       alipay0_amt,
--       swipe_debit_amt,
--       swipe_debit0_amt,
--       wechat_amt,
--       wechat0_amt,
--       quickpass_amt,
--       quickpass0_amt,
      direct_customer)
        VALUES (b_agent_no,
     LEFT(b_trade_date,7), -- 月份
      b_trade_num,
      b_trade_money,
--       b_all_device_num,
--       b_trade_device_num,
--       b_new_device,
--       b_swipe_credit_amt,
--       b_swipe_credit0_amt,
--       b_alipay_amt,
--       b_alipay0_amt,
--       b_swipe_debit_amt,
--       b_swipe_debit0_amt,
--       b_wechat_amt,
--       b_wechat0_amt,
--       b_quickpass_amt,
--       b_quickpass0_amt,
      1);
CALL cr_debug.UPDATE_SYSTEM_CALLS(102)/*[cr_debug.1]*/;
    END IF;
  UNTIL stopflg = 1
  END REPEAT;

  CALL cr_debug.TRACE(95, 95, 2, 19, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE grb_cursor;
  CALL cr_debug.TRACE(96, 96, 2, 9, cr_stack_depth)/*[cr_debug.2]*/;
COMMIT;
CALL cr_debug.TRACE(97, 97, 0, 3, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


create
    definer = part@`%` procedure everyone_activate_profit_producer(IN device_no1 varchar(50), IN policytype int)
BEGIN
	DECLARE t_error INTEGER DEFAULT 0;  -- 定义错误标识  
  DECLARE custom_no1 varchar(50); -- 客户编号
  DECLARE chnnel_customer_no1 varchar(50);-- 商户通道编号
	DECLARE product_no1 VARCHAR(50); -- 产品编号
	DECLARE agent_level1 INT; -- 代理级别
	DECLARE jifen INT DEFAULT 0; -- 奖励积分
	DECLARE first_into INT DEFAULT 1;
	DECLARE system_device_no1 VARCHAR(50);
	DECLARE next_money DECIMAL(15,2) DEFAULT 0;
	DECLARE money DECIMAL(15,2);
	DECLARE level_agent_no VARCHAR(50);
	DECLARE stopflg INT DEFAULT 0;
	DECLARE first_agent_no VARCHAR(50); -- 设备的直属代理
	DECLARE date_cursor CURSOR  FOR( -- 终端激活SELECT * FROM agent_agent aa WHERE aa.agent_no='A00000038'
			SELECT b.*,a.agent_level FROM
				(SELECT pdr.e_value,pdr.object_no FROM policy_detail_rim pdr WHERE policy_type_no = policytype AND object_type='1' AND object_no in (
				SELECT aa.parent_no FROM agent_agent aa WHERE aa.agent_no = (
				SELECT agent_no FROM device d WHERE d.device_no = device_no1
				)
				)	AND e_name ='cash_reward' ) b
				INNER JOIN 
				 agent a ON a.agent_no = b.object_no ORDER BY a.agent_level DESC
	);
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1; -- 发现sql异常设置为1
	DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止

		-- 事务开始
		START TRANSACTION;
			OPEN date_cursor; -- 打开游标
				REPEAT
					FETCH date_cursor INTO money,level_agent_no,agent_level1;
					
					IF(stopflg != 1) THEN	
							SELECT product_no,customer_no,chnnel_customer_no FROM device WHERE device_no = device_no1 INTO product_no1,custom_no1,chnnel_customer_no1;-- 查询当前交易使用的产品编号
							-- 判断政策金额是不是为空,改变事务状态
							 IF money IS NULL THEN
									SET t_error = 1;
								END IF;
							-- 更新待入账账户金额
							UPDATE agent_account SET wait_account = wait_account + money - next_money WHERE agent_no =level_agent_no AND account_type='1';
							-- 添加记录
							INSERT INTO `agent_account_details` 
								(`serial_no`, `agent_no`, `amount`, `set_date`, `set_time`, `account_type`, `product_no`,`act_rim`,
                device_no,customer_no,chnnel_customer_no,source_flag) 
								VALUES (device_no1, level_agent_no, (money - next_money), CURDATE(), CURTIME(), '1',product_no1, '激活分润',
                device_no1,custom_no1,chnnel_customer_no1,5);
							-- 改变状态
								UPDATE device SET reward_status = 1,`status`='2',active_date=CURDATE() WHERE device_no=device_no1;	
								
							SET next_money = money;

					END IF;
				UNTIL stopflg =1
				END REPEAT;
			CLOSE date_cursor;	-- 关闭游标
		-- 判断错误状态，决定是否回滚
		 IF t_error = 1 THEN    
					ROLLBACK;    
			ELSE    
					COMMIT;    
			END IF;    
	END;


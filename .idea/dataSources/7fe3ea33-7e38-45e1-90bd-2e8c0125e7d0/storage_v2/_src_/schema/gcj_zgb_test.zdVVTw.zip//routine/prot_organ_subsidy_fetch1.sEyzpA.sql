create
    definer = part@`%` procedure prot_organ_subsidy_fetch1()
BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('prot_organ_subsidy_fetch1', 'pay2_haike', 7, 100636)/*[cr_debug.1]*/;
  DECLARE count_details int DEFAULT 0;-- 明细表中是否存在
  DECLARE product varchar(50); -- 产品编号
  DECLARE product_no1 varchar(50); -- 循环产品编号
  DECLARE agent_no1 varchar(50); 	-- 代理编号
  DECLARE agent_level1 varchar(50); 	-- 代理层级
  DECLARE parent_no1 varchar(50); 	-- 父级代理
  DECLARE is_min_agent_no varchar(50); 	-- 是否时最后一级代理
  DECLARE b_agent_no varchar(50) DEFAULT 0; 	-- 内循环的代理编号
  DECLARE trad_serial_no1 varchar(50); 	-- 交易流水号
  DECLARE trad_money1 varchar(50); -- 交易总额
  DECLARE organ_subsidy_policy varchar(50); -- 政策类型
  DECLARE policy_rate varchar(10); -- 奖励费率
  DECLARE this_agent_no varchar(30); -- 当前代理 
  DECLARE reward_earnings varchar(18) DEFAULT 0; -- 奖励收益
  DECLARE this_policy_rate varchar(10); -- 当前奖励费率
  DECLARE count_num int(5); -- 防止重复插入
  DECLARE front_end_display2 int(1); -- 当前代理享受政策
  DECLARE productss varchar(100); -- 代理有哪些产品
  DECLARE stopflg int DEFAULT 0; -- 初始化游标记录

  DECLARE date_cursor CURSOR FOR
  (SELECT
      aa.agent_no,
      aa.agent_level,
      ap.product_no
    FROM agent_agent aa
      LEFT JOIN agent_policy ap
        ON ap.agent_no = aa.agent_no
    WHERE ap.front_end_display = 1
    GROUP BY aa.agent_no,
             ap.product_no
    ORDER BY aa.agent_no DESC);

  DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('prot_organ_subsidy_fetch1_Handler', 'prot_organ_subsidy_fetch1', 'pay2_haike', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_level1', agent_level1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('parent_no1', parent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('is_min_agent_no', is_min_agent_no, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_agent_no', b_agent_no, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policy_rate', policy_rate, 'varchar(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('this_agent_no', this_agent_no, 'varchar(30)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('reward_earnings', reward_earnings, 'varchar(18)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('this_policy_rate', this_policy_rate, 'varchar(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_num', count_num, 'int(5)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('front_end_display2', front_end_display2, 'int(1)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('productss', productss, 'varchar(100)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(36, 36, 41, 57, cr_stack_depth)/*[cr_debug.2]*/;
SET stopflg = 1;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;   -- 当无记录时，标记游标终止
  CALL cr_debug.UPDATE_WATCH3('count_details', count_details, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_level1', agent_level1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('parent_no1', parent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('is_min_agent_no', is_min_agent_no, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_agent_no', b_agent_no, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policy_rate', policy_rate, 'varchar(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('this_agent_no', this_agent_no, 'varchar(30)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('reward_earnings', reward_earnings, 'varchar(18)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('this_policy_rate', this_policy_rate, 'varchar(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_num', count_num, 'int(5)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('front_end_display2', front_end_display2, 'int(1)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('productss', productss, 'varchar(100)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(2, 2, 0, 5, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(37, 37, 2, 19, cr_stack_depth)/*[cr_debug.2]*/;
OPEN date_cursor; -- 打开游标
  CALL cr_debug.TRACE(38, 160, 2, 13, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT
    CALL cr_debug.TRACE(39, 39, 4, 64, cr_stack_depth)/*[cr_debug.2]*/;
FETCH date_cursor INTO agent_no1, agent_level1, product_no1;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('agent_level1', agent_level1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
    CALL cr_debug.TRACE(40, 158, 4, 11, cr_stack_depth)/*[cr_debug.2]*/;
IF (stopflg != 1) THEN
   CALL cr_debug.TRACE(41, 41, 3, 26, cr_stack_depth)/*[cr_debug.2]*/;
SET @total_amount1 = 0;
CALL cr_debug.UPDATE_WATCH3('@total_amount1', @total_amount1, '', cr_stack_depth)/*[cr_debug.1]*/;
    BEGIN
      DECLARE stopflg1 int DEFAULT 0; -- 内循环游标记录

      DECLARE notrade_cur CURSOR FOR
      (SELECT
          ts.product_no,
          SUM(ts.trad_money) AS total_money,
          ts.trad_serial_no
        FROM trad_serial ts
        WHERE ts.trade_status = 1
        AND ts.trade_type IN ('0', '6', '9')
        AND DATE_FORMAT(DATE_SUB('2021-07-15', INTERVAL 1 MONTH), '%Y-%m') = DATE_FORMAT(ts.trad_date, '%Y-%m')
        AND ts.agent_no IN (SELECT
            aa.agent_no
          FROM agent_agent aa
          WHERE aa.parent_no = agent_no1)
        AND ts.product_no = product_no1
        AND ts.trade_type != 5
        GROUP BY ts.product_no
      --       SELECt
      --           ts.product_no,
      --           SUM(ts.trad_money-ts.deposit_amount) AS total_money,
      --           ts.trad_serial_no
      --         FROM trad_serial ts
      --         WHERE ts.trade_status = 1
      --         AND ts.trade_type IN ('0', '6', '9')
      --         AND DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), '%Y-%m') = DATE_FORMAT(ts.trad_date, '%Y-%m')
      --         AND ts.agent_no IN (SELECT
      --             agent_no
      --           FROM agent_agent aa
      --           WHERE parent_no = agent_no1)
      --         AND ts.trade_type!=5
      --         GROUP BY ts.product_no
      );

      DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('prot_organ_subsidy_fetch1_Handler', 'prot_organ_subsidy_fetch1', 'pay2_haike', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg1', stopflg1, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_details', count_details, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('product_no1', product_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('agent_level1', agent_level1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('parent_no1', parent_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('is_min_agent_no', is_min_agent_no, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('b_agent_no', b_agent_no, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, 'varchar(50)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('policy_rate', policy_rate, 'varchar(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('this_agent_no', this_agent_no, 'varchar(30)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('reward_earnings', reward_earnings, 'varchar(18)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('this_policy_rate', this_policy_rate, 'varchar(10)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('count_num', count_num, 'int(5)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('front_end_display2', front_end_display2, 'int(1)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('productss', productss, 'varchar(100)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('stopflg', stopflg, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(77, 77, 45, 62, cr_stack_depth)/*[cr_debug.2]*/;
SET stopflg1 = 1;
CALL cr_debug.UPDATE_WATCH3('stopflg1', stopflg1, '', cr_stack_depth)/*[cr_debug.1]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;
     
      CALL cr_debug.UPDATE_WATCH3('stopflg1', stopflg1, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(42, 42, 4, 9, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(79, 79, 6, 23, cr_stack_depth)/*[cr_debug.2]*/;
OPEN notrade_cur;
      CALL cr_debug.TRACE(80, 154, 6, 17, cr_stack_depth)/*[cr_debug.2]*/;
REPEAT
        CALL cr_debug.TRACE(81, 81, 8, 69, cr_stack_depth)/*[cr_debug.2]*/;
FETCH notrade_cur INTO product, trad_money1, trad_serial_no1;
CALL cr_debug.UPDATE_WATCH3('product', product, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
        CALL cr_debug.TRACE(82, 152, 8, 15, cr_stack_depth)/*[cr_debug.2]*/;
IF stopflg1 != 1 THEN

          CALL cr_debug.TRACE(84, 108, 10, 17, cr_stack_depth)/*[cr_debug.2]*/;
IF product = 'P00000001' THEN -- 电签
            CALL cr_debug.TRACE(85, 85, 12, 45, cr_stack_depth)/*[cr_debug.2]*/;
SET organ_subsidy_policy = '132';
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
          ELSEIF product = 'P00000002' THEN
            CALL cr_debug.TRACE(87, 87, 12, 45, cr_stack_depth)/*[cr_debug.2]*/;
SET organ_subsidy_policy = '131';
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
          ELSEIF product = 'P00000003' THEN
            CALL cr_debug.TRACE(89, 89, 12, 45, cr_stack_depth)/*[cr_debug.2]*/;
SET organ_subsidy_policy = '133';
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
          ELSEIF product = 'P00000004' THEN
            CALL cr_debug.TRACE(91, 91, 12, 45, cr_stack_depth)/*[cr_debug.2]*/;
SET organ_subsidy_policy = '134';
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
          ELSEIF product = 'P00000005' THEN
            CALL cr_debug.TRACE(93, 93, 12, 45, cr_stack_depth)/*[cr_debug.2]*/;
SET organ_subsidy_policy = '135';
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
          ELSEIF product = 'P00000006' THEN
            CALL cr_debug.TRACE(95, 95, 12, 45, cr_stack_depth)/*[cr_debug.2]*/;
SET organ_subsidy_policy = '136';
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
          ELSEIF product = 'P00000007' THEN
            CALL cr_debug.TRACE(97, 97, 12, 45, cr_stack_depth)/*[cr_debug.2]*/;
SET organ_subsidy_policy = '140';
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
          ELSEIF product = 'P00000008' THEN
            CALL cr_debug.TRACE(99, 99, 12, 45, cr_stack_depth)/*[cr_debug.2]*/;
SET organ_subsidy_policy = '141';
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
          ELSEIF product = 'P00000009' THEN
            CALL cr_debug.TRACE(101, 101, 12, 45, cr_stack_depth)/*[cr_debug.2]*/;
SET organ_subsidy_policy = '142';
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
          ELSEIF product = 'P00000010' THEN
            CALL cr_debug.TRACE(103, 103, 12, 45, cr_stack_depth)/*[cr_debug.2]*/;
SET organ_subsidy_policy = '137';
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
          ELSEIF product = 'P00000011' THEN
            CALL cr_debug.TRACE(105, 105, 12, 45, cr_stack_depth)/*[cr_debug.2]*/;
SET organ_subsidy_policy = '138';
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
          ELSEIF product = 'P00000012' THEN
            CALL cr_debug.TRACE(107, 107, 12, 45, cr_stack_depth)/*[cr_debug.2]*/;
SET organ_subsidy_policy = '139';
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
          END IF;
          -- 流水号   时间+当前代理
          CALL cr_debug.TRACE(110, 110, 10, 85, cr_stack_depth)/*[cr_debug.2]*/;
SET trad_serial_no1 = CONCAT(DATE_FORMAT('2021-07-15', '%Y%m'), agent_no1);
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, '', cr_stack_depth)/*[cr_debug.1]*/;

          -- 机构补贴
          CALL cr_debug.TRACE(113, 113, 10, 123, cr_stack_depth)/*[cr_debug.2]*/;
CALL prot_organ_subsidy1(agent_no1, organ_subsidy_policy, product, trad_money1, trad_serial_no1, @total_amount1);
CALL cr_debug.UPDATE_WATCH3('agent_no1', agent_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('organ_subsidy_policy', organ_subsidy_policy, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('product', product, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trad_money1', trad_money1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('trad_serial_no1', trad_serial_no1, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('@total_amount1', @total_amount1, '', cr_stack_depth)/*[cr_debug.1]*/;
          CALL cr_debug.TRACE(114, 115, 10, 27, cr_stack_depth)/*[cr_debug.2]*/;
SELECT
            @total_amount1;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
          CALL cr_debug.TRACE(116, 151, 10, 17, cr_stack_depth)/*[cr_debug.2]*/;
IF @total_amount1 >= 0 THEN
            CALL cr_debug.TRACE(117, 122, 12, 44, cr_stack_depth)/*[cr_debug.2]*/;
SET count_num = (SELECT
                COUNT(*)
              FROM agent_account_details aad
              WHERE aad.serial_no = trad_serial_no1
              AND aad.agent_no = agent_no1
              AND aad.product_no = product);
CALL cr_debug.UPDATE_WATCH3('count_num', count_num, '', cr_stack_depth)/*[cr_debug.1]*/;
            CALL cr_debug.TRACE(123, 150, 12, 19, cr_stack_depth)/*[cr_debug.2]*/;
IF count_num = 0 THEN
              -- 上级费率和上级代理
              CALL cr_debug.TRACE(125, 136, 14, 77, cr_stack_depth)/*[cr_debug.2]*/;
SELECT
                pdr.object_no,
                pdr.e_value
              FROM agent_policy ap
                LEFT JOIN policy_detail_rim pdr
                  ON pdr.policy_type_no = ap.policy_type_no
                  AND ap.agent_no = pdr.object_no
                  AND ap.product_no = pdr.product_no
              WHERE pdr.object_no = agent_no1
              AND ap.product_no = product
              AND pdr.policy_type_no = organ_subsidy_policy
              AND pdr.object_type = '1' INTO this_agent_no, this_policy_rate;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('this_agent_no', this_agent_no, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('this_policy_rate', this_policy_rate, '', cr_stack_depth)/*[cr_debug.1]*/;
              -- 上级代理奖励

              CALL cr_debug.TRACE(139, 139, 14, 92, cr_stack_depth)/*[cr_debug.2]*/;
SET reward_earnings = this_policy_rate * trad_money1 / 10000 - @total_amount1;
CALL cr_debug.UPDATE_WATCH3('reward_earnings', reward_earnings, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('@total_amount1', @total_amount1, '', cr_stack_depth)/*[cr_debug.1]*/;
              -- 插入金额
              CALL cr_debug.TRACE(141, 149, 14, 21, cr_stack_depth)/*[cr_debug.2]*/;
IF reward_earnings > 0 THEN
                CALL cr_debug.TRACE(142, 145, 16, 39, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE agent_account
                SET wait_account = wait_account + TRUNCATE(reward_earnings, 2)
                WHERE agent_no = agent_no1
                AND account_type = '0';
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/;
                -- 插入记录
                CALL cr_debug.TRACE(147, 148, 16, 149, cr_stack_depth)/*[cr_debug.2]*/;
INSERT INTO agent_account_details (serial_no, agent_no, amount, set_date, set_time, product_no, account_type, act_rim, source_flag, trade_money)
                  VALUES (trad_serial_no1, agent_no1, TRUNCATE(reward_earnings, 2), '2021-07-15', CURTIME(), product, '0', '机构补贴', '3', trad_money1);
CALL cr_debug.UPDATE_SYSTEM_CALLS(102)/*[cr_debug.1]*/;
              END IF;
            END IF;
          END IF;
        END IF;
      UNTIL stopflg1 = 1
      END REPEAT;
      CALL cr_debug.TRACE(155, 155, 6, 24, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE notrade_cur;	-- 关闭游标
    CALL cr_debug.TRACE(156, 156, 4, 7, cr_stack_depth)/*[cr_debug.2]*/;
END;

    END IF;
  UNTIL stopflg = 1
  END REPEAT;
  CALL cr_debug.TRACE(161, 161, 2, 20, cr_stack_depth)/*[cr_debug.2]*/;
CLOSE date_cursor;	-- 关闭游标
CALL cr_debug.TRACE(162, 162, 0, 3, cr_stack_depth)/*[cr_debug.2]*/;
SET cr_stack_depth = cr_stack_depth - 1/*[cr_debug.2]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth)/*[cr_debug.2]*/;
END;


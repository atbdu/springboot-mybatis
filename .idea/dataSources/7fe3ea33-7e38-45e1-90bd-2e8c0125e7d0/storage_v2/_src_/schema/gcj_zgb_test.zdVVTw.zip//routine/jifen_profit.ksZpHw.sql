create
    definer = part@`%` procedure jifen_profit()
BEGIN
	DECLARE stopflg INT DEFAULT 0;
  DECLARE product varchar(50);
	DECLARE agent_no1 VARCHAR(50);
	DECLARE device_no1 VARCHAR(50);
	DECLARE date_cursor CURSOR  FOR( -- 终端激活
			SELECT device_no,product_no FROM device WHERE `status`=2 AND (active_date='2021-06-07' OR active_date='2021-06-08' OR active_date='2021-06-09')
			AND product_no !='P00000003'
	);
	DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
		OPEN date_cursor; -- 打开游标
			REPEAT
				FETCH date_cursor INTO device_no1,product;
				
				IF(stopflg != 1) THEN	
						IF  product= 'P00000001' THEN -- 电签
                  CALL everyone_activate_jifen_producer(device_no1,'8');
									-- CALL everyone_activate_profit_producer(device_no1,'8'); -- 计算这一台电签的分润
							ELSEIF product= 'P00000002'THEN
									-- CALL everyone_activate_profit_producer(device_no1,'1'); -- 计算这一台POS的分润
                  CALL everyone_activate_jifen_producer(device_no1,'1');
							-- ELSEIF product = 'P00000003' THEN
								-- CALL everyone_activate_profit_producer(device_no1,'25'); -- 计算这一台POS的分润
							ELSEIF product = 'P00000004' THEN
									-- CALL everyone_activate_profit_producer(device_no1,'29'); -- 计算这一台电签的分润
                  CALL everyone_activate_jifen_producer(device_no1,'29');
							ELSEIF product = 'P00000005' THEN
									-- CALL everyone_activate_profit_producer(device_no1,'35'); -- 计算这一台电签的分润
                  CALL everyone_activate_jifen_producer(device_no1,'35');
							-- ELSEIF product = 'P00000006' THEN
									-- CALL everyone_activate_profit_producer(device_no1,'26'); -- 计算这一台电签的分润
							ELSEIF product = 'P00000007' THEN
									-- CALL everyone_activate_profit_producer(device_no1,'81'); -- 计算这一台电签的分润
                  CALL everyone_activate_jifen_producer(device_no1,'81');
							ELSEIF product = 'P00000008' THEN
									-- CALL everyone_activate_profit_producer(device_no1,'87'); -- 计算这一台电签的分润
                  CALL everyone_activate_jifen_producer(device_no1,'87');
							-- ELSEIF product = 'P00000009' THEN
									-- CALL everyone_activate_profit_producer(device_no1,'26'); -- 计算这一台电签的分润
							ELSEIF product = 'P00000010' THEN
									-- CALL everyone_activate_profit_producer(device_no1,'55'); -- 计算这一台电签的分润
                  CALL everyone_activate_jifen_producer(device_no1,'55');
							ELSEIF product = 'P00000011' THEN
									-- CALL everyone_activate_profit_producer(device_no1,'61'); -- 计算这一台电签的分润
                  CALL everyone_activate_jifen_producer(device_no1,'61');
							 ELSEIF product = 'P00000013' THEN
								UPDATE device SET reward_status = 1,`status`='2',active_date=CURDATE() WHERE device_no=device_no1;
                ELSEIF product = 'P00000014' THEN
								UPDATE device SET reward_status = 1,`status`='2',active_date=CURDATE() WHERE device_no=device_no1;	
							END IF;
				END IF;
			UNTIL stopflg =1
			END REPEAT;
		CLOSE date_cursor;	-- 关闭游标
END;


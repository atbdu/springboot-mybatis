create
    definer = part@`%` procedure everyone_deposit_policy(IN device_no1 varchar(50), IN policytype int,
                                                         IN product_no1 varchar(50), IN trade_money1 decimal(10, 2),
                                                         IN trade_type1 int) comment '押金分润'
BEGIN
	DECLARE stopflg INT DEFAULT 0;
  DECLARE source_flag1 int DEFAULT 10;
  DECLARE customer_no1 varchar(50);
  DECLARE chnnel_customer_no1 varchar(50);
	DECLARE agent_no1 VARCHAR(50); -- 代理编号
	DECLARE policy_money DECIMAL(15,2); -- 代理政策金额
	-- DECLARE trade_money1 DECIMAL(15,2); -- 交易金额
	DECLARE temp_value varchar(50) DEFAULT 0.00; -- 中间变量
	-- DECLARE product_no1 VARCHAR(50); -- 产品编号
	DECLARE date_cursor CURSOR  FOR( -- 终端押金政策
			select a.agent_no,pdr.e_value from policy_detail_rim pdr
	left join agent a on pdr.object_no=a.agent_no
	 where  pdr.policy_type_no=policytype and pdr.object_no IN (SELECT parent_no
                               FROM agent_agent
                               WHERE agent_no = (SELECT agent_no FROM device WHERE device_no=device_no1 ))
																AND object_type = '1' order by a.agent_level desc
	);
	DECLARE CONTINUE HANDLER FOR NOT FOUND set stopflg=1;   -- 当无记录时，标记游标终止
	-- 查询流水的交易金额，即为最后一级代理的设置押金
		-- SELECT trad_money,product_no FROM trad_serial WHERE trad_serial_no =trad_serial_no1 INTO trade_money1,product_no1;
    SELECT customer_no,chnnel_customer_no FROM device d WHERE d.device_no=device_no1 INTO customer_no1,chnnel_customer_no1;
		OPEN date_cursor; -- 打开游标
			REPEAT
				FETCH date_cursor INTO agent_no1,policy_money; -- 代理编号，和代理政策
				IF(stopflg != 1) THEN	
						SET temp_value = policy_money-temp_value;
						IF temp_value IS NOT NULL THEN
								UPDATE agent_account SET wait_account =wait_account + temp_value WHERE agent_no = agent_no1 AND account_type = '3';-- 服务费账户
								INSERT INTO agent_account_details
                (serial_no,agent_no,amount,set_date,set_time,product_no,account_type,act_rim,customer_no,
                chnnel_customer_no,device_no,trade_type,source_flag,trade_money)
                VALUES(
								device_no1,agent_no1,temp_value,CURDATE(),CURTIME(),product_no1,'3','终端代收服务费分润',customer_no1,
                chnnel_customer_no1,device_no1,trade_type1,source_flag1,trade_money1);
								SET temp_value = policy_money;
						END IF;
				END IF;
				UPDATE device SET cash_pledge_status = '2' WHERE device_no=device_no1;
			UNTIL stopflg =1
			END REPEAT;
		CLOSE date_cursor;	-- 关闭游标
END;


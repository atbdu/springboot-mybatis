create definer = part@`%` trigger trigger_customer_customer_no_insert
    before insert
    on customer
    for each row
begin
	set new.customer_no =ifnull(( select concat('C',LPAD((replace(max(customer_no),'C','')+1),8,0)) from customer),'C00000001');
end;

